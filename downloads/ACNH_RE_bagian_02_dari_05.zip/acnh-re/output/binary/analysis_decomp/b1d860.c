
void _INIT_2630(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003652fb0 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3652fe8);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003652fb4 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003652fb8 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003652fcc = 0xffff;
  uRam0000000003652fc8 = 0xffffffff;
  uRam0000000003652fd4 = 0;
  uRam0000000003652fd0 = 0;
  uRam0000000003652fbc = (undefined4)uVar2;
  uRam0000000003652fc0 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003652fd8 = uVar2;
  uRam0000000003652fe0 = 0;
  return;
}

