
void FUN_00c248c0(long param_1)

{
  FUN_00c0db10(param_1 + 0x2540);
  return;
}

