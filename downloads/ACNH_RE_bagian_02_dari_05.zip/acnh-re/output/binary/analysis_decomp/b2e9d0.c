
void FUN_00c2e9d0(undefined4 param_1)

{
  undefined8 uVar1;
  ulong uVar2;
  
  uVar1 = *puRam00000000033d0f28;
  FUN_00c12830(uVar1);
  FUN_00c02c00();
  uVar2 = *puRam00000000033d2050;
  FUN_001c6030(uVar2);
  FUN_00bf87a0(uVar1,param_1,uVar2 & 0xffffffff);
  FUN_00bf8140();
  return;
}

