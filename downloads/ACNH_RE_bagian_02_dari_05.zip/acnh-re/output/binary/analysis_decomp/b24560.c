
bool FUN_00c24560(long param_1)

{
  if (*(uint *)(param_1 + 0x48) < 10 &&
      (1 << (ulong)(*(uint *)(param_1 + 0x48) & 0x1f) & 0x2a8U) != 0) {
    *(undefined1 *)(param_1 + 0x246d) = 1;
    return true;
  }
  return *(char *)(param_1 + 0x246d) != '\0';
}

