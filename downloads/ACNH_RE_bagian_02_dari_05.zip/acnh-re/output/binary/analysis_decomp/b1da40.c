
void FUN_00c1da40(long param_1)

{
  long lVar1;
  ulong uVar2;
  undefined2 uVar3;
  ulong uVar4;
  ulong uVar5;
  undefined1 auStack_148 [40];
  undefined8 uStack_120;
  undefined2 uStack_118;
  undefined1 uStack_116;
  undefined4 uStack_114;
  long lStack_110;
  undefined2 *puStack_108;
  undefined4 uStack_100;
  undefined2 auStack_fc [66];
  long lStack_78;
  undefined2 *puStack_70;
  undefined4 uStack_68;
  undefined2 auStack_64 [18];
  
  uStack_120 = *(undefined8 *)(param_1 + 0x208);
  uStack_118 = 1;
  uStack_116 = 0;
  lVar1 = lRam00000000033d5c88 + 0x10;
  puStack_108 = auStack_fc;
  uStack_114 = 0;
  uStack_100 = 0x40;
  lStack_110 = lVar1;
  FUN_01a907a0(&lStack_110);
  uVar3 = *puRam00000000033d14d0;
  lStack_110 = lRam00000000033f4da8 + 0x10;
  *puStack_108 = uVar3;
  puStack_70 = auStack_64;
  uStack_68 = 0x10;
  lStack_78 = lVar1;
  FUN_01a907a0(&lStack_78);
  *puStack_70 = uVar3;
  uVar2 = param_1 + 0x210;
  lStack_78 = lRam00000000033e7770 + 0x10;
  uVar4 = uVar2;
  FUN_00122100();
  if ((uVar4 & 1) == 0) {
    if (*(long *)(param_1 + 0x238) != 0) {
      FUN_001220b0(auStack_148);
      FUN_00122180(auStack_148,*(undefined8 *)(param_1 + 0x238),0);
      FUN_00c1dd00(&uStack_120,auStack_148);
      FUN_00c1e050(&uStack_120);
      *(undefined1 *)(param_1 + 0x240) = 1;
      FUN_001220d0(auStack_148);
    }
  }
  else {
    uVar4 = uVar2;
    FUN_00122290();
    uVar5 = uVar2;
    FUN_001222a0();
    if (((int)uVar4 != 0x28) || ((int)uVar5 != 0)) {
      FUN_00c1dd00(&uStack_120,uVar2);
      FUN_00c1e050(&uStack_120);
      *(undefined1 *)(param_1 + 0x240) = 1;
    }
  }
  return;
}

