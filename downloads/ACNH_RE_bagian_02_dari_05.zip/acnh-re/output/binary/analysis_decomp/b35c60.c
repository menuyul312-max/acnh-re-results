
void FUN_00c35c60(long *param_1)

{
  long lVar1;
  ulong uVar2;
  byte bVar3;
  long *plVar4;
  uint uVar5;
  long lStack_58;
  long lStack_50;
  undefined4 auStack_40 [2];
  long lStack_38;
  
  plVar4 = param_1 + 0x1c;
  lVar1 = lRam00000000033d5200 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,plVar4,0xb);
  uVar2 = (long)param_1 + 0xf6U;
  if ((long)param_1 + 0xf6U <= (long)param_1 + 0xe2U) {
    uVar2 = (long)param_1 + 0xe2U;
  }
  *param_1 = lVar1;
  *(undefined8 *)((long)param_1 + 0xee) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  memset(plVar4,0,(uVar2 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  uVar5 = 2;
  *(undefined4 *)(param_1 + 0x1f) = 2;
  FUN_00fecf00();
  FUN_00fe9350(&lStack_58,plVar4 + 0x1ce23,1);
  lStack_58 = lRam00000000033d4cb0 + 0x10;
  lStack_38 = *(long *)(lStack_50 + 0x10) + *(long *)(lStack_50 + 8) + 4;
  auStack_40[0] = 10;
  FUN_010e4670(param_1,auStack_40);
  bVar3 = *(byte *)(*(long *)(lStack_50 + 0x10) + *(long *)(lStack_50 + 8) + 0x18);
  if (bVar3 < 4) {
    uVar5 = (uint)bVar3;
  }
  *(uint *)(param_1 + 0x1f) = uVar5;
  FUN_00fe93d0(&lStack_58);
  return;
}

