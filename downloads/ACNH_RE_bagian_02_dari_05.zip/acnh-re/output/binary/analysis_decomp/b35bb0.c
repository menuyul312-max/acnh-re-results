
void _INIT_2663(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655a28 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655a60);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655a2c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655a30 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655a44 = 0xffff;
  uRam0000000003655a40 = 0xffffffff;
  uRam0000000003655a4c = 0;
  uRam0000000003655a48 = 0;
  uRam0000000003655a34 = (undefined4)uVar2;
  uRam0000000003655a38 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655a50 = uVar2;
  uRam0000000003655a58 = 0;
  return;
}

