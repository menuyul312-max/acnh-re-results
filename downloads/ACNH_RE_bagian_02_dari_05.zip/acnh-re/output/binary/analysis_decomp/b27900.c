
long FUN_00c27900(long param_1)

{
  return param_1 + 0x6f8;
}

