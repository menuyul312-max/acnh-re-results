
void FUN_00c34180(long param_1,undefined4 param_2,long param_3)

{
  int iStack_14;
  
  iStack_14 = (int)*(char *)(param_3 + 4);
  if (*(char *)(param_3 + 4) < '\x18') {
    if (iStack_14 < 0) {
      iStack_14 = 0;
    }
  }
  else {
    iStack_14 = 0x17;
  }
  FUN_00c170f0(param_1,param_2,&iStack_14);
  *(int *)(param_1 + 0x108) = iStack_14;
  return;
}

