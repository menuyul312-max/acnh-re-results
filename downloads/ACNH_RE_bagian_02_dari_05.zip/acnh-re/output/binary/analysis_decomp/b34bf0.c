
void FUN_00c34bf0(undefined8 param_1)

{
  ulong uVar1;
  ulong uVar2;
  undefined1 *puVar3;
  long lStack_50;
  long lStack_48;
  undefined1 auStack_38 [8];
  undefined4 auStack_30 [2];
  long lStack_28;
  undefined1 auStack_18 [8];
  
  uVar2 = 0;
  FUN_00ea3fc0(auStack_18);
  uVar1 = 0;
  FUN_00ea4020();
  if ((uVar1 & 1) == 0) {
    FUN_00f712f0(&lStack_50);
    FUN_00ea4020();
    auStack_18[0] = (undefined1)lStack_50;
    if ((uVar2 & 1) == 0) {
      auStack_18[0] = 0xff;
    }
  }
  FUN_00ea3fc0(auStack_38,auStack_18);
  puVar3 = auStack_38;
  thunk_FUN_00faafd0();
  if (puVar3 != (undefined1 *)0x0) {
    FUN_00fe9350(&lStack_50,puVar3 + 0x165e0,1);
    lStack_50 = lRam00000000033d98a0 + 0x10;
    lStack_28 = *(long *)(lStack_48 + 0x10) + *(long *)(lStack_48 + 8) + 4;
    auStack_30[0] = 10;
    FUN_010e4670(param_1,auStack_30);
    FUN_001234f0(param_1);
    FUN_00121d40();
    FUN_00fe93d0(&lStack_50);
  }
  return;
}

