
uint FUN_00c352e0(long *param_1,undefined1 *param_2,undefined4 param_3)

{
  uint uVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  long *plVar4;
  long *plVar5;
  long lStack_d0;
  long *plStack_c8;
  long lStack_c0;
  undefined1 *puStack_b8;
  undefined4 uStack_b0;
  undefined1 auStack_ac [68];
  long lStack_68;
  undefined8 uStack_60;
  undefined1 auStack_58 [24];
  
  plVar5 = &lStack_d0;
  puVar2 = param_2;
  FUN_01058a90(param_2);
  puVar3 = param_2;
  FUN_01058d00();
  if (((ulong)puVar3 & 1) == 0) {
    uVar1 = 0;
  }
  else {
    plVar4 = param_1;
    (**(code **)(*param_1 + 0x10))();
    FUN_00b9c290(auStack_58,param_2);
    FUN_00ba2c90(&lStack_68,auStack_58);
    puStack_b8 = auStack_ac;
    lStack_c0 = lRam00000000033d0670 + 0x10;
    uStack_b0 = 0x40;
    FUN_01a90780(&lStack_c0);
    lStack_c0 = lRam00000000033d1298;
    *puStack_b8 = *puRam00000000033d0660;
    lStack_c0 = lStack_c0 + 0x10;
    puVar3 = auStack_58;
    FUN_00b9cb60(puVar3,0x4a);
    (**(code **)(lStack_68 + 0x18))(&lStack_68);
    if (((ulong)puVar3 & 1) != 0) {
      FUN_00bac440(&lStack_d0,auStack_58);
      FUN_01058a90(&lStack_d0);
      puVar2 = (undefined1 *)plVar5;
    }
    FUN_01a90820(&lStack_c0,&UNK_02ac7184,uStack_60,(ulong)puVar2 & 0xffffffff,param_3);
    param_1 = param_1 + 1;
    lStack_d0 = lRam00000000033d0668 + 0x10;
    plStack_c8 = plVar4;
    FUN_00123860(param_1,&lStack_d0,&lStack_c0,0);
    uVar1 = (uint)param_1;
  }
  return uVar1 & 1;
}

