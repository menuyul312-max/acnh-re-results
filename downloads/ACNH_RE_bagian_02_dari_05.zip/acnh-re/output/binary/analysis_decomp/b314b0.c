
void FUN_00c314b0(long *param_1)

{
  *param_1 = lRam00000000033f5238 + 0x10;
  FUN_001237f0(param_1 + 0x3e);
  FUN_001237f0(param_1 + 2);
  return;
}

