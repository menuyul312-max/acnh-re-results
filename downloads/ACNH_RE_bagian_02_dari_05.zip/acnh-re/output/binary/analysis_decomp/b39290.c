
bool FUN_00c39290(ulong param_1,undefined4 *param_2,undefined8 param_3,undefined8 param_4)

{
  bool bVar1;
  ulong uVar2;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  long lStack_78;
  undefined1 *puStack_70;
  undefined4 uStack_68;
  undefined1 auStack_64 [36];
  
  uVar2 = *puRam00000000033d3ef0;
  FUN_00c41ec0(uVar2);
  puStack_70 = auStack_64;
  lStack_78 = lRam00000000033d0670 + 0x10;
  uStack_68 = 0x20;
  FUN_01a90780(&lStack_78);
  lStack_78 = lRam00000000033d0680;
  *puStack_70 = *puRam00000000033d0660;
  lStack_78 = lStack_78 + 0x10;
  FUN_00c38550(param_1,&uStack_88,param_4,uVar2 & 0xffffffff);
  bVar1 = (param_1 & 1) != 0;
  if (bVar1) {
    *param_2 = uStack_88;
    param_2[1] = uStack_84;
    param_2[2] = uStack_80;
    (**(code **)(lStack_78 + 0x18))(&lStack_78);
    FUN_01a90820(param_3,&UNK_02a3e896,puStack_70);
  }
  return bVar1;
}

