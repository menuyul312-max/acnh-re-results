
void FUN_00c1dc00(undefined8 param_1)

{
  FUN_00c1dd00();
  FUN_00c1e050(param_1);
  return;
}

