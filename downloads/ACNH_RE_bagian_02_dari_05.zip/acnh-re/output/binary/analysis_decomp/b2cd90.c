
void FUN_00c2cd90(long param_1,uint param_2)

{
  long *plVar1;
  
  plVar1 = *(long **)(param_1 + 0x18);
  if ((*(int *)(*plVar1 + 0x244) == 1) && ((int)plVar1[1] == 0)) {
    *(undefined1 *)(*(long *)(*plVar1 + 0x220) + 0x304) = 1;
    if ((param_2 & 1) != 0) {
      *(undefined1 *)(*(long *)(*plVar1 + 0x220) + 0x306) = 1;
    }
    *(undefined4 *)(plVar1 + 1) = 1;
    return;
  }
  return;
}

