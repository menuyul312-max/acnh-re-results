
undefined8 FUN_00c367e0(undefined8 param_1,ulong param_2,long param_3)

{
  long lVar1;
  uint uVar2;
  short sVar3;
  long lVar4;
  undefined8 uVar5;
  int iVar6;
  short *psVar7;
  ulong uVar8;
  short *psVar9;
  uint uVar10;
  long lVar11;
  uint uVar12;
  long lStack_e8;
  short *psStack_e0;
  long lStack_d8;
  short *psStack_d0;
  int iStack_c8;
  short asStack_c4 [34];
  long lStack_80;
  short *psStack_78;
  undefined4 uStack_70;
  short asStack_6c [14];
  
  psStack_78 = asStack_6c;
  lVar11 = lRam00000000033d5c88 + 0x10;
  uStack_70 = 0xd;
  lStack_80 = lVar11;
  FUN_01a907a0(&lStack_80);
  sVar3 = *psRam00000000033d14d0;
  lStack_80 = lRam00000000033f5298 + 0x10;
  *psStack_78 = sVar3;
  psStack_d0 = asStack_c4;
  iStack_c8 = 0x20;
  lStack_d8 = lVar11;
  FUN_01a907a0(&lStack_d8);
  lStack_d8 = lRam00000000033f4878;
  *psStack_d0 = sVar3;
  lStack_d8 = lStack_d8 + 0x10;
  FUN_00117b60(param_2,&lStack_80);
  if ((param_2 & 1) == 0) {
    FUN_001232c0(param_1);
    uVar5 = 0;
  }
  else {
    *psStack_d0 = sVar3;
    psVar7 = psStack_d0;
    lVar4 = lRam00000000033f4dc0;
    lStack_e8 = lRam00000000033f4dc0 + 0x10;
    psStack_e0 = (short *)param_3;
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) {
LAB_00c36928:
        uVar10 = (uint)lVar11;
        uVar12 = uVar10 & ((int)uVar10 >> 0x1f ^ 0xffffffffU);
        goto LAB_00c3692c;
      }
      if (psStack_d0[lVar11 + 1] == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36928;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        lVar11 = lVar11 + 2;
        goto LAB_00c36928;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    uVar10 = 0;
    uVar12 = 0;
LAB_00c3692c:
    (**(code **)(lStack_e8 + 0x18))(&lStack_e8);
    lVar11 = 0;
    do {
      if (*(short *)((long)psStack_e0 + lVar11 * 2) == sVar3) goto LAB_00c36990;
      lVar1 = (long)psStack_e0 + lVar11 * 2;
      if (*(short *)(lVar1 + 2) == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36990;
      }
      if (*(short *)(lVar1 + 4) == sVar3) {
        lVar11 = lVar11 + 2;
        goto LAB_00c36990;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    lVar11 = 0;
LAB_00c36990:
    uVar2 = (uint)lVar11;
    if ((int)(iStack_c8 - uVar12) <= (int)(uint)lVar11) {
      uVar2 = iStack_c8 + ~uVar12;
    }
    if (0 < (int)uVar2) {
      (**(code **)(lStack_e8 + 0x18))(&lStack_e8);
      memcpy(psVar7 + uVar12,psStack_e0,
             -(ulong)(uVar2 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar2 << 1);
      if ((int)uVar10 < (int)(uVar2 + uVar12)) {
        psVar7[(int)(uVar2 + uVar12)] = sVar3;
      }
    }
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) goto LAB_00c36a38;
      if (psStack_d0[lVar11 + 1] == sVar3) {
        iVar6 = (int)lVar11 + 1;
        if (iVar6 < iStack_c8 + -1) goto LAB_00c36a48;
        goto LAB_00c36a58;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        iVar6 = (int)lVar11 + 2;
        if (iVar6 < iStack_c8 + -1) goto LAB_00c36a48;
        goto LAB_00c36a58;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    lVar11 = 0;
LAB_00c36a38:
    iVar6 = (int)lVar11;
    if (iVar6 < iStack_c8 + -1) {
LAB_00c36a48:
      psStack_d0[iVar6] = 0x2011;
      (psStack_d0 + iVar6)[1] = sVar3;
    }
LAB_00c36a58:
    (**(code **)(lStack_80 + 0x18))(&lStack_80);
    psVar9 = psStack_d0;
    iVar6 = 0;
    uVar8 = 0xffffffffffffffff;
    psVar7 = psStack_78 + 2;
    do {
      psStack_e0 = psStack_78;
      if (psVar7[-2] == sVar3) {
joined_r0x00c36ae8:
        if (iVar6 < 0) {
          psStack_e0 = *(short **)(lRam00000000033f4dc8 + 8);
        }
        break;
      }
      if (psVar7[-1] == sVar3) {
        iVar6 = iVar6 + 1;
        goto joined_r0x00c36ae8;
      }
      if (*psVar7 == sVar3) {
        iVar6 = (int)uVar8 + 3;
        goto joined_r0x00c36ae8;
      }
      uVar8 = uVar8 + 3;
      iVar6 = iVar6 + 3;
      psVar7 = psVar7 + 3;
    } while (uVar8 >> 0x13 == 0);
    lStack_e8 = lVar4 + 0x10;
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) {
LAB_00c36b78:
        uVar10 = (uint)lVar11;
        uVar12 = uVar10 & ((int)uVar10 >> 0x1f ^ 0xffffffffU);
        goto LAB_00c36b7c;
      }
      if (psStack_d0[lVar11 + 1] == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36b78;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        lVar11 = lVar11 + 2;
        goto LAB_00c36b78;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    uVar10 = 0;
    uVar12 = 0;
LAB_00c36b7c:
    uVar2 = 4;
    if ((int)(iStack_c8 - uVar12) < 5) {
      uVar2 = iStack_c8 + ~uVar12;
    }
    if (0 < (int)uVar2) {
      (**(code **)(lStack_e8 + 0x18))(&lStack_e8);
      memcpy(psVar9 + uVar12,psStack_e0,
             -(ulong)(uVar2 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar2 << 1);
      if ((int)uVar10 < (int)(uVar2 + uVar12)) {
        psVar9[(int)(uVar2 + uVar12)] = sVar3;
      }
    }
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) goto LAB_00c36c28;
      if (psStack_d0[lVar11 + 1] == sVar3) {
        iVar6 = (int)lVar11 + 1;
        if (iVar6 < iStack_c8 + -1) goto LAB_00c36c38;
        goto LAB_00c36c48;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        iVar6 = (int)lVar11 + 2;
        if (iVar6 < iStack_c8 + -1) goto LAB_00c36c38;
        goto LAB_00c36c48;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    lVar11 = 0;
LAB_00c36c28:
    iVar6 = (int)lVar11;
    if (iVar6 < iStack_c8 + -1) {
LAB_00c36c38:
      psStack_d0[iVar6] = 0x2011;
      (psStack_d0 + iVar6)[1] = sVar3;
    }
LAB_00c36c48:
    (**(code **)(lStack_80 + 0x18))(&lStack_80);
    psVar7 = psStack_d0;
    lVar11 = 0;
    do {
      if (psStack_78[lVar11] == sVar3) {
LAB_00c36cd0:
        iVar6 = (int)lVar11;
joined_r0x00c36cd4:
        if (3 < iVar6) {
          psVar9 = psStack_78 + 4;
          goto LAB_00c36cf8;
        }
        break;
      }
      if (psStack_78[lVar11 + 1] == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36cd0;
      }
      if (psStack_78[lVar11 + 2] == sVar3) {
        iVar6 = (int)lVar11 + 2;
        goto joined_r0x00c36cd4;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    psVar9 = *(short **)(lRam00000000033f4dc8 + 8);
LAB_00c36cf8:
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) {
LAB_00c36d60:
        uVar10 = (uint)lVar11;
        uVar12 = uVar10 & ((int)uVar10 >> 0x1f ^ 0xffffffffU);
        goto LAB_00c36d64;
      }
      if (psStack_d0[lVar11 + 1] == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36d60;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        lVar11 = lVar11 + 2;
        goto LAB_00c36d60;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    uVar10 = 0;
    uVar12 = 0;
LAB_00c36d64:
    uVar2 = 4;
    if ((int)(iStack_c8 - uVar12) < 5) {
      uVar2 = iStack_c8 + ~uVar12;
    }
    if (0 < (int)uVar2) {
      memcpy(psVar7 + uVar12,psVar9,-(ulong)(uVar2 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar2 << 1
            );
      if ((int)uVar10 < (int)(uVar2 + uVar12)) {
        psVar7[(int)(uVar2 + uVar12)] = sVar3;
      }
    }
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) goto LAB_00c36dfc;
      if (psStack_d0[lVar11 + 1] == sVar3) {
        iVar6 = (int)lVar11 + 1;
        if (iVar6 < iStack_c8 + -1) goto LAB_00c36e0c;
        goto LAB_00c36e1c;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        iVar6 = (int)lVar11 + 2;
        if (iVar6 < iStack_c8 + -1) goto LAB_00c36e0c;
        goto LAB_00c36e1c;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    lVar11 = 0;
LAB_00c36dfc:
    iVar6 = (int)lVar11;
    if (iVar6 < iStack_c8 + -1) {
LAB_00c36e0c:
      psStack_d0[iVar6] = 0x2011;
      (psStack_d0 + iVar6)[1] = sVar3;
    }
LAB_00c36e1c:
    (**(code **)(lStack_80 + 0x18))(&lStack_80);
    psVar7 = psStack_d0;
    lVar11 = 0;
    do {
      if (psStack_78[lVar11] == sVar3) {
LAB_00c36ea4:
        iVar6 = (int)lVar11;
joined_r0x00c36ea8:
        if (7 < iVar6) {
          psVar9 = psStack_78 + 8;
          goto LAB_00c36ecc;
        }
        break;
      }
      if (psStack_78[lVar11 + 1] == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36ea4;
      }
      if (psStack_78[lVar11 + 2] == sVar3) {
        iVar6 = (int)lVar11 + 2;
        goto joined_r0x00c36ea8;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    psVar9 = *(short **)(lRam00000000033f4dc8 + 8);
LAB_00c36ecc:
    (**(code **)(lStack_d8 + 0x18))(&lStack_d8);
    lVar11 = 0;
    do {
      if (psStack_d0[lVar11] == sVar3) {
LAB_00c36f34:
        uVar10 = (uint)lVar11;
        uVar12 = uVar10 & ((int)uVar10 >> 0x1f ^ 0xffffffffU);
        goto LAB_00c36f38;
      }
      if (psStack_d0[lVar11 + 1] == sVar3) {
        lVar11 = lVar11 + 1;
        goto LAB_00c36f34;
      }
      if (psStack_d0[lVar11 + 2] == sVar3) {
        lVar11 = lVar11 + 2;
        goto LAB_00c36f34;
      }
      uVar8 = lVar11 + 2;
      lVar11 = lVar11 + 3;
    } while (uVar8 >> 0x13 == 0);
    uVar10 = 0;
    uVar12 = 0;
LAB_00c36f38:
    uVar2 = 4;
    if ((int)(iStack_c8 - uVar12) < 5) {
      uVar2 = iStack_c8 + ~uVar12;
    }
    if (0 < (int)uVar2) {
      memcpy(psVar7 + uVar12,psVar9,-(ulong)(uVar2 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar2 << 1
            );
      if ((int)uVar10 < (int)(uVar2 + uVar12)) {
        psVar7[(int)(uVar2 + uVar12)] = sVar3;
      }
    }
    FUN_00123cc0(param_1,&lStack_d8);
    uVar5 = 1;
  }
  return uVar5;
}

