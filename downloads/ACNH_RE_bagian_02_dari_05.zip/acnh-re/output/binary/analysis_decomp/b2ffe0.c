
void FUN_00c2ffe0(long *param_1)

{
  long *plVar1;
  
  plVar1 = param_1;
  (**(code **)(*param_1 + 0x28))();
  if ((int)plVar1 == 2) {
                    /* WARNING: Could not recover jumptable at 0x00c30018. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x48))(param_1);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00c3002c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x38))(param_1);
  return;
}

