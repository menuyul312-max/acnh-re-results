
void FUN_00c2a750(undefined8 param_1)

{
  int iVar1;
  
  if ((bRam0000000003654378 & 1) == 0) {
    iVar1 = 0x3654378;
    __cxa_guard_acquire();
    if (iVar1 != 0) {
      FUN_0175b320(0x3654390,param_1);
      FUN_001001c0(uRam00000000033d6190,0x3654390,&DAT_0311c000);
      __cxa_guard_release(0x3654378);
    }
  }
  FUN_0175aed0(0x3654390,param_1,0);
  return;
}

