
void FUN_00c1f6b0(long param_1)

{
  FUN_00c1fb90(param_1 + 8);
  return;
}

