
uint FUN_00c330e0(undefined8 param_1,int *param_2)

{
  long lVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  long *plVar6;
  ulong uVar7;
  long *plVar8;
  long lStack_70;
  undefined *puStack_68;
  long lStack_60;
  undefined *puStack_58;
  undefined4 uStack_50;
  undefined1 auStack_4c [12];
  undefined8 uVar5;
  
  iVar2 = *param_2;
  if (iVar2 != -1) {
    uVar5 = param_1;
    FUN_00e1c3d0();
    iVar3 = (int)uVar5;
    FUN_00e21860();
    if (iVar2 == iVar3) {
      lVar1 = lRam00000000033d0668 + 0x10;
      plVar6 = &lStack_60;
      puStack_58 = &UNK_02a5b2d9;
      lStack_60 = lVar1;
      FUN_00c1a380(plVar6);
      uVar7 = (ulong)*puRam00000000033d2b68;
      _ZN2nn2os11GetTlsValueENS0_7TlsSlotE(uVar7);
      FUN_01aaa0e0();
      puStack_58 = auStack_4c;
      lStack_60 = lRam00000000033d0670 + 0x10;
      uStack_50 = 8;
      FUN_01a90780(&lStack_60);
      *puStack_58 = *puRam00000000033d0660;
      lStack_60 = lRam00000000033d25e8 + 0x10;
      plVar8 = &lStack_60;
      puStack_68 = &UNK_02a5b2d9;
      lStack_70 = lVar1;
      FUN_00c1a3c0(plVar8,&lStack_70,(uVar7 & 0xffffffff) * ((ulong)plVar6 & 0xffffffff) >> 0x20);
      if (((ulong)plVar8 & 1) != 0) {
        puStack_68 = &UNK_02a5b2d9;
        lStack_70 = lVar1;
        FUN_00123860(param_1,&lStack_70,&lStack_60,0);
        uVar4 = (uint)param_1;
        goto LAB_00c331dc;
      }
    }
  }
  uVar4 = 0;
LAB_00c331dc:
  return uVar4 & 1;
}

