
uint FUN_00c2f1e0(ulong param_1)

{
  ulong uVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  ulong uVar5;
  uint uStack_14;
  
  uVar5 = param_1 & 0xffffffff;
  uVar1 = param_1;
  FUN_0011db00();
  uVar4 = (uint)param_1;
  if ((uVar1 & 1) != 0) {
    uStack_14 = (uVar4 & 0xffff) + 0x27;
    goto LAB_00c2f22c;
  }
  uVar1 = uVar5;
  FUN_0011db70();
  if ((uVar1 & 1) == 0) {
    uVar1 = param_1 & 0xffffffff;
    FUN_0011db90();
    if ((uVar1 & 1) != 0) {
      iVar2 = -0x30a0;
      goto LAB_00c2f228;
    }
    uVar1 = param_1 & 0xffffffff;
    FUN_0011dc40();
    if ((uVar1 & 1) == 0) {
      uVar1 = param_1 & 0xffffffff;
      FUN_0011dc20();
      if ((uVar1 & 1) == 0) {
        uVar1 = uVar5;
        FUN_0011dc80();
        if ((uVar1 & 1) == 0) {
          uVar1 = param_1 & 0xffffffff;
          FUN_0011dc60();
          if ((uVar1 & 1) == 0) {
            uVar1 = param_1 & 0xffffffff;
            FUN_0011dcc0();
            if ((uVar1 & 1) != 0) {
LAB_00c2f2d4:
              return (uVar4 & 0xffff) + 0x108;
            }
            uVar1 = param_1 & 0xffffffff;
            FUN_0011dca0();
            if ((uVar1 & 1) != 0) goto LAB_00c2f2d4;
            uVar1 = param_1 & 0xffffffff;
            FUN_0011dce0();
            if ((uVar1 & 1) != 0) goto LAB_00c2f2d4;
            uVar1 = param_1 & 0xffffffff;
            FUN_0011dcf0();
            if ((uVar1 & 1) != 0) goto LAB_00c2f2d4;
            uVar1 = param_1 & 0xffffffff;
            FUN_0011dd10();
            if ((uVar1 & 1) != 0) goto LAB_00c2f2d4;
            param_1 = param_1 & 0xffffffff;
            FUN_0011de40();
            if ((param_1 & 1) == 0) {
              uVar1 = uVar5;
              FUN_0011de20();
              if ((uVar1 & 1) == 0) {
                uVar1 = uVar5;
                FUN_0011de60();
                if (((uVar4 - 0x4e00 >> 9 & 0x7f) < 0x29) || ((uVar1 & 1) != 0)) {
                  uStack_14 = 0;
                  FUN_01170f30(&uStack_14,uVar5);
                }
                else {
                  uVar4 = uVar4 & 0xffff;
                  uStack_14 = 0x107;
                  if (uVar4 < 0x386) {
                    if (uVar4 < 0xa0) {
                      switch(uVar4) {
                      case 0:
                        puVar3 = &UNK_02af8f04;
                        break;
                      default:
                        goto switchD_00c2f374_caseD_387;
                      case 10:
                        puVar3 = &UNK_02af8f00;
                        break;
                      case 0x20:
                        puVar3 = &UNK_02af8eec;
                        break;
                      case 0x21:
                        puVar3 = &UNK_02af8edc;
                        break;
                      case 0x2c:
                        puVar3 = &UNK_02af8ef8;
                        break;
                      case 0x2e:
                        puVar3 = &UNK_02af8efc;
                        break;
                      case 0x3f:
                        puVar3 = &UNK_02af8ed4;
                      }
                    }
                    else if (uVar4 < 0xff) {
                      if (uVar4 == 0xa0) {
                        puVar3 = &UNK_02af8ef4;
                      }
                      else if (uVar4 == 0xb7) {
                        puVar3 = &UNK_02af8ec8;
                      }
                      else {
                        if (uVar4 != 0xdf) {
                          return 0x107;
                        }
                        puVar3 = &UNK_02af8f60;
                      }
                    }
                    else if (uVar4 < 0x153) {
                      if (uVar4 == 0xff) {
                        puVar3 = &UNK_02af8f58;
                      }
                      else {
                        if (uVar4 != 0x152) {
                          return 0x107;
                        }
                        puVar3 = &UNK_02af8f68;
                      }
                    }
                    else if (uVar4 == 0x153) {
                      puVar3 = &UNK_02af8f64;
                    }
                    else {
                      if (uVar4 != 0x178) {
                        return 0x107;
                      }
                      puVar3 = &UNK_02af8f5c;
                    }
                  }
                  else if (uVar4 < 0x2026) {
                    switch(uVar4) {
                    case 0x386:
                      puVar3 = &UNK_02af8f08;
                      break;
                    default:
                      goto switchD_00c2f374_caseD_387;
                    case 0x388:
                      puVar3 = &UNK_02af8f0c;
                      break;
                    case 0x389:
                      puVar3 = &UNK_02af8f10;
                      break;
                    case 0x38a:
                      puVar3 = &UNK_02af8f14;
                      break;
                    case 0x38c:
                      puVar3 = &UNK_02af8f18;
                      break;
                    case 0x38e:
                      puVar3 = &UNK_02af8f1c;
                      break;
                    case 0x38f:
                      puVar3 = &UNK_02af8f20;
                      break;
                    case 0x390:
                      puVar3 = &UNK_02af8f50;
                      break;
                    case 0x3aa:
                      puVar3 = &UNK_02af8f24;
                      break;
                    case 0x3ab:
                      puVar3 = &UNK_02af8f28;
                      break;
                    case 0x3ac:
                      puVar3 = &UNK_02af8f2c;
                      break;
                    case 0x3ad:
                      puVar3 = &UNK_02af8f30;
                      break;
                    case 0x3ae:
                      puVar3 = &UNK_02af8f34;
                      break;
                    case 0x3af:
                      puVar3 = &UNK_02af8f38;
                      break;
                    case 0x3b0:
                      puVar3 = &UNK_02af8f54;
                      break;
                    case 0x3ca:
                      puVar3 = &UNK_02af8f48;
                      break;
                    case 0x3cb:
                      puVar3 = &UNK_02af8f4c;
                      break;
                    case 0x3cc:
                      puVar3 = &UNK_02af8f3c;
                      break;
                    case 0x3cd:
                      puVar3 = &UNK_02af8f40;
                      break;
                    case 0x3ce:
                      puVar3 = &UNK_02af8f44;
                    }
                  }
                  else if (uVar4 < 0x30fc) {
                    if (uVar4 < 0x3001) {
                      if (uVar4 == 0x2026) {
                        puVar3 = &UNK_02af8ed0;
                      }
                      else {
                        if (uVar4 != 0x3000) {
                          return 0x107;
                        }
                        puVar3 = &UNK_02af8ef0;
                      }
                    }
                    else if (uVar4 == 0x3001) {
                      puVar3 = &UNK_02af8ee4;
                    }
                    else if (uVar4 == 0x3002) {
                      puVar3 = &UNK_02af8ee8;
                    }
                    else {
                      if (uVar4 != 0x30fb) {
                        return 0x107;
                      }
                      puVar3 = &UNK_02af8ecc;
                    }
                  }
                  else if (uVar4 < 0xff01) {
                    if (uVar4 == 0x30fc) {
                      puVar3 = &UNK_02af8ebc;
                    }
                    else {
                      if (uVar4 != 0xe221) {
                        return 0x107;
                      }
                      puVar3 = &UNK_02af8ec4;
                    }
                  }
                  else if (uVar4 == 0xff01) {
                    puVar3 = &UNK_02af8ee0;
                  }
                  else if (uVar4 == 0xff1f) {
                    puVar3 = &UNK_02af8ed8;
                  }
                  else {
                    if (uVar4 != 0xff5e) {
                      return 0x107;
                    }
                    puVar3 = &UNK_02af8ec0;
                  }
                  uStack_14 = (uint)*(ushort *)(puVar3 + 2);
                }
              }
              else {
                uStack_14 = (uVar4 & 0xffff) - 0x2e5;
              }
            }
            else {
              uStack_14 = (uVar4 & 0xffff) - 0x305;
            }
            goto LAB_00c2f22c;
          }
          iVar2 = -0xfec0;
        }
        else {
          iVar2 = -0xfee0;
        }
        goto LAB_00c2f228;
      }
      uStack_14 = (uVar4 & 0xffff) + 0x20;
    }
    else {
      uStack_14 = uVar4 & 0xffff;
    }
  }
  else {
    iVar2 = -0x3040;
LAB_00c2f228:
    uStack_14 = iVar2 + (uint)(ushort)uVar5;
  }
LAB_00c2f22c:
  if (0x106 < uStack_14) {
    uStack_14 = 0x107;
  }
switchD_00c2f374_caseD_387:
  return uStack_14;
}

