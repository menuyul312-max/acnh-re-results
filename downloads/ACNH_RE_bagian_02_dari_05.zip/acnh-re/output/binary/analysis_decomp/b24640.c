
void FUN_00c24640(long param_1)

{
  if (*(int *)(param_1 + 0x48) == 7) {
    FUN_020067b0(param_1 + 0x40,6);
    return;
  }
  FUN_00c24660();
  return;
}

