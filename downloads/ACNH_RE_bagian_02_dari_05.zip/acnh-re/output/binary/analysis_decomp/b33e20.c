
void FUN_00c33e20(long param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  ulong uVar1;
  
  uVar1 = *puRam00000000033d2050;
  FUN_001c6030(uVar1);
  FUN_00c166c0(param_1,uVar1 & 0xffffffff,param_2,param_3,param_4,param_5);
  *(undefined4 *)(param_1 + 0x108) = param_2;
  return;
}

