
void FUN_00c30040(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c30048. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x40))();
  return;
}

