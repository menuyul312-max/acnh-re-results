
void FUN_00c2f830(long param_1)

{
  FUN_022ed130(param_1 + 8);
  return;
}

