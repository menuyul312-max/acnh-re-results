
void FUN_00c35460(long *param_1)

{
  long lVar1;
  long *plVar2;
  long *plVar3;
  
  lVar1 = lRam00000000033d96b0 + 0x10;
  *param_1 = lRam00000000033f5280 + 0x10;
  plVar3 = param_1 + 1;
  *plVar3 = lVar1;
  FUN_00123650(plVar3,param_1 + 0x1d,0x40);
  plVar2 = param_1 + 0x2d;
  if (param_1 + 0x2d <= (long *)((long)param_1 + 0xea)) {
    plVar2 = (long *)((long)param_1 + 0xea);
  }
  *plVar3 = lVar1;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  memset(param_1 + 0x1d,0,(long)plVar2 + (-0xe7 - (long)param_1) & 0xfffffffffffffffe);
  *param_1 = lRam00000000033f5288 + 0x10;
  return;
}

