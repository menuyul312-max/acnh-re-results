
void FUN_00c28f90(long param_1)

{
  long *plVar1;
  long *plVar2;
  
  plVar2 = (long *)(param_1 + 0x48);
  plVar1 = plVar2;
  (**(code **)(*plVar2 + 0x10))();
  if (((ulong)plVar1 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c28fc8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*plVar2)(plVar2);
    return;
  }
  return;
}

