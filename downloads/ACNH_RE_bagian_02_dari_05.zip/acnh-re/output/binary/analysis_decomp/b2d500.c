
void FUN_00c2d500(long param_1)

{
  FUN_01385c10(*(undefined8 *)(param_1 + 0x20));
  return;
}

