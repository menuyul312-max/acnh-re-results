
void FUN_00c3ad10(int *param_1)

{
  undefined2 uVar1;
  int iVar2;
  int *piVar3;
  char *pcVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  
  piVar3 = piRam00000000033f5320;
  pcVar4 = pcRam00000000033f5318;
  iVar2 = *param_1;
  do {
    piVar6 = param_1;
    if (iVar2 == 0) {
LAB_00c3ae58:
      piVar9 = (int *)0x0;
      FUN_01765e80();
      FUN_01765e10();
joined_r0x00c3ae50:
      uVar7 = (uint)piVar9;
      if (((ulong)piVar6 & 1) == 0) {
        FUN_00c3b930((ulong)piVar9 & 0xffffffff,0);
        if (0xc < uVar7) {
          uVar7 = 0;
        }
        uVar1 = (undefined2)uVar7;
      }
      else {
        FUN_00c3aed0((ulong)piVar9 & 0xffffffff,0);
        if (0xc < uVar7) {
          uVar7 = 0;
        }
        uVar1 = (undefined2)uVar7;
      }
      FUN_01765ea0();
      if ((uint)param_1 < *puRam00000000033f5338) {
        *(undefined2 *)(*(long *)(puRam00000000033f5338 + 2) + (long)(int)(uint)param_1 * 2) = uVar1
        ;
      }
      return;
    }
    piVar5 = param_1;
    if (*pcVar4 == '\0') {
      *pcVar4 = '\x01';
      piVar3[0] = -1;
      piVar3[1] = -1;
      piVar3[2] = -1;
      piVar3[3] = -1;
      piVar3[4] = -1;
      FUN_01765e80();
      if (piVar5 != (int *)0x0) goto LAB_00c3ad80;
LAB_00c3ae04:
      piVar9 = (int *)0x0;
LAB_00c3ae08:
      FUN_01765e80();
      FUN_01765e10();
      goto joined_r0x00c3ae50;
    }
    iVar2 = *piVar3;
    if (-1 < iVar2) {
      if ((uint *)((long)iVar2 + (long)param_1) != (uint *)0x0) {
        piVar9 = (int *)(ulong)*(uint *)((long)iVar2 + (long)param_1);
        FUN_01765e80();
        FUN_01765e10();
        goto joined_r0x00c3ae50;
      }
      goto LAB_00c3ae58;
    }
    if (iVar2 != -1) goto LAB_00c3ae58;
    FUN_01765e80();
    if (piVar5 == (int *)0x0) goto LAB_00c3ae04;
LAB_00c3ad80:
    piVar9 = piVar5;
    FUN_01765e60();
    if (piVar9 == (int *)0x0) goto LAB_00c3ae08;
    FUN_01765e50();
    *piVar3 = -2;
    if ((uint)piVar5 == 0) goto LAB_00c3ae58;
    uVar7 = 0;
    piVar8 = piVar9 + 1;
    while (piVar9[(ulong)uVar7 * 2] != -0x4188918f) {
      uVar7 = uVar7 + 1;
      piVar8 = piVar8 + 2;
      if ((uint)piVar5 <= uVar7) goto LAB_00c3ae58;
    }
    iVar2 = 0;
    if (*piVar8 != -1) {
      iVar2 = *piVar8;
    }
    *piVar3 = iVar2;
    iVar2 = *param_1;
  } while( true );
}

