
uint thunk_FUN_001b62b0(ushort *param_1)

{
  ushort uVar1;
  uint uVar2;
  byte *pbVar3;
  long lVar4;
  long lVar5;
  ulong uVar6;
  
  uVar1 = *param_1;
  uVar6 = (ulong)uVar1;
  if ((*pbRam00000000033d4b80 & 1) == 0) {
    pbVar3 = pbRam00000000033d4b80;
    __cxa_guard_acquire();
    uVar6 = (ulong)(uint)uVar1;
    if ((int)pbVar3 != 0) {
      FUN_001b55f0(puRam00000000033d4b88);
      __cxa_guard_release(pbRam00000000033d4b80);
      uVar6 = (ulong)(uint)uVar1;
    }
  }
  if (0 < (int)*puRam00000000033d4b88) {
    lVar5 = 0;
    do {
      if (*(int *)(*(long *)(puRam00000000033d4b88 + 2) + lVar5 * 4) == (int)(uVar6 >> 0xb)) {
        if ((int)lVar5 != -1) goto LAB_001b6318;
        break;
      }
      lVar5 = lVar5 + 1;
    } while (lVar5 < (int)*puRam00000000033d4b88);
  }
  lVar5 = 0;
LAB_001b6318:
  if (((*pbRam00000000033d4b80 & 1) == 0) &&
     (pbVar3 = pbRam00000000033d4b80, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
    FUN_001b55f0(puRam00000000033d4b88);
    __cxa_guard_release(pbRam00000000033d4b80);
  }
  lVar4 = (long)(int)(uint)lVar5;
  if (*puRam00000000033d4b88 <= (uint)lVar5) {
    lVar4 = 0;
  }
  uVar2 = *(int *)(*(long *)(puRam00000000033d4b88 + 2) + lVar4 * 4) - 1;
  return (uint)(uVar2 < 0xf) & 0x76d5U >> (ulong)(uVar2 & 0x1f);
}

