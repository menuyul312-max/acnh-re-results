
void _INIT_2652(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655140 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655178);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655144 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655148 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000365515c = 0xffff;
  uRam0000000003655158 = 0xffffffff;
  uRam0000000003655164 = 0;
  uRam0000000003655160 = 0;
  uRam000000000365514c = (undefined4)uVar2;
  uRam0000000003655150 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655168 = uVar2;
  uRam0000000003655170 = 0;
  return;
}

