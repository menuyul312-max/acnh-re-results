
uint FUN_00c2e6d0(ulong param_1,ulong param_2)

{
  ulong uVar1;
  ulong uVar2;
  undefined1 *puVar3;
  undefined1 *puVar4;
  uint uVar5;
  short asStack_448 [2];
  short asStack_444 [2];
  undefined1 auStack_440 [520];
  undefined1 auStack_238 [520];
  
  if (param_1 == param_2) {
LAB_00c2e7d0:
    uVar5 = 1;
  }
  else {
    uVar1 = param_1;
    FUN_001233a0();
    uVar2 = param_2;
    FUN_001233a0();
    if (uVar1 == uVar2) {
      uVar1 = param_1;
      FUN_001234a0();
      uVar2 = param_2;
      FUN_001234a0();
      if (uVar2 <= uVar1) goto LAB_00c2e7d0;
    }
    FUN_00bedcd0(auStack_238,0);
    FUN_001204c0(auStack_238,param_1);
    FUN_00bedcd0(auStack_440,0);
    FUN_001204c0(auStack_440,param_2);
    asStack_444[0] = 0;
    asStack_448[0] = 0;
    while( true ) {
      puVar3 = auStack_238;
      FUN_00120570(puVar3,asStack_444);
      puVar4 = auStack_440;
      FUN_00120570(puVar4,asStack_448);
      if (((ulong)puVar3 & 1) == 0) break;
      if (((ulong)puVar4 & 1) == 0) {
        uVar5 = 1;
        goto LAB_00c2e7e4;
      }
      if (asStack_444[0] != asStack_448[0]) {
        FUN_001204c0(auStack_440,param_2);
        FUN_00120570(auStack_440,asStack_448);
        if (asStack_444[0] != asStack_448[0]) {
          FUN_001204c0(auStack_440,param_2);
        }
      }
    }
    uVar5 = (uint)puVar4 ^ 1;
LAB_00c2e7e4:
    FUN_001219a0(auStack_440);
    FUN_001219a0(auStack_238);
  }
  return uVar5 & 1;
}

