
bool FUN_00c2adf0(undefined8 param_1,uint param_2)

{
  uint uVar1;
  
  FUN_00c2f6b0(param_1,param_2 & 1);
  uVar1 = (int)param_1 - 0xa4;
  if ((uVar1 < 0x3b) && ((1L << ((ulong)uVar1 & 0x3f) & 0x7c000000000000dU) != 0)) {
    return false;
  }
  return (int)param_1 != 0x108;
}

