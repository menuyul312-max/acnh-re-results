
long FUN_00c248d0(long param_1)

{
  return param_1 + 0x2478;
}

