
undefined8 FUN_00c24c40(undefined8 *param_1)

{
  return *param_1;
}

