
void _INIT_2651(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam00000000036550f8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655130);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036550fc = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655100 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655114 = 0xffff;
  uRam0000000003655110 = 0xffffffff;
  uRam000000000365511c = 0;
  uRam0000000003655118 = 0;
  uRam0000000003655104 = (undefined4)uVar2;
  uRam0000000003655108 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655120 = uVar2;
  uRam0000000003655128 = 0;
  return;
}

