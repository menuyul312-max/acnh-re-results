
uint FUN_00c31640(undefined8 param_1,ulong param_2,undefined8 *param_3)

{
  long lVar1;
  long lVar2;
  undefined1 uVar3;
  ulong uVar4;
  ulong uVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  uint uVar8;
  undefined1 auStack_158 [88];
  long lStack_100;
  undefined1 *puStack_f8;
  undefined4 uStack_f0;
  undefined1 auStack_ec [68];
  long lStack_a8;
  undefined1 *puStack_a0;
  undefined4 uStack_98;
  undefined1 auStack_94 [68];
  
  puStack_a0 = auStack_94;
  uStack_98 = 0x40;
  lVar1 = lRam00000000033d0670 + 0x10;
  lStack_a8 = lVar1;
  FUN_01a90780(&lStack_a8);
  uVar3 = *puRam00000000033d0660;
  *puStack_a0 = uVar3;
  uStack_f0 = 0x40;
  lVar2 = lRam00000000033d1298 + 0x10;
  puStack_f8 = auStack_ec;
  lStack_100 = lVar1;
  lStack_a8 = lVar2;
  FUN_01a90780(&lStack_100);
  *puStack_f8 = uVar3;
  uVar4 = param_2;
  lStack_100 = lVar2;
  FUN_00ba2650();
  if ((int)uVar4 == 0) {
    uVar4 = param_2;
    FUN_00bb6710();
    if ((uint)uVar4 < 0x26) {
      uVar5 = uVar4;
      FUN_00b6cf00();
      uVar7 = *(undefined8 *)
               (uVar5 + (-(uVar4 >> 0x1f & 1) & 0xfffffff800000000 | (uVar4 & 0xffffffff) << 3));
    }
    else {
      uVar7 = 0x2ab9d8f;
    }
    FUN_01a90820(&lStack_a8,&UNK_02a473bd,uVar7);
    FUN_00bb6620(param_2,&lStack_100);
  }
  else {
    FUN_00ba2710(param_2,&lStack_a8);
    FUN_00ba2870(param_2,&lStack_100);
  }
  uVar7 = param_1;
  FUN_00c30040(param_1);
  puVar6 = param_3;
  (**(code **)*param_3)(param_3,uVar7,&lStack_a8,&lStack_100,1);
  uVar8 = (uint)puVar6;
  uVar4 = param_2;
  FUN_00b9cf00(param_2);
  FUN_00124340(uVar7,uVar4 & 0xffffffff);
  uVar4 = param_2;
  FUN_00bab800();
  if ((uVar4 & 1) != 0) {
    (**(code **)(lStack_100 + 0x18))(&lStack_100);
    FUN_0013f520(auStack_158,&UNK_02accadb,puStack_f8);
    uVar7 = param_1;
    FUN_00c30060(param_1);
    (**(code **)*param_3)(param_3,uVar7,&lStack_a8,auStack_158,1);
    uVar8 = uVar8 & (uint)param_3;
    FUN_00bab850();
    if ((int)param_2 == 1) {
      uVar7 = 1;
    }
    else {
      uVar7 = 2;
    }
    FUN_00c2ffd0(param_1,uVar7);
  }
  return uVar8 & 1;
}

