
bool FUN_00c2c340(long param_1)

{
  return *(int *)(param_1 + 0x28) == 2;
}

