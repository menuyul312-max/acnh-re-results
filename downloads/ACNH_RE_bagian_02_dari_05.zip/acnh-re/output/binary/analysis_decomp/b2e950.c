
undefined4 FUN_00c2e950(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = param_1 % 10;
  param_1 = param_1 % 100;
  if (iVar1 != 1 || param_1 == 0xb) {
    uVar2 = 1;
    if (((iVar1 != 2 || param_1 == 0xc) && (iVar1 != 3 || param_1 == 0xd)) &&
       (uVar2 = 1, param_1 == 0xe || iVar1 != 4)) {
      uVar2 = 2;
    }
    return uVar2;
  }
  return 0;
}

