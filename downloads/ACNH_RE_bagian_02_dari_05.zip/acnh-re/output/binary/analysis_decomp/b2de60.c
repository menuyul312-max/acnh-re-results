
void FUN_00c2de60(undefined4 *param_1)

{
  *param_1 = 0;
  *(undefined8 *)(param_1 + 3) = 0;
  *(undefined8 *)(param_1 + 1) = 0x3f80000000000000;
  return;
}

