
void _INIT_2650(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam00000000036550b0 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36550e8);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036550b4 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam00000000036550b8 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036550cc = 0xffff;
  uRam00000000036550c8 = 0xffffffff;
  uRam00000000036550d4 = 0;
  uRam00000000036550d0 = 0;
  uRam00000000036550bc = (undefined4)uVar2;
  uRam00000000036550c0 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036550d8 = uVar2;
  uRam00000000036550e0 = 0;
  return;
}

