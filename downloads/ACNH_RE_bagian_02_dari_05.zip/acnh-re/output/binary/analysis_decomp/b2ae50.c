
bool FUN_00c2ae50(int *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1 - 0xa4;
  if (uVar1 < 0x3b && (1L << ((ulong)uVar1 & 0x3f) & 0x7c000000000000dU) != 0) {
    return false;
  }
  return *param_1 != 0x108;
}

