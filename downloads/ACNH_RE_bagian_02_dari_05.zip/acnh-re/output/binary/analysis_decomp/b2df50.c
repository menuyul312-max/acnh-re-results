
void _INIT_2642(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654e40 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654e78);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654e44 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654e48 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654e5c = 0xffff;
  uRam0000000003654e58 = 0xffffffff;
  uRam0000000003654e64 = 0;
  uRam0000000003654e60 = 0;
  uRam0000000003654e4c = (undefined4)uVar2;
  uRam0000000003654e50 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654e68 = uVar2;
  uRam0000000003654e70 = 0;
  return;
}

