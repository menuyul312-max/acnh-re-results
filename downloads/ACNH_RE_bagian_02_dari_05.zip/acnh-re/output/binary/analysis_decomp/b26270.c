
void FUN_00c26270(undefined8 *param_1)

{
  param_1[9] = 0xffffffff;
  param_1[10] = 0xffffffff;
  FUN_02006750(param_1 + 8);
  FUN_00c2b070(*param_1);
  return;
}

