
uint FUN_001b2730(undefined4 param_1,undefined8 param_2,undefined8 *param_3)

{
  long lStack_28;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  lStack_28 = lRam00000000033d4b00 + 0x10;
  uStack_20 = *param_3;
  uStack_18 = *(undefined4 *)(param_3 + 1);
  uStack_14 = param_1;
  FUN_001b2780(param_2,&lStack_28);
  return (uint)param_2 & 1;
}

