
void FUN_00c262a0(undefined8 *param_1)

{
  FUN_02006900(param_1 + 8);
  FUN_00c2a650(param_1[7]);
  *(undefined2 *)((long)param_1 + 0x244c) = 0;
  if (-10000 < *(int *)(param_1 + 0x481)) {
    *(int *)(param_1 + 0x481) = *(int *)(param_1 + 0x481) + -1;
  }
  (**(code **)((ulong)*(uint *)(param_1 + 0x489) * 0x10 + 0x31ce868))
            ((long)param_1 +
             (*(long *)((ulong)*(uint *)(param_1 + 0x489) * 0x10 + 0x31ce870) >> 1) + 0x2400);
  FUN_00c2bd60(param_1[4]);
  FUN_00c2b400(*param_1);
  return;
}

