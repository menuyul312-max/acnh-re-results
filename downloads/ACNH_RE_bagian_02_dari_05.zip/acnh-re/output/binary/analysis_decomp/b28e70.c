
void FUN_00c28e70(long param_1)

{
  *(undefined8 *)(param_1 + 0x20) = 0;
  return;
}

