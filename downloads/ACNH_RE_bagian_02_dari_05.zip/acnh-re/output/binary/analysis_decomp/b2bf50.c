
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c2bf50(long *param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  bool bVar5;
  long lVar6;
  long *plVar7;
  long *plVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  uint auStack_58 [2];
  long lStack_50;
  undefined4 uStack_48;
  
  lVar6 = *param_1;
  FUN_00c24b20();
  uStack_68 = 0;
  uStack_60 = 0x3f80000000000000;
  uStack_78 = 0;
  uStack_70 = 0x3f80000000000000;
  if (lVar6 == 0) {
    uStack_68 = 0x3f8000003f800000;
    uStack_60 = 0x3f8000003f800000;
    uStack_78 = 0x3f0000003f000000;
    uStack_70 = 0x3f8000003f000000;
    plVar8 = *(long **)(param_1[4] + 0x218);
    uVar1 = uStack_68;
    uVar2 = uStack_60;
    uVar3 = uStack_78;
    uVar4 = uStack_70;
  }
  else {
    FUN_00c29140();
    plVar8 = *(long **)(param_1[4] + 0x218);
    uVar1 = uStack_68;
    uVar2 = uStack_60;
    uVar3 = uStack_78;
    uVar4 = uStack_70;
  }
  if (plVar8 != (long *)0x0) {
    plVar7 = plVar8;
    FUN_0138b7e0();
    FUN_0138b890();
    uStack_68._0_4_ = (float)uVar1;
    powf((float)uStack_68,0x40100000);
    uStack_68._4_4_ = (float)((ulong)uVar1 >> 0x20);
    powf(uStack_68._4_4_,0x40100000);
    uStack_60._0_4_ = (float)uVar2;
    powf((float)uStack_60,0x40100000);
    uStack_60._4_4_ = (float)((ulong)uVar2 >> 0x20);
    uStack_78._0_4_ = (float)uVar3;
    powf((float)uStack_78,0x40100000);
    uStack_78._4_4_ = (float)((ulong)uVar3 >> 0x20);
    powf(uStack_78._4_4_,0x40100000);
    uStack_70._0_4_ = (float)uVar4;
    powf((float)uStack_70,0x40100000);
    uStack_70._4_4_ = (float)((ulong)uVar4 >> 0x20);
    if (plVar8 != (long *)0x0) {
      fVar16 = (float)uStack_78;
      if (1.0 < (float)uStack_78) {
        fVar16 = 1.0;
      }
      fVar13 = 0.0;
      if (0.0 <= (float)uStack_78) {
        fVar13 = fVar16 * _UNK_02ad6060;
      }
      bVar5 = 0.0 <= uStack_78._4_4_;
      if (1.0 < uStack_78._4_4_) {
        uStack_78._4_4_ = 1.0;
      }
      fVar16 = 0.0;
      if (bVar5) {
        fVar16 = uStack_78._4_4_ * _UNK_02ad6060;
      }
      bVar5 = 0.0 <= (float)uStack_70;
      if (1.0 < (float)uStack_70) {
        uStack_70._0_4_ = 1.0;
      }
      fVar15 = 0.0;
      if (bVar5) {
        fVar15 = (float)uStack_70 * _UNK_02ad6060;
      }
      bVar5 = 0.0 <= uStack_70._4_4_;
      if (1.0 < uStack_70._4_4_) {
        uStack_70._4_4_ = 1.0;
      }
      fVar9 = 0.0;
      if (bVar5) {
        fVar9 = uStack_70._4_4_ * _UNK_02ad6060;
      }
      auStack_58[0] =
           (int)fVar13 << 0x18 | ((int)fVar15 & 0xffU) << 8 | ((int)fVar16 & 0xffU) << 0x10 |
           (int)fVar9;
      lStack_50 = lRam00000000033f51d8 + 0x10;
      uStack_48 = 0x1a;
      (**(code **)(*plVar8 + 0x18))(plVar8,&lStack_50);
      (**(code **)(plVar8[3] + 0x1b8))(plVar8[1],1,1,0,auStack_58);
    }
    fVar16 = _UNK_02ad6060;
    if ((plVar7 != (long *)0x0) && (plVar8 = (long *)plVar7[9], plVar8 != (long *)0x0)) {
      fVar9 = 0.0;
      fVar13 = 0.0;
      fVar15 = (float)uStack_68;
      if (1.0 < (float)uStack_68) {
        fVar15 = 1.0;
      }
      fVar12 = fVar9;
      if (0.0 <= (float)uStack_68) {
        fVar12 = fVar15 * _UNK_02ad6060;
      }
      fVar15 = uStack_68._4_4_;
      if (1.0 < uStack_68._4_4_) {
        fVar15 = 1.0;
      }
      fVar10 = fVar13;
      if (0.0 <= uStack_68._4_4_) {
        fVar10 = fVar15 * _UNK_02ad6060;
      }
      fVar15 = (float)uStack_60;
      if (1.0 < (float)uStack_60) {
        fVar15 = 1.0;
      }
      fVar14 = fVar9;
      if (0.0 <= (float)uStack_60) {
        fVar14 = fVar15 * _UNK_02ad6060;
      }
      fVar15 = uStack_60._4_4_;
      if (1.0 < uStack_60._4_4_) {
        fVar15 = 1.0;
      }
      fVar11 = fVar13;
      if (0.0 <= uStack_60._4_4_) {
        fVar11 = fVar15 * _UNK_02ad6060;
      }
      auStack_58[0] =
           (int)fVar12 << 0x18 | ((int)fVar10 & 0xffU) << 0x10 | ((int)fVar14 & 0xffU) << 8 |
           (int)fVar11;
      uStack_48 = 0x30;
      lVar6 = lRam00000000033f51d8 + 0x10;
      lStack_50 = lVar6;
      (**(code **)(*plVar8 + 0x18))(plVar8,&lStack_50);
      (**(code **)(plVar8[3] + 0x318))(plVar8[1],0,0,auStack_58);
      bVar5 = 0.0 <= (float)uStack_68;
      if (1.0 < (float)uStack_68) {
        uStack_68._0_4_ = 1.0;
      }
      fVar15 = fVar9;
      if (bVar5) {
        fVar15 = (float)uStack_68 * fVar16;
      }
      bVar5 = 0.0 <= uStack_68._4_4_;
      if (1.0 < uStack_68._4_4_) {
        uStack_68._4_4_ = 1.0;
      }
      fVar12 = fVar13;
      if (bVar5) {
        fVar12 = uStack_68._4_4_ * fVar16;
      }
      bVar5 = 0.0 <= (float)uStack_60;
      if (1.0 < (float)uStack_60) {
        uStack_60._0_4_ = 1.0;
      }
      if (bVar5) {
        fVar9 = (float)uStack_60 * fVar16;
      }
      fVar10 = uStack_60._4_4_;
      if (1.0 < uStack_60._4_4_) {
        fVar10 = 1.0;
      }
      if (0.0 <= uStack_60._4_4_) {
        fVar13 = fVar10 * fVar16;
      }
      auStack_58[0] =
           (int)fVar15 << 0x18 | ((int)fVar12 & 0xffU) << 0x10 | ((int)fVar9 & 0xffU) << 8 |
           (int)fVar13;
      uStack_48 = 0x30;
      lStack_50 = lVar6;
      (**(code **)(*plVar8 + 0x18))(plVar8,&lStack_50);
      (**(code **)(plVar8[3] + 0x318))(plVar8[1],1,0,auStack_58);
    }
  }
  return;
}

