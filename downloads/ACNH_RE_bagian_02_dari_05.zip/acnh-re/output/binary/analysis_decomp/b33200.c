
void FUN_00c33200(long *param_1,uint *param_2,long param_3)

{
  long *plVar1;
  ulong uVar2;
  long lVar3;
  long lVar4;
  long lStack_68;
  undefined *puStack_60;
  long lStack_50;
  long lStack_48;
  
  lVar3 = lRam00000000033f5250 + 0x10;
  *param_1 = lVar3;
  FUN_00123650(param_1,param_1 + 0x1c,0x17);
  *param_1 = lVar3;
  *(undefined8 *)((long)param_1 + 0x106) = 0;
  param_1[0x1c] = 0;
  uVar2 = (long)param_1 + 0x10eU;
  if ((long)param_1 + 0x10eU <= (long)param_1 + 0xe2U) {
    uVar2 = (long)param_1 + 0xe2U;
  }
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  memset(param_1 + 0x1c,0,(uVar2 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  plVar1 = param_1;
  FUN_00c330e0(param_1,param_2);
  if (((ulong)plVar1 & 1) == 0) {
    uVar2 = (ulong)*param_2;
    FUN_00ff2ff0();
    if (uVar2 != 0) {
      FUN_00fe9350(&lStack_68,uVar2,1);
      lStack_68 = lRam00000000033f5258 + 0x10;
      lVar3 = *(long *)((long)puStack_60 + 0x10) + *(long *)((long)puStack_60 + 8);
      FUN_010e5640();
      lStack_50 = CONCAT44(lStack_50._4_4_,0x16);
      lStack_48 = lVar3;
      FUN_010e4670(param_1,&lStack_50);
      FUN_00fe93d0(&lStack_68);
    }
    plVar1 = param_1;
    FUN_001232e0();
    if ((param_3 != 0) && (((ulong)plVar1 & 1) != 0)) {
      lVar4 = *plRam00000000033d3788;
      lVar3 = param_3;
      FUN_00101bf0(param_3,0);
      lStack_68 = CONCAT44(lStack_68._4_4_,(int)lVar3);
      FUN_00189ce0(lVar4,&lStack_68);
      if (lVar4 != 0) {
        lStack_68 = lRam00000000033d0668 + 0x10;
        puStack_60 = &UNK_02a9c831;
        lStack_50 = lStack_68;
        lStack_48 = param_3;
        FUN_00123860(param_1,&lStack_68,&lStack_50,0);
      }
    }
  }
  return;
}

