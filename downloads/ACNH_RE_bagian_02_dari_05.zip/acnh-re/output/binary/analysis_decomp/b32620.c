
void FUN_00c32620(long *param_1,long param_2,long param_3)

{
  long lVar1;
  long *plVar2;
  undefined8 uStack_68;
  long lStack_60;
  undefined4 auStack_50 [2];
  long lStack_48;
  
  lVar1 = lRam00000000033f4800 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0x10);
  plVar2 = param_1 + 0x20;
  if (param_1 + 0x20 <= (long *)((long)param_1 + 0xe2)) {
    plVar2 = (long *)((long)param_1 + 0xe2);
  }
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  *param_1 = lVar1;
  memset(param_1 + 0x1c,0,(long)plVar2 + (-0xdf - (long)param_1) & 0xfffffffffffffffe);
  FUN_00ff1f30(param_2,param_3);
  if (param_2 != 0) {
    FUN_00fe9350(&uStack_68,param_2,1);
    uStack_68 = lRam00000000033d9ab0 + 0x10;
    auStack_50[0] = 10;
    lStack_48 = *(long *)(lStack_60 + 0x10) + *(long *)(lStack_60 + 8) + 0x138;
    FUN_010e4670(param_1,auStack_50);
    FUN_00fe93d0(&uStack_68);
    plVar2 = param_1;
    FUN_001232e0();
    if (((ulong)plVar2 & 1) == 0) goto LAB_00c32734;
  }
  uStack_68 = CONCAT44(uStack_68._4_4_,10);
  lStack_60 = param_3 + 0x20;
  FUN_010e4670(param_1,&uStack_68);
LAB_00c32734:
  FUN_001234f0(param_1);
  FUN_00121d40();
  return;
}

