
void FUN_00c2dec0(undefined8 *param_1)

{
  *param_1 = 0;
  return;
}

