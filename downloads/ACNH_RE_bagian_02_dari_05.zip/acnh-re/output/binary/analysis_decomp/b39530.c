
void FUN_00c39530(int *param_1,uint param_2,int param_3)

{
  long lVar1;
  int iVar2;
  char *pcVar3;
  undefined8 *puVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  
  puVar4 = puRam00000000033f5320;
  pcVar3 = pcRam00000000033f5318;
  if (*param_1 != 0) {
    lVar1 = 0;
    if (param_2 < 5) {
      lVar1 = (long)(int)param_2;
    }
    while( true ) {
      if (*pcVar3 == '\0') {
        *pcVar3 = '\x01';
        *puVar4 = 0xffffffffffffffff;
        puVar4[1] = 0xffffffffffffffff;
        *(undefined4 *)(puVar4 + 2) = 0xffffffff;
      }
      iVar2 = *(int *)((long)puVar4 + lVar1 * 4);
      if ((((-1 < iVar2) || (iVar2 != -1)) ||
          (piVar5 = param_1, FUN_01765e80(), piVar5 == (int *)0x0)) ||
         (piVar6 = piVar5, FUN_01765e60(), piVar6 == (int *)0x0)) break;
      FUN_01765e50();
      *(undefined4 *)((long)puVar4 + lVar1 * 4) = 0xfffffffe;
      if ((uint)piVar5 == 0) {
        return;
      }
      uVar7 = 0;
      piVar8 = piVar6 + 1;
      while (piVar6[(ulong)uVar7 * 2] != param_3) {
        uVar7 = uVar7 + 1;
        piVar8 = piVar8 + 2;
        if ((uint)piVar5 <= uVar7) {
          return;
        }
      }
      iVar2 = 0;
      if (*piVar8 != -1) {
        iVar2 = *piVar8;
      }
      *(int *)((long)puVar4 + lVar1 * 4) = iVar2;
      if (*param_1 == 0) {
        return;
      }
    }
  }
  return;
}

