
void thunk_FUN_001249f0(void)

{
  return;
}

