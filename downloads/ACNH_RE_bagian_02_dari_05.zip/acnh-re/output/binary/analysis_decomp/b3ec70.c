
void FUN_00c3ec70(undefined8 *param_1)

{
  long lVar1;
  long lVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  char cVar6;
  long lVar7;
  long lVar8;
  long lVar9;
  undefined8 *puVar10;
  long lVar11;
  ulong uVar12;
  undefined8 uVar13;
  undefined *puVar14;
  long *plVar15;
  
  puVar10 = puRam00000000033d06b0;
  uVar4 = *(undefined4 *)(puRam00000000033d06b0 + 1);
  *param_1 = *puRam00000000033d06b0;
  *(undefined4 *)(param_1 + 1) = uVar4;
  *(undefined4 *)((long)param_1 + 0xc) = 0;
  FUN_010589b0(param_1 + 2,uRam00000000033d25e0);
  lVar7 = lRam00000000033d0670;
  lVar1 = lRam00000000033d0670 + 0x10;
  plVar15 = param_1 + 3;
  *plVar15 = lVar1;
  param_1[4] = (long)param_1 + 0x2c;
  *(undefined4 *)(param_1 + 5) = 0x20;
  FUN_01a90780(plVar15);
  lVar8 = lRam00000000033d0678;
  puVar14 = (undefined *)param_1[4];
  *plVar15 = lRam00000000033d0678 + 0x10;
  if (puVar14 != &UNK_02a3f278) {
    cVar5 = *pcRam00000000033d0660;
    uVar12 = 0;
    cVar6 = UNK_02a3f278;
    while (cVar6 != cVar5) {
      if (uVar12 >> 0x13 != 0) {
        uVar12 = 0;
        break;
      }
      if ((&UNK_02a3f279)[uVar12] == cVar5) {
        uVar12 = uVar12 + 1;
        break;
      }
      cVar6 = (&UNK_02a3f27a)[uVar12];
      uVar12 = uVar12 + 2;
    }
    iVar3 = (int)uVar12;
    if (*(int *)(param_1 + 5) <= (int)uVar12) {
      iVar3 = *(int *)(param_1 + 5) + -1;
    }
    memcpy(puVar14,&UNK_02a3f278,(long)iVar3);
    puVar14[iVar3] = cVar5;
  }
  lVar9 = lRam00000000033d0680;
  plVar15 = param_1 + 10;
  *plVar15 = lVar1;
  param_1[0xb] = (long)param_1 + 100;
  *(undefined4 *)(param_1 + 0xc) = 8;
  param_1[3] = lVar9 + 0x10;
  FUN_01a90780(plVar15);
  lVar1 = lRam00000000033d9510;
  *plVar15 = lRam00000000033d9510 + 0x10;
  puVar14 = (undefined *)param_1[0xb];
  if (puVar14 != &UNK_02a3f278) {
    cVar5 = *pcRam00000000033d0660;
    uVar12 = 0;
    cVar6 = UNK_02a3f278;
    while (cVar6 != cVar5) {
      if (uVar12 >> 0x13 != 0) {
        uVar12 = 0;
        break;
      }
      if ((&UNK_02a3f279)[uVar12] == cVar5) {
        uVar12 = uVar12 + 1;
        break;
      }
      cVar6 = (&UNK_02a3f27a)[uVar12];
      uVar12 = uVar12 + 2;
    }
    iVar3 = (int)uVar12;
    if (*(int *)(param_1 + 0xc) <= (int)uVar12) {
      iVar3 = *(int *)(param_1 + 0xc) + -1;
    }
    memcpy(puVar14,&UNK_02a3f278,(long)iVar3);
    puVar14[iVar3] = cVar5;
  }
  lVar11 = lRam00000000033d25e8;
  lVar2 = lRam00000000033d25e8 + 0x10;
  plVar15 = param_1 + 0xe;
  *plVar15 = lVar7 + 0x10;
  param_1[0xf] = (long)param_1 + 0x84;
  param_1[10] = lVar2;
  *(undefined4 *)(param_1 + 0x10) = 0x20;
  FUN_01a90780(plVar15);
  *plVar15 = lVar8 + 0x10;
  puVar14 = (undefined *)param_1[0xf];
  if (puVar14 != &UNK_02a3f278) {
    cVar5 = *pcRam00000000033d0660;
    uVar12 = 0;
    cVar6 = UNK_02a3f278;
    while (cVar6 != cVar5) {
      if (uVar12 >> 0x13 != 0) {
        uVar12 = 0;
        break;
      }
      if ((&UNK_02a3f279)[uVar12] == cVar5) {
        uVar12 = uVar12 + 1;
        break;
      }
      cVar6 = (&UNK_02a3f27a)[uVar12];
      uVar12 = uVar12 + 2;
    }
    iVar3 = (int)uVar12;
    if (*(int *)(param_1 + 0x10) <= (int)uVar12) {
      iVar3 = *(int *)(param_1 + 0x10) + -1;
    }
    memcpy(puVar14,&UNK_02a3f278,(long)iVar3);
    puVar14[iVar3] = cVar5;
  }
  plVar15 = param_1 + 0x15;
  *plVar15 = lVar7 + 0x10;
  param_1[0xe] = lVar9 + 0x10;
  param_1[0x16] = (long)param_1 + 0xbc;
  *(undefined4 *)(param_1 + 0x17) = 8;
  FUN_01a90780(plVar15);
  *plVar15 = lVar1 + 0x10;
  puVar14 = (undefined *)param_1[0x16];
  if (puVar14 != &UNK_02a3f278) {
    cVar5 = *pcRam00000000033d0660;
    uVar12 = 0;
    cVar6 = UNK_02a3f278;
    while (cVar6 != cVar5) {
      if (uVar12 >> 0x13 != 0) {
        uVar12 = 0;
        break;
      }
      if ((&UNK_02a3f279)[uVar12] == cVar5) {
        uVar12 = uVar12 + 1;
        break;
      }
      cVar6 = (&UNK_02a3f27a)[uVar12];
      uVar12 = uVar12 + 2;
    }
    iVar3 = (int)uVar12;
    if (*(int *)(param_1 + 0x17) <= (int)uVar12) {
      iVar3 = *(int *)(param_1 + 0x17) + -1;
    }
    memcpy(puVar14,&UNK_02a3f278,(long)iVar3);
    puVar14[iVar3] = cVar5;
  }
  param_1[0x15] = lVar11 + 0x10;
  *(undefined4 *)(param_1 + 0x19) = 0;
  *(undefined2 *)((long)param_1 + 0xcc) = 0;
  uVar13 = *puVar10;
  *(undefined4 *)(param_1 + 0x1b) = *(undefined4 *)(puVar10 + 1);
  param_1[0x1a] = uVar13;
  uVar13 = *puVar10;
  *(undefined4 *)((long)param_1 + 0xe4) = *(undefined4 *)(puVar10 + 1);
  *(undefined8 *)((long)param_1 + 0xdc) = uVar13;
  return;
}

