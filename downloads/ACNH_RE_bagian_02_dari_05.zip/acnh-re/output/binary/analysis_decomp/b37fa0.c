
/* WARNING: Type propagation algorithm not settling */

void FUN_00c37fa0(long param_1,undefined8 *param_2,uint *param_3)

{
  int *piVar1;
  ushort uVar2;
  int iVar3;
  undefined8 *puVar4;
  long lVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  ulong uVar9;
  undefined2 uVar10;
  uint uVar11;
  int *piVar12;
  uint uVar13;
  ulong uVar14;
  uint *puVar15;
  uint auStack_80 [2];
  long lStack_78;
  long lStack_70;
  
  if (param_2 != (undefined8 *)0x0) {
    *param_2 = 0;
    lVar5 = param_1;
    FUN_00fecf00();
    if (lVar5 != 0) {
      FUN_00fe9350(&lStack_78,lVar5 + 0x20a168,1);
      puVar4 = puRam00000000033f5320;
      uVar13 = 0;
      piVar1 = (int *)(param_1 + 8);
      lStack_78 = lRam00000000033d8a08 + 0x10;
      piVar6 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
      puVar15 = puRam00000000033f5338;
      if (0 < (int)*(uint *)(param_1 + 0x1c8)) goto LAB_00c38068;
LAB_00c3803c:
      piVar6 = piVar1;
      FUN_01766670();
      if (piVar6 == (int *)0x0) goto LAB_00c38068;
      FUN_01765e30();
      if (uVar13 < (uint)piVar6) {
        do {
          piVar6 = piVar1;
          FUN_00c38330(piVar1,uVar13);
          if (piVar6 != (int *)0x0) {
            piVar7 = piVar6;
            FUN_01765ea0();
            if ((*puVar15 <= (uint)piVar7) ||
               (uVar2 = *(ushort *)(*(long *)(puVar15 + 2) + (long)(int)(uint)piVar7 * 2),
               auStack_80[0] = (uint)uVar2, 0xc < uVar2)) {
              auStack_80[0] = 0;
            }
            if (auStack_80[0] == *param_3) {
              if (*piVar6 != 0) {
                do {
                  piVar7 = piVar6;
                  if (*pcRam00000000033f5318 == '\0') {
                    *pcRam00000000033f5318 = '\x01';
                    *puVar4 = 0xffffffffffffffff;
                    puVar4[1] = 0xffffffffffffffff;
                    *(undefined4 *)(puVar4 + 2) = 0xffffffff;
                    FUN_01765e80();
                  }
                  else {
                    iVar3 = *(int *)(puVar4 + 1);
                    if (-1 < iVar3) {
                      if ((undefined2 *)((long)iVar3 + (long)piVar6) != (undefined2 *)0x0) {
                        uVar10 = *(undefined2 *)((long)iVar3 + (long)piVar6);
                        goto LAB_00c38194;
                      }
                      break;
                    }
                    if (iVar3 != -1) break;
                    FUN_01765e80();
                  }
                  puVar15 = puRam00000000033f5338;
                  if ((piVar7 == (int *)0x0) ||
                     (piVar8 = piVar7, FUN_01765e60(), puVar15 = puRam00000000033f5338,
                     piVar8 == (int *)0x0)) break;
                  FUN_01765e50();
                  *(undefined4 *)(puVar4 + 1) = 0xfffffffe;
                  puVar15 = puRam00000000033f5338;
                  if ((uint)piVar7 == 0) break;
                  uVar11 = 0;
                  piVar12 = piVar8 + 1;
                  while (piVar8[(ulong)uVar11 * 2] != -0x489482c9) {
                    uVar11 = uVar11 + 1;
                    piVar12 = piVar12 + 2;
                    if ((uint)piVar7 <= uVar11) goto LAB_00c38190;
                  }
                  iVar3 = 0;
                  if (*piVar12 != -1) {
                    iVar3 = *piVar12;
                  }
                  *(int *)(puVar4 + 1) = iVar3;
                  puVar15 = puRam00000000033f5338;
                  if (*piVar6 == 0) break;
                } while( true );
              }
LAB_00c38190:
              uVar10 = 0xfffe;
LAB_00c38194:
              uVar14 = *(long *)(lStack_70 + 0x10) + *(long *)(lStack_70 + 8);
              FUN_010588a0(auStack_80,uVar10);
              FUN_01077f60(uVar14,auStack_80);
              if ((uVar14 & 1) != 0) {
                iVar3 = *piVar6;
                while (iVar3 != 0) {
                  piVar7 = piVar6;
                  if (*pcRam00000000033f5318 != '\0') {
                    iVar3 = *(int *)((long)puVar4 + 0xc);
                    if (iVar3 < 0) {
                      if (iVar3 == -1) {
                        FUN_01765e80();
                        if (piVar7 != (int *)0x0) goto LAB_00c381ec;
LAB_00c38284:
                        puVar15 = puRam00000000033f5338;
                        uVar14 = 0;
                        uVar9 = 0;
                        FUN_00981a00();
                        goto joined_r0x00c382ec;
                      }
                    }
                    else if ((ushort *)((long)iVar3 + (long)piVar6) != (ushort *)0x0) {
                      uVar14 = (ulong)*(ushort *)((long)iVar3 + (long)piVar6);
                      uVar9 = uVar14;
                      FUN_00981a00();
                      goto joined_r0x00c382ec;
                    }
                    break;
                  }
                  *pcRam00000000033f5318 = '\x01';
                  *puVar4 = 0xffffffffffffffff;
                  puVar4[1] = 0xffffffffffffffff;
                  *(undefined4 *)(puVar4 + 2) = 0xffffffff;
                  FUN_01765e80();
                  if (piVar7 == (int *)0x0) goto LAB_00c38284;
LAB_00c381ec:
                  piVar8 = piVar7;
                  FUN_01765e60();
                  if (piVar8 == (int *)0x0) goto LAB_00c38284;
                  FUN_01765e50();
                  *(undefined4 *)((long)puVar4 + 0xc) = 0xfffffffe;
                  if ((uint)piVar7 == 0) goto LAB_00c38284;
                  uVar11 = 0;
                  piVar12 = piVar8 + 1;
                  while (piVar8[(ulong)uVar11 * 2] != -0x2112f64) {
                    uVar11 = uVar11 + 1;
                    piVar12 = piVar12 + 2;
                    if ((uint)piVar7 <= uVar11) goto LAB_00c38284;
                  }
                  iVar3 = 0;
                  if (*piVar12 != -1) {
                    iVar3 = *piVar12;
                  }
                  *(int *)((long)puVar4 + 0xc) = iVar3;
                  puVar15 = puRam00000000033f5338;
                  iVar3 = *piVar6;
                }
                uVar14 = 0;
                uVar9 = 0;
                FUN_00981a00();
joined_r0x00c382ec:
                if (((uVar9 & 1) != 0) && ((uint)uVar14 < 0x40)) {
                  *(byte *)((long)param_2 + (uVar14 >> 3)) =
                       *(byte *)((long)param_2 + (uVar14 >> 3)) |
                       (byte)(1 << (ulong)((uint)uVar14 & 7));
                }
              }
            }
          }
          uVar13 = uVar13 + 1;
          piVar6 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
          if ((int)*(uint *)(param_1 + 0x1c8) < 1) goto LAB_00c3803c;
LAB_00c38068:
          if ((uint)piVar6 <= uVar13) break;
        } while( true );
      }
      FUN_00fe93d0(&lStack_78);
    }
  }
  return;
}

