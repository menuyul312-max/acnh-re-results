
undefined1 FUN_00c1d9e0(long param_1,undefined8 param_2,undefined8 param_3)

{
  *(undefined1 *)(param_1 + 0x240) = 0;
  *(undefined8 *)(param_1 + 0x238) = param_3;
  FUN_00122110(param_1 + 0x210);
  FUN_0011e470(param_1);
  FUN_0011e520(param_1,param_2);
  FUN_0011e660(param_1);
  FUN_00c1da40(param_1);
  return *(undefined1 *)(param_1 + 0x240);
}

