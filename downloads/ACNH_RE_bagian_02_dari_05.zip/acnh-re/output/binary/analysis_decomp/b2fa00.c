
void FUN_00c2fa00(int *param_1)

{
  int *piVar1;
  int *piVar2;
  byte *pbVar3;
  int iVar4;
  
  iVar4 = *param_1;
  if (iVar4 == 1) {
    FUN_00c2fb10(param_1);
    iVar4 = *param_1;
  }
  if (iVar4 == 2) {
    piVar2 = param_1 + 2;
    piVar1 = piVar2;
    FUN_022ed810(piVar2,0);
    if (((ulong)piVar1 & 1) != 0) {
      piVar1 = piVar2;
      FUN_022ed3c0();
      if (((ulong)piVar1 & 1) == 0) {
LAB_00c2faf0:
        iVar4 = 4;
      }
      else {
        FUN_022ed300();
        if (((*pbRam00000000033f5220 & 1) == 0) &&
           (pbVar3 = pbRam00000000033f5220, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
          *plRam00000000033f5228 = lRam00000000033d4b48 + 0x10;
          __cxa_guard_release(pbRam00000000033f5220);
          if (piVar2 != (int *)0x0) goto LAB_00c2fa70;
LAB_00c2faec:
          param_1[0x10] = 0;
          param_1[0x11] = 0;
          goto LAB_00c2faf0;
        }
        if (piVar2 == (int *)0x0) goto LAB_00c2faec;
LAB_00c2fa70:
        piVar1 = piVar2;
        (*(code *)**(undefined8 **)piVar2)(piVar2,plRam00000000033f5228);
        if (((ulong)piVar1 & 1) == 0) goto LAB_00c2faec;
        iVar4 = 3;
        *(int **)(param_1 + 0x10) = piVar2;
      }
      *param_1 = iVar4;
      goto LAB_00c2faf8;
    }
    iVar4 = *param_1;
  }
  if (iVar4 == 0) {
    return;
  }
LAB_00c2faf8:
  param_1[0x12] = param_1[0x12] + 1;
  return;
}

