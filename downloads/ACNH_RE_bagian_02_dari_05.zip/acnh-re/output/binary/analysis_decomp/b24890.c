
void FUN_00c24890(long param_1)

{
  FUN_00c2cff0(*(undefined8 *)(param_1 + 0x20));
  FUN_00bea770();
  return;
}

