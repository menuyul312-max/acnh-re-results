
void FUN_00c1f510(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5)

{
  long lVar1;
  undefined8 uVar2;
  
  *param_1 = param_2;
  FUN_00c1fb10(param_1 + 1);
  param_1[0x61b] = param_3;
  param_1[0x61c] = param_4;
  lVar1 = lRam00000000033f4dd0;
  param_1[0x61d] = param_5;
  uVar2 = uRam00000000033f4dd8;
  *(undefined1 *)(param_1 + 0x61e) = 0;
  param_1[2] = lVar1 + 0x10;
  param_1[3] = param_1;
  param_1[4] = uVar2;
  param_1[5] = 0;
  return;
}

