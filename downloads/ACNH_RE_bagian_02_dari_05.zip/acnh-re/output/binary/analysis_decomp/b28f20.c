
undefined1 FUN_00c28f20(long param_1)

{
  return *(undefined1 *)(param_1 + 0x1a1);
}

