
void FUN_00c24660(long param_1)

{
  undefined1 *puVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  
  FUN_00be60c0(param_1 + 0x8c);
  *(undefined1 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  FUN_001232c0(param_1 + 0x240);
  FUN_001232c0(param_1 + 0x1320);
  *(undefined8 *)(param_1 + 0x2408) = 0xffffffffffffd8f0;
  *(undefined8 *)(param_1 + 0x2410) = 0;
  *(undefined4 *)(param_1 + 0x2418) = 0xffffffff;
  FUN_00122110(param_1 + 0x2420);
  *(undefined4 *)(param_1 + 0x2448) = 0;
  *(undefined2 *)(param_1 + 0x244c) = 0;
  *(undefined2 *)(param_1 + 0x2460) = 0;
  *(undefined1 *)(param_1 + 0x2458) = 0;
  *(undefined8 *)(param_1 + 0x2450) = 0;
  *(undefined8 *)(param_1 + 0x2464) = 0xffffffff;
  *(undefined1 *)(param_1 + 0x2462) = 0;
  *(undefined1 *)(param_1 + 0x246c) = 1;
  puVar1 = puRam00000000033d0660;
  *(undefined2 *)(param_1 + 0x2471) = 0;
  *(undefined4 *)(param_1 + 0x246d) = 0;
  **(undefined1 **)(param_1 + 0x2480) = *puVar1;
  FUN_00c0dae0(param_1 + 0x24d0);
  FUN_00c0dae0(param_1 + 0x2540);
  uVar2 = *puRam00000000033d0f28;
  FUN_00c12820(uVar2);
  uVar3 = *(undefined8 *)(param_1 + 8);
  FUN_00bfb370(uVar3);
  FUN_00c02ae0(uVar2,uVar3);
  FUN_020067b0(param_1 + 0x40,0);
  *(undefined4 *)(param_1 + 0x88) = 0;
  FUN_00c2ce90(*(undefined8 *)(param_1 + 0x20));
  FUN_00c2a600(*(undefined8 *)(param_1 + 0x38));
  FUN_00c1c530(*(undefined8 *)(param_1 + 0x10),0);
  return;
}

