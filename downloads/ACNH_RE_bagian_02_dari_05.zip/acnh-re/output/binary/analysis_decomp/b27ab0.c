
void FUN_00c27ab0(long param_1)

{
  *(undefined4 *)(param_1 + 0x2188) = 0;
  return;
}

