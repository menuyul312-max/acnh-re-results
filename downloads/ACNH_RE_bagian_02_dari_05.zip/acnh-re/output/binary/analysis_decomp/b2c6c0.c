
void FUN_00c2c6c0(undefined8 *param_1)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  long lStack_40;
  undefined4 uStack_38;
  uint auStack_28 [2];
  
  lVar3 = param_1[4];
  if (lVar3 != 0) {
    iVar1 = *(int *)((long)param_1 + 0x2c);
    if (iVar1 == 2) {
      plVar2 = *(long **)(lVar3 + 0x228);
    }
    else if (iVar1 == 1) {
      plVar2 = *(long **)(lVar3 + 0x220);
    }
    else {
      if (iVar1 != 0) {
        return;
      }
      plVar2 = *(long **)(lVar3 + 0x218);
    }
    if ((plVar2 != (long *)0x0) && ((**(code **)(*plVar2 + 0x220))(), plVar2 != (long *)0x0)) {
      iVar1 = (int)*param_1;
      FUN_00c24b40();
      FUN_00be6b50();
      plVar2 = (long *)plVar2[9];
      if (plVar2 != (long *)0x0) {
        auStack_28[0] = 1;
        if (iVar1 == 1) {
          auStack_28[0] = 2;
        }
        lVar3 = lRam00000000033f51d8 + 0x10;
        uStack_38 = 0x36;
        lStack_40 = lVar3;
        (**(code **)(*plVar2 + 0x18))(plVar2,&lStack_40);
        (**(code **)(plVar2[3] + 0x378))(plVar2[1],auStack_28);
        auStack_28[0] = (uint)(iVar1 != 1);
        uStack_38 = 0x34;
        lStack_40 = lVar3;
        (**(code **)(*plVar2 + 0x18))(plVar2,&lStack_40);
        (**(code **)(plVar2[3] + 0x358))(plVar2[1],auStack_28);
      }
    }
  }
  return;
}

