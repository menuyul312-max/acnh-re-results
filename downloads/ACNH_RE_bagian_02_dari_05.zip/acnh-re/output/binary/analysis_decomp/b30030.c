
void FUN_00c30030(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c30038. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x38))();
  return;
}

