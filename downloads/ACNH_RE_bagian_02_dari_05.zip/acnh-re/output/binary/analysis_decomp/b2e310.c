
void _INIT_2645(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654f28 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654f60);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654f2c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654f30 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654f44 = 0xffff;
  uRam0000000003654f40 = 0xffffffff;
  uRam0000000003654f4c = 0;
  uRam0000000003654f48 = 0;
  uRam0000000003654f34 = (undefined4)uVar2;
  uRam0000000003654f38 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654f50 = uVar2;
  uRam0000000003654f58 = 0;
  return;
}

