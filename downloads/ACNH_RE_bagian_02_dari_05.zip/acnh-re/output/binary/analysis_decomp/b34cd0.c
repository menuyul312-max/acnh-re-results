
void _INIT_2661(void)

{
  int iVar1;
  char cVar2;
  char cVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined *puVar6;
  ulong uVar7;
  long lVar8;
  long lStack_40;
  undefined *puStack_38;
  
  lStack_40 = CONCAT44(lStack_40._4_4_,2);
  uRam00000000036558f8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655950);
  uVar4 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036558fc = uVar4;
  uVar4 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655900 = uVar4;
  uVar5 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655924 = 0xffff;
  uRam0000000003655920 = 0xffffffff;
  uRam000000000365592c = 0;
  uRam0000000003655928 = 0;
  uRam0000000003655904 = (undefined4)uVar5;
  uRam0000000003655908 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655938 = 0;
  uRam0000000003655930 = uVar5;
  FUN_010588a0(0x3655940,0x1c2b);
  FUN_010588a0(0x3655948,0x142e);
  uRam0000000003655914 = 0x200000003;
  iRam0000000003655910 = *piRam00000000033d0630;
  lRam0000000003655988 = lRam00000000033d0670 + 0x10;
  iRam000000000365590c = -iRam0000000003655910;
  lVar8 = lRam00000000033d0668 + 0x10;
  puStack_38 = &UNK_02ac0a89;
  puRam0000000003655990 = (undefined *)0x365599c;
  iRam0000000003655998 = 0x20;
  lStack_40 = lVar8;
  FUN_01a90780(0x3655988);
  puVar6 = puRam0000000003655990;
  lRam0000000003655988 = lRam00000000033d0678 + 0x10;
  if (puRam0000000003655990 != &UNK_02ac0a89) {
    cVar2 = *pcRam00000000033d0660;
    uVar7 = 0;
    cVar3 = UNK_02ac0a89;
    while (cVar3 != cVar2) {
      if (uVar7 >> 0x13 != 0) {
        uVar7 = 0;
        break;
      }
      if ((&UNK_02ac0a8a)[uVar7] == cVar2) {
        uVar7 = uVar7 + 1;
        break;
      }
      cVar3 = (&UNK_02ac0a8b)[uVar7];
      uVar7 = uVar7 + 2;
    }
    iVar1 = (int)uVar7;
    if (iRam0000000003655998 <= (int)uVar7) {
      iVar1 = iRam0000000003655998 + -1;
    }
    memcpy(puRam0000000003655990,&UNK_02ac0a89,(long)iVar1);
    puVar6[iVar1] = cVar2;
    lVar8 = lStack_40;
  }
  lRam0000000003655988 = lRam00000000033d0680 + 0x10;
  (**(code **)(lVar8 + 0x18))(&lStack_40);
  puVar6 = puStack_38;
  FUN_00101bf0(puStack_38,0);
  uRam00000000036559c0 = SUB84(puVar6,0);
  FUN_0062bab0(0x3655960,0xffff0001,0xffff0001,0xffff,0xffff);
  FUN_001001c0(uRam00000000033d0688,0x3655960,&DAT_0311c000);
  return;
}

