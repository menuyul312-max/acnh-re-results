
undefined1 FUN_00c1e590(long param_1)

{
  return *(undefined1 *)(param_1 + 9);
}

