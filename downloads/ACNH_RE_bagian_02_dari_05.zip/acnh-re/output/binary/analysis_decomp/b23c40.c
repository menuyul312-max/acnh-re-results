
undefined8 FUN_00c23c40(undefined8 *param_1)

{
  return *param_1;
}

