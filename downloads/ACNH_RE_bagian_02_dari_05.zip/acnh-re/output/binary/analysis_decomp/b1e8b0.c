
void FUN_00c1e8b0(long *param_1)

{
  long *plVar1;
  undefined *puVar2;
  ulong uVar3;
  undefined4 auStack_50 [2];
  long lStack_48;
  undefined *puStack_40;
  long lStack_38;
  char cStack_30;
  char cStack_2e;
  undefined4 auStack_28 [2];
  undefined1 auStack_18 [8];
  
  plVar1 = (long *)*param_1;
  FUN_00c24b10();
  if (plVar1 == (long *)0x0) {
    return;
  }
  (**(code **)(*plVar1 + 0x10))(auStack_18);
  uVar3 = 0;
  FUN_00ea4020();
  if ((uVar3 & 1) == 0) {
    return;
  }
  auStack_28[0] = SUB84(auStack_18,0);
  FUN_00f6f120();
  FUN_0013fe00(&lStack_38,auStack_28,0);
  if (((lStack_38 != 0) && (cStack_30 != '\0')) && (cStack_2e != '\0')) {
    puVar2 = *(undefined **)(lStack_38 + 0x60);
    lStack_48 = lRam00000000033d0668 + 0x10;
    puStack_40 = &UNK_02a5aeac;
    FUN_001470e0(puVar2,&lStack_48);
    if (puVar2 != (undefined *)0x0) {
      if (puVar2 == &UNK_02aa0a8d) goto LAB_00c1e9ac;
      uVar3 = 0;
      do {
        if ((&UNK_02aa0a8d)[uVar3] != puVar2[uVar3]) break;
        if ((&UNK_02aa0a8d)[uVar3] == *pcRam00000000033d0660) goto LAB_00c1e9ac;
        uVar3 = uVar3 + 1;
      } while (uVar3 < 0x80001);
    }
    auStack_50[0] = *(undefined4 *)((long)param_1 + 0xc);
    FUN_00f7b150(auStack_18,auStack_50,1,(char)param_1[1],0);
  }
LAB_00c1e9ac:
  FUN_00140040(&lStack_38);
  return;
}

