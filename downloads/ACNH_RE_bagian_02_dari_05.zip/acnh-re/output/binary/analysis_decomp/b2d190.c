
undefined4 FUN_00c2d190(long param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2c);
  if (iVar1 == 2) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x44);
  }
  if (iVar1 != 1) {
    if (iVar1 == 0) {
      switch(*(undefined4 *)(param_1 + 0x34)) {
      case 0:
        return *(undefined4 *)(lRam00000000033f4d60 + 0x34);
      case 1:
        return *(undefined4 *)(lRam00000000033f4d60 + 0x38);
      case 2:
        return *(undefined4 *)(lRam00000000033f4d60 + 0x3c);
      case 3:
        return *(undefined4 *)(lRam00000000033f4d60 + 0x48);
      case 4:
        return *(undefined4 *)(lRam00000000033f4d60 + 0x4c);
      case 5:
        return *(undefined4 *)(lRam00000000033f4d60 + 0x50);
      default:
        return 0;
      }
    }
    return 0;
  }
  return *(undefined4 *)(lRam00000000033f4d60 + 0x40);
}

