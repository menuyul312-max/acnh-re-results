
void _INIT_2632(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003653538 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3653570);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000365353c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003653540 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003653554 = 0xffff;
  uRam0000000003653550 = 0xffffffff;
  uRam000000000365355c = 0;
  uRam0000000003653558 = 0;
  uRam0000000003653544 = (undefined4)uVar2;
  uRam0000000003653548 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003653560 = uVar2;
  uRam0000000003653568 = 0;
  return;
}

