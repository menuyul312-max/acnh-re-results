
void _INIT_2665(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655e50 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655e88);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655e54 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655e58 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655e6c = 0xffff;
  uRam0000000003655e68 = 0xffffffff;
  uRam0000000003655e74 = 0;
  uRam0000000003655e70 = 0;
  uRam0000000003655e5c = (undefined4)uVar2;
  uRam0000000003655e60 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655e78 = uVar2;
  uRam0000000003655e80 = 0;
  return;
}

