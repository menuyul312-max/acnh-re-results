
void FUN_00c2fca0(long param_1,undefined8 param_2)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  undefined8 uVar4;
  
  uVar1 = *puRam00000000033d0f28;
  FUN_00c127c0();
  FUN_00c17ae0();
  FUN_00c17ab0();
  if (uVar1 != 0) {
    uVar2 = uVar1;
    FUN_01a8d530();
    if ((uint)uVar2 < 0x10) {
      uVar3 = uVar2;
      FUN_00193a30();
      uVar4 = *(undefined8 *)
               (uVar3 + (-(uVar2 >> 0x1f & 1) & 0xfffffff800000000 | (uVar2 & 0xffffffff) << 3));
    }
    else {
      uVar4 = 0x2ab9d8f;
    }
    (**(code **)(*(long *)(param_1 + 0x50) + 0x18))(param_1 + 0x50);
    FUN_01a90820(param_2,&UNK_02abd271,uVar1,uVar4,*(undefined8 *)(param_1 + 0x58));
  }
  return;
}

