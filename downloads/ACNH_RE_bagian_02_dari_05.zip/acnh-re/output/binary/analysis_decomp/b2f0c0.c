
void thunk_FUN_022ea890(long *param_1)

{
  long lVar1;
  long lVar2;
  
  param_1[2] = 0;
  lVar1 = lRam0000000003431f40;
  *(undefined1 *)(param_1 + 3) = 0x22;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  param_1[8] = (long)(param_1 + 8);
  param_1[9] = (long)(param_1 + 8);
  param_1[4] = 0;
  *param_1 = lVar1 + 0x10;
  param_1[1] = 0;
  param_1[0xc] = (long)(param_1 + 0xb);
  param_1[0xd] = -0x100000000;
  param_1[10] = -0x100000000;
  param_1[0xb] = (long)(param_1 + 0xb);
  FUN_01aa2460(param_1 + 0xe);
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  lVar2 = lRam00000000033d0660;
  lVar1 = lRam00000000033d0668 + 0x10;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined2 *)(param_1 + 0x21) = 0;
  *(undefined1 *)((long)param_1 + 0x10b) = 0;
  param_1[0x1e] = lVar1;
  param_1[0x1f] = lVar2;
  *(undefined4 *)((long)param_1 + 0x54) = 0x98;
  *(undefined4 *)((long)param_1 + 0x6c) = 0xa8;
  return;
}

