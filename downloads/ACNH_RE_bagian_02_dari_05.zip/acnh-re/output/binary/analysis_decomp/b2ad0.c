
uint FUN_001b2ad0(undefined8 param_1,undefined8 *param_2,undefined4 *param_3,undefined8 *param_4,
                 undefined8 param_5)

{
  long lStack_58;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  
  uStack_2c = param_3[2];
  uStack_40 = param_3[3];
  uStack_44 = *param_3;
  uStack_38 = param_3[1];
  uStack_24 = param_3[8];
  uStack_3c = param_3[6];
  uStack_30 = param_3[7];
  uStack_34 = param_3[4];
  uStack_28 = param_3[5];
  lStack_58 = lRam00000000033d4b08 + 0x10;
  uStack_50 = *param_2;
  uStack_48 = *(undefined4 *)(param_2 + 1);
  uStack_20 = *param_4;
  uStack_18 = *(undefined4 *)(param_4 + 1);
  FUN_001b2b50(param_1,&lStack_58,param_5);
  return (uint)param_1 & 1;
}

