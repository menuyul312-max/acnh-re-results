
void FUN_00c30690(undefined8 param_1,undefined8 param_2,int *param_3)

{
  int iVar1;
  char *pcVar2;
  undefined8 *puVar3;
  int *piVar4;
  int *piVar5;
  undefined2 uVar6;
  uint uVar7;
  int *piVar8;
  undefined1 auStack_440 [976];
  undefined1 auStack_70 [16];
  
  puVar3 = puRam00000000033d8280;
  pcVar2 = pcRam00000000033d8278;
  iVar1 = *param_3;
  do {
    if (iVar1 == 0) {
LAB_00c307ac:
      uVar6 = 0xfffe;
LAB_00c307b0:
      FUN_010588a0(auStack_70,uVar6);
      FUN_00c31070(auStack_440,auStack_70,uRam00000000033d1570);
      FUN_00bf9a10(param_2,auStack_440,0);
      FUN_00c314b0(auStack_440);
      return;
    }
    piVar5 = param_3;
    if (*pcVar2 == '\0') {
      *pcVar2 = '\x01';
      puVar3[6] = 0xffffffffffffffff;
      puVar3[7] = 0xffffffffffffffff;
      *(undefined4 *)(puVar3 + 8) = 0xffffffff;
      puVar3[4] = 0xffffffffffffffff;
      puVar3[5] = 0xffffffffffffffff;
      puVar3[2] = 0xffffffffffffffff;
      puVar3[3] = 0xffffffffffffffff;
      *puVar3 = 0xffffffffffffffff;
      puVar3[1] = 0xffffffffffffffff;
      FUN_01765e80();
    }
    else {
      iVar1 = *(int *)((long)puVar3 + 0x14);
      if (-1 < iVar1) {
        if ((undefined2 *)((long)iVar1 + (long)param_3) != (undefined2 *)0x0) {
          uVar6 = *(undefined2 *)((long)iVar1 + (long)param_3);
          goto LAB_00c307b0;
        }
        goto LAB_00c307ac;
      }
      if (iVar1 != -1) goto LAB_00c307ac;
      FUN_01765e80();
    }
    if ((piVar5 == (int *)0x0) || (piVar4 = piVar5, FUN_01765e60(), piVar4 == (int *)0x0))
    goto LAB_00c307ac;
    FUN_01765e50();
    *(undefined4 *)((long)puVar3 + 0x14) = 0xfffffffe;
    if ((uint)piVar5 == 0) goto LAB_00c307ac;
    uVar7 = 0;
    piVar8 = piVar4 + 1;
    while (piVar4[(ulong)uVar7 * 2] != -0x3cc576b2) {
      uVar7 = uVar7 + 1;
      piVar8 = piVar8 + 2;
      if ((uint)piVar5 <= uVar7) goto LAB_00c307ac;
    }
    iVar1 = 0;
    if (*piVar8 != -1) {
      iVar1 = *piVar8;
    }
    *(int *)((long)puVar3 + 0x14) = iVar1;
    iVar1 = *param_3;
  } while( true );
}

