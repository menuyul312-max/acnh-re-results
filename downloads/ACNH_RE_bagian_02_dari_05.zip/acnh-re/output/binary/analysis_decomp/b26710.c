
void FUN_00c26710(long param_1)

{
  ulong uVar1;
  
  uVar1 = param_1 + 0x2540;
  FUN_00c0e780();
  if ((uVar1 & 1) != 0) {
    FUN_00c27b00(*(undefined8 *)(param_1 + 0x28),0);
    *(undefined4 *)(param_1 + 0x2464) = 0xffffffff;
    *(undefined1 *)(param_1 + 0x2462) = 0;
    *(undefined1 *)(param_1 + 0x246e) = 0;
    FUN_00c27960(*(undefined8 *)(param_1 + 0x28));
    *(undefined8 *)(param_1 + 0x2408) = 0xffffffffffffd8f0;
    *(undefined1 *)(param_1 + 0xac) = 0;
    *(undefined8 *)(param_1 + 0x2410) = 0;
    *(undefined4 *)(param_1 + 0x2418) = 0xffffffff;
    FUN_00122110(param_1 + 0x2420);
    *(undefined4 *)(param_1 + 0x2448) = 0;
    *(undefined2 *)(param_1 + 0x244c) = 0;
    FUN_020067b0(param_1 + 0x40,1);
    return;
  }
  **(undefined1 **)(param_1 + 0x2480) = *puRam00000000033d0660;
  if ((*(char *)(param_1 + 0x246c) != '\0') && (*(char *)(param_1 + 0x246f) == '\0')) {
    FUN_00c27b00(*(undefined8 *)(param_1 + 0x28),0);
    *(undefined4 *)(param_1 + 0x2464) = 0xffffffff;
    *(undefined1 *)(param_1 + 0x2462) = 0;
    *(undefined1 *)(param_1 + 0x246e) = 0;
    *(undefined8 *)(param_1 + 0x2408) = 0xffffffffffffd8f0;
    *(undefined1 *)(param_1 + 0xac) = 0;
    *(undefined8 *)(param_1 + 0x2410) = 0;
    *(undefined4 *)(param_1 + 0x2418) = 0xffffffff;
    FUN_00122110(param_1 + 0x2420);
    *(undefined4 *)(param_1 + 0x2448) = 0;
    *(undefined2 *)(param_1 + 0x244c) = 0;
    FUN_020067b0(param_1 + 0x40,6);
    return;
  }
  FUN_00c27b00(*(undefined8 *)(param_1 + 0x28),0);
  *(undefined4 *)(param_1 + 0x2464) = 0xffffffff;
  *(undefined1 *)(param_1 + 0x2462) = 0;
  *(undefined1 *)(param_1 + 0x246e) = 0;
  *(undefined8 *)(param_1 + 0x2408) = 0xffffffffffffd8f0;
  *(undefined1 *)(param_1 + 0xac) = 0;
  *(undefined8 *)(param_1 + 0x2410) = 0;
  *(undefined4 *)(param_1 + 0x2418) = 0xffffffff;
  FUN_00122110(param_1 + 0x2420);
  *(undefined4 *)(param_1 + 0x2448) = 0;
  *(undefined2 *)(param_1 + 0x244c) = 0;
  FUN_020067b0(param_1 + 0x40,7);
  return;
}

