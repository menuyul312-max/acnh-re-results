
void FUN_00c2f780(undefined4 *param_1)

{
  long lVar1;
  long lVar2;
  undefined1 uVar3;
  long *plVar4;
  
  *param_1 = 0;
  FUN_022ed100(param_1 + 2);
  *(undefined8 *)(param_1 + 0x10) = 0;
  param_1[0x12] = 0;
  lVar1 = lRam00000000033d0670 + 0x10;
  *(undefined4 **)(param_1 + 0x16) = param_1 + 0x19;
  plVar4 = (long *)(param_1 + 0x14);
  *plVar4 = lVar1;
  param_1[0x18] = 0x40;
  FUN_01a90780(plVar4);
  uVar3 = *puRam00000000033d0660;
  lVar2 = lRam00000000033d1298 + 0x10;
  **(undefined1 **)(param_1 + 0x16) = uVar3;
  *plVar4 = lVar2;
  plVar4 = (long *)(param_1 + 0x2a);
  *plVar4 = lVar1;
  param_1[0x2e] = 0x40;
  *(undefined4 **)(param_1 + 0x2c) = param_1 + 0x2f;
  FUN_01a90780(plVar4);
  **(undefined1 **)(param_1 + 0x2c) = uVar3;
  *plVar4 = lVar2;
  return;
}

