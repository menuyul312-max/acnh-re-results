
void FUN_00c37f90(long param_1)

{
  FUN_01766240(param_1 + 8);
  return;
}

