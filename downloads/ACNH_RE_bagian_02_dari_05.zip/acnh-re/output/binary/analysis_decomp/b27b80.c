
void FUN_00c27b80(long param_1)

{
  FUN_00bee590(param_1 + 0xbe0);
  return;
}

