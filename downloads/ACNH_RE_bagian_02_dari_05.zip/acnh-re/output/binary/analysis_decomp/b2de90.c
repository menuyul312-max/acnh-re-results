
void FUN_00c2de90(undefined4 param_1,undefined4 param_2,long param_3)

{
  *(undefined4 *)(param_3 + 0xc) = param_1;
  *(undefined4 *)(param_3 + 0x10) = param_2;
  return;
}

