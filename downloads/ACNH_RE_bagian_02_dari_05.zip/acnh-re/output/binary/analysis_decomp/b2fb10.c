
void FUN_00c2fb10(undefined4 *param_1)

{
  undefined8 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  long lStack_f0;
  undefined *puStack_e8;
  undefined4 uStack_e0;
  undefined1 auStack_dc [68];
  undefined1 auStack_98 [16];
  undefined1 auStack_88 [56];
  undefined8 uStack_50;
  
  FUN_022ed010(auStack_98);
  lStack_f0 = lRam00000000033d0668 + 0x10;
  puStack_e8 = &UNK_02a4231c;
  FUN_01a904f0(auStack_88,&lStack_f0);
  uVar1 = *puRam00000000033d0f28;
  FUN_00c12810();
  puStack_e8 = auStack_dc;
  lStack_f0 = lRam00000000033d0670 + 0x10;
  uStack_e0 = 0x40;
  uStack_50 = uVar1;
  FUN_01a90780(&lStack_f0);
  lStack_f0 = lRam00000000033d1298;
  *puStack_e8 = *puRam00000000033d0660;
  lStack_f0 = lStack_f0 + 0x10;
  puVar2 = param_1;
  FUN_00c2fca0(param_1,&lStack_f0);
  uVar3 = 4;
  if (((ulong)puVar2 & 1) != 0) {
    puVar2 = param_1 + 2;
    FUN_022ed6d0(puVar2,&lStack_f0,auStack_98,0);
    uVar3 = 2;
    if (((ulong)puVar2 & 1) == 0) {
      uVar3 = 4;
    }
  }
  *param_1 = uVar3;
  FUN_022ee740(auStack_98);
  return;
}

