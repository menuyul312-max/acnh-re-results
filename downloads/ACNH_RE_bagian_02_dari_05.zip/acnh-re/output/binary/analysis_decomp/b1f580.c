
void FUN_00c1f580(undefined8 *param_1,ulong param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  long lVar9;
  undefined8 uVar10;
  undefined8 uStack_3148;
  undefined1 auStack_3140 [8];
  long lStack_3138;
  undefined8 *puStack_3130;
  undefined8 uStack_3128;
  undefined8 uStack_3120;
  undefined8 uStack_70;
  ulong uStack_68;
  long lStack_60;
  undefined1 uStack_58;
  
  uVar6 = param_2;
  FUN_00c0e780();
  if ((uVar6 & 1) != 0) {
    uVar6 = param_2;
    FUN_00c0dc60();
    uVar7 = param_2;
    FUN_00c0dc30();
    uVar8 = param_2;
    FUN_00c0dc40();
    if ((((int)uVar6 == 1) && ((int)uVar7 < 0x400)) && (iVar5 = (int)uVar8, iVar5 < 0x80)) {
      iVar2 = 0;
      if (iVar5 != -1) {
        iVar2 = iVar5;
      }
      uVar1 = iVar2 + (int)uVar7 * 0x80;
      if (-1 < (int)uVar1) {
        lVar9 = param_1[0x61d];
        uVar3 = *(uint *)(lVar9 + (ulong)(uVar1 >> 5) * 4);
        uVar4 = 1 << (ulong)(uVar1 & 0x1f);
        if ((uVar3 & uVar4) == 0) {
          if (uVar1 >> 0x11 == 0) {
            *(uint *)(lVar9 + (ulong)(uVar1 >> 5) * 4) = uVar3 | uVar4;
            lVar9 = param_1[0x61d];
          }
          uStack_3148 = *param_1;
          uVar10 = param_1[0x61b];
          FUN_00c1fb10(auStack_3140);
          lStack_3138 = lRam00000000033f4dd0 + 0x10;
          uStack_3128 = uRam00000000033f4dd8;
          uStack_3120 = 0;
          uStack_58 = 0;
          puStack_3130 = &uStack_3148;
          uStack_70 = uVar10;
          uStack_68 = param_2;
          lStack_60 = lVar9;
          FUN_00c1f6f0(&uStack_3148);
          *(undefined1 *)(param_1 + 0x61e) = uStack_58;
          FUN_00c1fb90(auStack_3140);
        }
      }
    }
  }
  return;
}

