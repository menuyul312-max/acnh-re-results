
void FUN_00c2b100(long *param_1,long param_2,undefined8 param_3)

{
  int iVar1;
  int iVar2;
  long lVar3;
  long *plVar4;
  byte *pbVar5;
  long lVar6;
  undefined4 uVar7;
  uint uVar8;
  
  lVar3 = *param_1;
  FUN_00c24b20();
  plVar4 = param_1 + 4;
  if ((lVar3 != 0) && (*(char *)(lVar3 + 0x1a0) != '\0')) {
    plVar4 = (long *)(lVar3 + 0x168);
  }
  FUN_01750090();
  if (((*pbRam00000000033f5188 & 1) == 0) &&
     (pbVar5 = pbRam00000000033f5188, __cxa_guard_acquire(), (int)pbVar5 != 0)) {
    *plRam00000000033f5190 = lRam00000000033d3270 + 0x10;
    __cxa_guard_release(pbRam00000000033f5188);
    if (plVar4 != (long *)0x0) goto LAB_00c2b164;
LAB_00c2b1bc:
    uVar8 = 1;
  }
  else {
    if (plVar4 == (long *)0x0) goto LAB_00c2b1bc;
LAB_00c2b164:
    (**(code **)*plVar4)(plVar4,plRam00000000033f5190);
    uVar8 = (uint)plVar4 ^ 1;
  }
  *(undefined4 *)(param_1 + 1) = 0;
  param_1[2] = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined4 *)((long)param_1 + 0x1c) = 0;
  FUN_00c2fc40(param_1 + 0xb);
  FUN_00bf1140(param_1 + 0x2b);
  iVar2 = (int)*param_1;
  FUN_00c24b40();
  iVar1 = iVar2;
  FUN_00be6c30();
  *(byte *)(param_1 + 3) = (byte)iVar1 & 1;
  FUN_00bf0fe0(param_1 + 0x2b,param_3);
  if (((uVar8 & 1) == 0) && (FUN_00be6ae0(), iVar2 != 1)) {
    lVar3 = param_2;
    FUN_00123520();
    lVar6 = param_2;
    FUN_00123530();
    if ((**(char **)(lVar3 + 8) != *pcRam00000000033d0660) &&
       (**(char **)(lVar6 + 8) != *pcRam00000000033d0660)) {
      FUN_00c2f840(param_1 + 0xb,lVar3,lVar6);
      lVar3 = *param_1;
      FUN_00c24b50();
      if (lVar3 != 0) {
        FUN_00c02580();
      }
      param_1[2] = param_2;
      uVar7 = 1;
      goto LAB_00c2b270;
    }
  }
  uVar7 = 3;
LAB_00c2b270:
  *(undefined4 *)(param_1 + 1) = uVar7;
  return;
}

