
void FUN_00c2aef0(long param_1)

{
  thunk_FUN_001219a0(param_1 + 0x158);
  FUN_00c2f830(param_1 + 0x58);
  FUN_0174fcf0(param_1 + 0x20);
  return;
}

