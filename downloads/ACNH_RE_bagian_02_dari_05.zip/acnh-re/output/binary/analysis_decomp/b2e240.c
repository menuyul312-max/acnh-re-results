
void FUN_00c2e240(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c2e248. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x28))();
  return;
}

