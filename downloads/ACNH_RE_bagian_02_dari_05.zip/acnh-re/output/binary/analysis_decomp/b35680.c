
void _INIT_2662(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam00000000036559c8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655a18);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036559cc = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam00000000036559d0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036559ec = 0xffff;
  uRam00000000036559e8 = 0xffffffff;
  uRam00000000036559f4 = 0;
  uRam00000000036559f0 = 0;
  uRam00000000036559d4 = (undefined4)uVar2;
  uRam00000000036559d8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655a00 = 0;
  uRam00000000036559f8 = uVar2;
  FUN_010588a0(0x3655a08,0x1c2b);
  FUN_010588a0(0x3655a10,0x142e);
  iRam00000000036559dc = -*piRam00000000033d0630;
  iRam00000000036559e0 = *piRam00000000033d0630;
  return;
}

