
void FUN_00c2c5b0(undefined8 *param_1)

{
  char cVar1;
  bool bVar2;
  int iStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  
  cVar1 = *(char *)(param_1 + 7);
  FUN_00c24b40(*param_1);
  FUN_00be6790();
  if ((cVar1 != '\0') && (iStack_24 == 0)) {
    if (iStack_2c == 2) {
      iStack_2c = 5;
    }
    else if (iStack_2c == 1) {
      iStack_2c = 4;
    }
    else if (iStack_2c == 0) {
      iStack_2c = 3;
    }
  }
  FUN_01385b90(param_1[4]);
  if (iStack_24 == 0) {
    if (*(int *)(param_1 + 5) == 2) {
      iStack_24 = 0;
      goto LAB_00c2c68c;
    }
    FUN_0138b700(*(undefined8 *)(param_1[4] + 0x218),uStack_28);
    FUN_0138b710(*(undefined8 *)(param_1[4] + 0x218),iStack_2c);
    bVar2 = true;
  }
  else {
    bVar2 = iStack_24 != 1;
  }
  if (!bVar2) {
    FUN_01387f70(*(undefined8 *)(param_1[4] + 0x220),uStack_28);
  }
LAB_00c2c68c:
  *(int *)((long)param_1 + 0x2c) = iStack_24;
  *(undefined4 *)(param_1 + 6) = uStack_28;
  *(int *)((long)param_1 + 0x34) = iStack_2c;
  *(undefined1 *)(param_1 + 7) = 0;
  return;
}

