
void _INIT_2639(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam00000000036543e8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654420);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036543ec = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam00000000036543f0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654404 = 0xffff;
  uRam0000000003654400 = 0xffffffff;
  uRam000000000365440c = 0;
  uRam0000000003654408 = 0;
  uRam00000000036543f4 = (undefined4)uVar2;
  uRam00000000036543f8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654410 = uVar2;
  uRam0000000003654418 = 0;
  return;
}

