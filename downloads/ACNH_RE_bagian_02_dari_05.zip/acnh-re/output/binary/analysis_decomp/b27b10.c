
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1  [16] FUN_00c27b10(long param_1)

{
  undefined1 *puVar1;
  float fVar2;
  undefined1 auVar3 [16];
  undefined8 uVar4;
  undefined1 auStack_238 [520];
  
  FUN_00beed40(auStack_238);
  puVar1 = auStack_238;
  FUN_00beedc0(puVar1,param_1 + 0x218);
  fVar2 = (float)(int)puVar1 * _UNK_02ad61f4;
  if (*(int *)(param_1 + 0xbd8) < 1) {
    fVar2 = 0.0;
  }
  uVar4 = 0;
  auVar3._4_4_ = 0;
  auVar3._0_4_ = fVar2;
  thunk_FUN_001219a0(auStack_238);
  auVar3._8_8_ = uVar4;
  return auVar3;
}

