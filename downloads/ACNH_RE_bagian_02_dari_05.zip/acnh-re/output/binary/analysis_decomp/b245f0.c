
bool FUN_00c245f0(long param_1)

{
  return *(int *)(param_1 + 0x48) == 0;
}

