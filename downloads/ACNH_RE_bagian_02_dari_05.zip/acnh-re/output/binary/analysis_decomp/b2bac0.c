
void _INIT_2640(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654450 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654498);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654454 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654458 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000365446c = 0xffff;
  uRam0000000003654468 = 0xffffffff;
  uRam0000000003654474 = 0;
  uRam0000000003654470 = 0;
  uRam000000000365445c = (undefined4)uVar2;
  uRam0000000003654460 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654478 = uVar2;
  uRam0000000003654480 = 0;
  return;
}

