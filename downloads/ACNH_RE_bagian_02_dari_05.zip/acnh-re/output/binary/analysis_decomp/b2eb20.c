
void _INIT_2647(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654fb8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654ff0);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654fbc = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654fc0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654fd4 = 0xffff;
  uRam0000000003654fd0 = 0xffffffff;
  uRam0000000003654fdc = 0;
  uRam0000000003654fd8 = 0;
  uRam0000000003654fc4 = (undefined4)uVar2;
  uRam0000000003654fc8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654fe0 = uVar2;
  uRam0000000003654fe8 = 0;
  return;
}

