
void FUN_00c24c70(long param_1,int param_2,int param_3)

{
  undefined8 uVar1;
  undefined *puVar2;
  undefined1 auStack_50 [32];
  
  uVar1 = *(undefined8 *)(param_1 + 0x20);
  FUN_00c2cff0(uVar1);
  FUN_00bea070(auStack_50);
  if (param_2 == 0) {
    puVar2 = &UNK_02ab4ff2;
  }
  else {
    puVar2 = &UNK_02a25a6a;
  }
  FUN_00bea090(auStack_50,&UNK_02a55af7,puVar2,0,0,0);
  FUN_00bea780(uVar1,auStack_50);
  FUN_00bea080(auStack_50);
  FUN_00bea070(auStack_50);
  if (param_3 == 0) {
    puVar2 = &UNK_02a7a07d;
  }
  else {
    puVar2 = &UNK_02a9c7e3;
  }
  FUN_00bea090(auStack_50,&UNK_02a55af7,puVar2,1,0,0);
  FUN_00bea780(uVar1,auStack_50);
  FUN_00bea080(auStack_50);
  *(int *)(param_1 + 0x2468) = param_3;
  return;
}

