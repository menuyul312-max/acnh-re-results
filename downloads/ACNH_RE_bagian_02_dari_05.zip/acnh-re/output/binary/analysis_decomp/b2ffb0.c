
ulong FUN_00c2ffb0(long *param_1)

{
  (**(code **)(*param_1 + 0x28))();
  return (ulong)param_1 & 0xffffffff;
}

