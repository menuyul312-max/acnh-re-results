
void _INIT_2654(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655230 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655268);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655234 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655238 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000365524c = 0xffff;
  uRam0000000003655248 = 0xffffffff;
  uRam0000000003655254 = 0;
  uRam0000000003655250 = 0;
  uRam000000000365523c = (undefined4)uVar2;
  uRam0000000003655240 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655258 = uVar2;
  uRam0000000003655260 = 0;
  return;
}

