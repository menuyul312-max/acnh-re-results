
void FUN_00c2f0d0(undefined8 param_1)

{
  FUN_022ea980();
  FUN_022ea940(param_1);
  return;
}

