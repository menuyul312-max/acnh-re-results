
long FUN_00c40210(int *param_1)

{
  long lVar1;
  int iVar2;
  char *pcVar3;
  undefined8 *puVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  long lVar8;
  int *piVar9;
  
  puVar4 = puRam00000000033f5498;
  pcVar3 = pcRam00000000033f5488;
  iVar2 = *param_1;
  while (iVar2 != 0) {
    piVar6 = param_1;
    if (*pcVar3 == '\0') {
      *pcVar3 = '\x01';
      puVar4[1] = 0xffffffffffffffff;
      puVar4[2] = 0xffffffffffffffff;
      *puVar4 = 0xffffffffffffffff;
      *(undefined4 *)(puVar4 + 3) = 0xffffffff;
      FUN_01765e80();
    }
    else {
      iVar2 = *(int *)(puVar4 + 2);
      if (-1 < iVar2) {
        lVar8 = (long)iVar2 + (long)param_1;
        goto LAB_00c4030c;
      }
      if (iVar2 != -1) break;
      FUN_01765e80();
    }
    if ((piVar6 == (int *)0x0) || (piVar5 = piVar6, FUN_01765e60(), piVar5 == (int *)0x0)) break;
    FUN_01765e50();
    *(undefined4 *)(puVar4 + 2) = 0xfffffffe;
    if ((uint)piVar6 == 0) break;
    uVar7 = 0;
    piVar9 = piVar5 + 1;
    while (piVar5[(ulong)uVar7 * 2] != -0x68417899) {
      uVar7 = uVar7 + 1;
      piVar9 = piVar9 + 2;
      if ((uint)piVar6 <= uVar7) goto LAB_00c40308;
    }
    iVar2 = 0;
    if (*piVar9 != -1) {
      iVar2 = *piVar9;
    }
    *(int *)(puVar4 + 2) = iVar2;
    iVar2 = *param_1;
  }
LAB_00c40308:
  lVar8 = 0;
LAB_00c4030c:
  lVar1 = *plRam00000000033f5568;
  if (lVar8 != 0) {
    lVar1 = lVar8;
  }
  return lVar1;
}

