
void FUN_00c388c0(long param_1,undefined8 param_2,uint *param_3)

{
  int *piVar1;
  int iVar2;
  ushort uVar3;
  char *pcVar4;
  undefined8 *puVar5;
  uint *puVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  ulong uVar10;
  undefined2 uVar11;
  uint uVar12;
  int *piVar13;
  uint uVar14;
  undefined1 auStack_70 [12];
  uint uStack_64;
  
  puVar6 = puRam00000000033f5338;
  puVar5 = puRam00000000033f5320;
  pcVar4 = pcRam00000000033f5318;
  uVar14 = 0;
  piVar1 = (int *)(param_1 + 8);
  piVar7 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
  if (0 < (int)*(uint *)(param_1 + 0x1c8)) goto LAB_00c38950;
LAB_00c38924:
  piVar7 = piVar1;
  FUN_01766670();
  if (piVar7 == (int *)0x0) goto LAB_00c38950;
  FUN_01765e30();
  if ((uint)piVar7 <= uVar14) {
    return;
  }
  do {
    piVar7 = piVar1;
    FUN_00c38330(piVar1,uVar14);
    if (piVar7 != (int *)0x0) {
      piVar8 = piVar7;
      FUN_01765ea0();
      if ((*puVar6 <= (uint)piVar8) ||
         (uVar3 = *(ushort *)(*(long *)(puVar6 + 2) + (long)(int)(uint)piVar8 * 2),
         uStack_64 = (uint)uVar3, 0xc < uVar3)) {
        uStack_64 = 0;
      }
      if (uStack_64 == *param_3) {
        iVar2 = *piVar7;
        while (iVar2 != 0) {
          piVar8 = piVar7;
          if (*pcVar4 == '\0') {
            *pcVar4 = '\x01';
            *puVar5 = 0xffffffffffffffff;
            puVar5[1] = 0xffffffffffffffff;
            *(undefined4 *)(puVar5 + 2) = 0xffffffff;
            FUN_01765e80();
          }
          else {
            iVar2 = *(int *)(puVar5 + 1);
            if (-1 < iVar2) {
              if ((undefined2 *)((long)iVar2 + (long)piVar7) != (undefined2 *)0x0) {
                uVar11 = *(undefined2 *)((long)iVar2 + (long)piVar7);
                goto LAB_00c38ad8;
              }
              break;
            }
            if (iVar2 != -1) break;
            FUN_01765e80();
          }
          if (piVar8 == (int *)0x0) {
            uVar11 = 0xfffe;
            goto LAB_00c38ad8;
          }
          piVar9 = piVar8;
          FUN_01765e60();
          if (piVar9 == (int *)0x0) {
LAB_00c38a98:
            uVar11 = 0xfffe;
            goto LAB_00c38ad8;
          }
          FUN_01765e50();
          *(undefined4 *)(puVar5 + 1) = 0xfffffffe;
          if ((uint)piVar8 == 0) goto LAB_00c38a98;
          uVar12 = 0;
          piVar13 = piVar9 + 1;
          while (piVar9[(ulong)uVar12 * 2] != -0x489482c9) {
            uVar12 = uVar12 + 1;
            piVar13 = piVar13 + 2;
            if ((uint)piVar8 <= uVar12) goto LAB_00c38a98;
          }
          iVar2 = 0;
          if (*piVar13 != -1) {
            iVar2 = *piVar13;
          }
          *(int *)(puVar5 + 1) = iVar2;
          iVar2 = *piVar7;
        }
        uVar11 = 0xfffe;
LAB_00c38ad8:
        FUN_010588a0(auStack_70,uVar11);
        uVar10 = 0;
        FUN_01058d00();
        if ((uVar10 & 1) != 0) {
          FUN_00b0f510(param_2,auStack_70);
        }
      }
    }
    uVar14 = uVar14 + 1;
    piVar7 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
    if ((int)*(uint *)(param_1 + 0x1c8) < 1) goto LAB_00c38924;
LAB_00c38950:
    if ((uint)piVar7 <= uVar14) {
      return;
    }
  } while( true );
}

