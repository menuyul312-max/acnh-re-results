
void FUN_00c2ce90(long param_1)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  
  lVar3 = *(long *)(param_1 + 0x20);
  if (lVar3 == 0) goto LAB_00c2cf24;
  iVar1 = *(int *)(param_1 + 0x2c);
  if (iVar1 == 2) {
    plVar2 = *(long **)(lVar3 + 0x228);
    if (plVar2 != (long *)0x0) goto LAB_00c2cec8;
LAB_00c2cf18:
    lVar3 = *(long *)(param_1 + 0x20);
  }
  else {
    if (iVar1 == 1) {
      plVar2 = *(long **)(lVar3 + 0x220);
    }
    else {
      if (iVar1 != 0) goto LAB_00c2cf24;
      plVar2 = *(long **)(lVar3 + 0x218);
    }
    if (plVar2 == (long *)0x0) goto LAB_00c2cf18;
LAB_00c2cec8:
    (**(code **)(*plVar2 + 0x220))();
    if (plVar2 == (long *)0x0) goto LAB_00c2cf18;
    FUN_01785ec0();
    lVar3 = *(long *)(param_1 + 0x20);
  }
  if ((lVar3 != 0) && (*(int *)(param_1 + 0x2c) == 0)) {
    FUN_0138b7e0(*(undefined8 *)(lVar3 + 0x218));
  }
LAB_00c2cf24:
  FUN_00c1b640();
  FUN_00bea600(*(undefined8 *)(param_1 + 0x10));
  FUN_00c2cf50(*(undefined8 *)(param_1 + 0x10));
  return;
}

