
void FUN_00c34a10(undefined8 param_1,long param_2)

{
  undefined4 auStack_30 [2];
  long lStack_28;
  
  lStack_28 = param_2 + 0x20;
  auStack_30[0] = 10;
  FUN_010e4670(param_1,auStack_30);
  FUN_001234f0(param_1);
  FUN_00121d40();
  return;
}

