
void FUN_00c2ccf0(undefined8 *param_1)

{
  ulong uVar1;
  int iStack_2c;
  
  FUN_00c24b40(*param_1);
  FUN_00be6790();
  if (((iStack_2c < 6) && (*(int *)(param_1 + 5) == 2)) && (*(int *)((long)param_1 + 0x2c) == 0)) {
    uVar1 = *(ulong *)(param_1[4] + 0x218);
    FUN_0138b720(uVar1,iStack_2c);
    if ((uVar1 & 1) != 0) {
      *(int *)((long)param_1 + 0x34) = iStack_2c;
    }
  }
  return;
}

