
void FUN_00c2f840(undefined4 *param_1,long *param_2,long *param_3)

{
  ulong uVar1;
  long lVar2;
  int iVar3;
  char cVar4;
  char *pcVar5;
  long lVar6;
  long lVar7;
  long lVar8;
  
  *param_1 = 0;
  FUN_022ed6c0(param_1 + 2);
  *(undefined8 *)(param_1 + 0x10) = 0;
  pcVar5 = pcRam00000000033d0660;
  param_1[0x12] = 0;
  cVar4 = *pcVar5;
  **(char **)(param_1 + 0x16) = cVar4;
  **(char **)(param_1 + 0x2c) = cVar4;
  lVar7 = *(long *)(param_1 + 0x16);
  (**(code **)(*param_2 + 0x18))(param_2);
  lVar8 = param_2[1];
  if (lVar7 != lVar8) {
    (**(code **)(*param_2 + 0x18))(param_2);
    lVar6 = 0;
    do {
      if (*(char *)(param_2[1] + lVar6) == cVar4) goto LAB_00c2f910;
      lVar2 = param_2[1] + lVar6;
      if (*(char *)(lVar2 + 1) == cVar4) {
        lVar6 = lVar6 + 1;
        goto LAB_00c2f910;
      }
      if (*(char *)(lVar2 + 2) == cVar4) {
        lVar6 = lVar6 + 2;
        goto LAB_00c2f910;
      }
      uVar1 = lVar6 + 2;
      lVar6 = lVar6 + 3;
    } while (uVar1 >> 0x13 == 0);
    lVar6 = 0;
LAB_00c2f910:
    iVar3 = (int)lVar6;
    if ((int)param_1[0x18] <= (int)lVar6) {
      iVar3 = param_1[0x18] + -1;
    }
    memcpy(lVar7,lVar8,(long)iVar3);
    *(char *)(lVar7 + iVar3) = cVar4;
  }
  lVar7 = *(long *)(param_1 + 0x2c);
  (**(code **)(*param_3 + 0x18))(param_3);
  lVar8 = param_3[1];
  if (lVar7 != lVar8) {
    (**(code **)(*param_3 + 0x18))(param_3);
    lVar6 = 0;
    do {
      if (*(char *)(param_3[1] + lVar6) == cVar4) goto LAB_00c2f9bc;
      lVar2 = param_3[1] + lVar6;
      if (*(char *)(lVar2 + 1) == cVar4) {
        lVar6 = lVar6 + 1;
        goto LAB_00c2f9bc;
      }
      if (*(char *)(lVar2 + 2) == cVar4) {
        lVar6 = lVar6 + 2;
        goto LAB_00c2f9bc;
      }
      uVar1 = lVar6 + 2;
      lVar6 = lVar6 + 3;
    } while (uVar1 >> 0x13 == 0);
    lVar6 = 0;
LAB_00c2f9bc:
    iVar3 = (int)lVar6;
    if ((int)param_1[0x2e] <= (int)lVar6) {
      iVar3 = param_1[0x2e] + -1;
    }
    memcpy(lVar7,lVar8,(long)iVar3);
    *(char *)(lVar7 + iVar3) = cVar4;
  }
  *param_1 = 1;
  return;
}

