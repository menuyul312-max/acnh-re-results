
void FUN_00c27ac0(long param_1)

{
  *(undefined4 *)(param_1 + 0x2188) = 1;
  return;
}

