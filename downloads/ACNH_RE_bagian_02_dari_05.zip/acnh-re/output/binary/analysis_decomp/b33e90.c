
void FUN_00c33e90(long param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_00c166c0(param_1,param_2,param_3,param_4,param_5,param_6);
  *(undefined4 *)(param_1 + 0x108) = param_3;
  return;
}

