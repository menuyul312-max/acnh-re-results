
void FUN_00c288d0(long param_1,undefined4 param_2)

{
  int iVar1;
  ulong uVar2;
  undefined8 uVar3;
  
  iVar1 = *(int *)(param_1 + 0x218c);
  if (iVar1 < 0) {
    uVar2 = *(ulong *)(param_1 + 0x210);
    FUN_00c2c340();
    if ((uVar2 & 1) != 0) {
      uVar2 = *(ulong *)(param_1 + 0x210);
      FUN_00c2cd70();
      if ((uVar2 & 1) != 0) {
        uVar3 = *(undefined8 *)(param_1 + 0x210);
        FUN_00c2d400(uVar3,param_2);
        *(int *)(param_1 + 0x218c) = (int)uVar3;
        FUN_00c2cc90(*(undefined8 *)(param_1 + 0x210),param_2);
      }
    }
  }
  else {
    if (iVar1 == 0) {
      *(undefined4 *)(param_1 + 0x218c) = 0xffffffff;
      return;
    }
    *(int *)(param_1 + 0x218c) = iVar1 + -1;
  }
  FUN_0011ea00(param_1);
  *(undefined4 *)(param_1 + 0x2188) = 5;
  return;
}

