
void FUN_001b2530(long param_1)

{
  *(undefined1 *)(param_1 + 0x1928) = 1;
  return;
}

