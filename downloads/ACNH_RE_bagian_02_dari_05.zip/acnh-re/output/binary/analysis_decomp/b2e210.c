
void FUN_00c2e210(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c2e218. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))();
  return;
}

