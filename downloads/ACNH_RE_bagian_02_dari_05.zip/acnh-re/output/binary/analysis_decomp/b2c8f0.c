
void FUN_00c2c8f0(long param_1,uint param_2)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  uint auStack_38 [2];
  long lStack_30;
  undefined4 uStack_28;
  
  lVar3 = *(long *)(param_1 + 0x20);
  if (lVar3 != 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    if (iVar1 == 2) {
      plVar2 = *(long **)(lVar3 + 0x228);
    }
    else if (iVar1 == 1) {
      plVar2 = *(long **)(lVar3 + 0x220);
    }
    else {
      if (iVar1 != 0) {
        return;
      }
      plVar2 = *(long **)(lVar3 + 0x218);
    }
    if (((plVar2 != (long *)0x0) && ((**(code **)(*plVar2 + 0x220))(), plVar2 != (long *)0x0)) &&
       (plVar2 = (long *)plVar2[9], plVar2 != (long *)0x0)) {
      auStack_38[0] = ~param_2 & 1;
      lStack_30 = lRam00000000033f51d8 + 0x10;
      uStack_28 = 0x35;
      (**(code **)(*plVar2 + 0x18))(plVar2,&lStack_30);
      (**(code **)(plVar2[3] + 0x368))(plVar2[1],auStack_38);
      return;
    }
  }
  return;
}

