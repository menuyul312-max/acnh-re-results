
undefined1  [16] FUN_00c2d0e0(undefined1 param_1 [16],long param_2)

{
  undefined4 uVar1;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined1 auVar2 [16];
  
  uVar4 = param_1._8_8_;
  uVar3 = param_1._4_4_;
  uVar1 = param_1._0_4_;
  if (*(long *)(param_2 + 0x20) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c2d0f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(long **)(*(long *)(param_2 + 0x20) + 0x210) + 0x208))();
    auVar2._4_4_ = uVar3;
    auVar2._0_4_ = uVar1;
    auVar2._8_8_ = uVar4;
    return auVar2;
  }
  return ZEXT816(0);
}

