
void FUN_00c30050(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c30058. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x48))();
  return;
}

