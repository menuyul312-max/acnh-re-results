
bool FUN_00c2c430(undefined8 *param_1)

{
  int iStack_18;
  int iStack_14;
  
  FUN_00c24b40(*param_1);
  FUN_00be6790();
  if (iStack_14 < 0) {
    return false;
  }
  if (-1 < *(int *)((long)param_1 + 0x2c)) {
    if (iStack_14 == *(int *)((long)param_1 + 0x2c)) {
      return iStack_18 != *(int *)(param_1 + 6);
    }
    return true;
  }
  return false;
}

