
ulong FUN_001b3ff0(byte *param_1)

{
  uint *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  ulong uVar4;
  long lVar5;
  long lStack_58;
  long lStack_50;
  uint auStack_40 [2];
  uint auStack_38 [2];
  uint auStack_28 [2];
  
  pbVar2 = param_1;
  FUN_001b6270();
  if ((((ulong)pbVar2 & 1) != 0) &&
     ((*(long *)(param_1 + 0x10) != 0 || (*(long *)(param_1 + 8) != 0)))) {
    pbVar3 = param_1;
    FUN_001b63f0(&lStack_58);
    pbVar2 = pbRam00000000033d4b80;
    if (((*pbRam00000000033d4b80 & 1) == 0) &&
       (pbVar3 = pbRam00000000033d4b80, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
      FUN_001b55f0(puRam00000000033d4b88);
      pbVar3 = pbRam00000000033d4b80;
      __cxa_guard_release();
    }
    puVar1 = puRam00000000033d4b88;
    lVar5 = (long)(int)(uint)lStack_58;
    if (*puRam00000000033d4b88 <= (uint)lStack_58) {
      lVar5 = 0;
    }
    if (*(int *)(*(long *)(puRam00000000033d4b88 + 2) + lVar5 * 4) != 0) {
      pbVar3 = param_1;
      FUN_001b63f0(auStack_28);
      if (((*pbVar2 & 1) == 0) &&
         (pbVar3 = pbRam00000000033d4b80, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
        FUN_001b55f0(puRam00000000033d4b88);
        pbVar3 = pbRam00000000033d4b80;
        __cxa_guard_release();
      }
      lVar5 = (long)(int)auStack_28[0];
      if (*puVar1 <= auStack_28[0]) {
        lVar5 = 0;
      }
      if (*(int *)(*(long *)(puVar1 + 2) + lVar5 * 4) != 1) {
        pbVar3 = param_1;
        FUN_001b63f0(auStack_38);
        if (((*pbVar2 & 1) == 0) &&
           (pbVar3 = pbRam00000000033d4b80, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
          FUN_001b55f0(puRam00000000033d4b88);
          pbVar3 = pbRam00000000033d4b80;
          __cxa_guard_release();
        }
        lVar5 = (long)(int)auStack_38[0];
        if (*puVar1 <= auStack_38[0]) {
          lVar5 = 0;
        }
        if (*(int *)(*(long *)(puVar1 + 2) + lVar5 * 4) != 4) {
          pbVar3 = param_1;
          FUN_001b63f0(auStack_40);
          if (((*pbVar2 & 1) == 0) &&
             (pbVar3 = pbRam00000000033d4b80, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
            FUN_001b55f0(puRam00000000033d4b88);
            pbVar3 = pbRam00000000033d4b80;
            __cxa_guard_release();
          }
          lVar5 = (long)(int)auStack_40[0];
          if (*puVar1 <= auStack_40[0]) {
            lVar5 = 0;
          }
          if (*(int *)(*(long *)(puVar1 + 2) + lVar5 * 4) != 5) {
            return 0xffffffff;
          }
        }
      }
    }
    FUN_00fed050();
    if (pbVar3 != (byte *)0x0) {
      pbVar2 = param_1;
      FUN_001b62b0();
      if (((ulong)pbVar2 & 1) == 0) {
        FUN_00fe9350(&lStack_58,pbVar3,1);
        lStack_58 = lRam00000000033d4b90 + 0x10;
        uVar4 = *(long *)(lStack_50 + 0x10) + *(long *)(lStack_50 + 8);
        FUN_001b68a0(param_1);
        FUN_010791b0(uVar4,(ulong)param_1 & 0xffffffff);
      }
      else {
        FUN_00fe9350(&lStack_58,pbVar3,1);
        lStack_58 = lRam00000000033d4b90 + 0x10;
        uVar4 = *(long *)(lStack_50 + 0x10) + *(long *)(lStack_50 + 8);
        FUN_001b68a0(param_1);
        FUN_010791e0(uVar4,(ulong)param_1 & 0xffffffff);
      }
      FUN_01078ec0();
      FUN_00fe93d0(&lStack_58);
      return uVar4 & 0xffffffff;
    }
  }
  return 0xffffffff;
}

