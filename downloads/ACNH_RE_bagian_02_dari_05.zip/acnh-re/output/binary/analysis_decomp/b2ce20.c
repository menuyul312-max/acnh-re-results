
bool FUN_00c2ce20(long param_1)

{
  return *(int *)(**(long **)(param_1 + 0x18) + 0x244) == 1;
}

