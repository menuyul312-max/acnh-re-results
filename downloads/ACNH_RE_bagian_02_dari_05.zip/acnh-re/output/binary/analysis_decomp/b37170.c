
void _INIT_2666(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655e98 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655ed0);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655e9c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655ea0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655eb4 = 0xffff;
  uRam0000000003655eb0 = 0xffffffff;
  uRam0000000003655ebc = 0;
  uRam0000000003655eb8 = 0;
  uRam0000000003655ea4 = (undefined4)uVar2;
  uRam0000000003655ea8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655ec0 = uVar2;
  uRam0000000003655ec8 = 0;
  return;
}

