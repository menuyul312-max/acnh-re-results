
undefined4 FUN_00c360f0(long param_1)

{
  return *(undefined4 *)(param_1 + 0xf8);
}

