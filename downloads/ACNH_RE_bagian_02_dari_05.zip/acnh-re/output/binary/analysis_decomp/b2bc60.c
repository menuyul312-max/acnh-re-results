
void FUN_00c2bc60(long param_1)

{
  if (*(long *)(param_1 + 0x18) != 0) {
    _ZdlPv();
  }
  if (*(long **)(param_1 + 0x10) != (long *)0x0) {
    (**(code **)(**(long **)(param_1 + 0x10) + 8))();
  }
  if (*(long *)(param_1 + 8) != 0) {
    _ZdlPv();
    return;
  }
  return;
}

