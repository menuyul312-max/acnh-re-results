
long * FUN_00c2c3e0(long param_1)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  
  lVar3 = *(long *)(param_1 + 0x20);
  if (lVar3 != 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    if (iVar1 == 2) {
      plVar2 = *(long **)(lVar3 + 0x228);
    }
    else {
      if (iVar1 != 1) {
        if (iVar1 != 0) {
          return (long *)0x0;
        }
        plVar2 = *(long **)(lVar3 + 0x218);
        if (plVar2 == (long *)0x0) {
          return (long *)0x0;
        }
        goto LAB_00c2c424;
      }
      plVar2 = *(long **)(lVar3 + 0x220);
    }
    if (plVar2 != (long *)0x0) {
LAB_00c2c424:
                    /* WARNING: Could not recover jumptable at 0x00c2c42c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar2 + 0x220))();
      return plVar2;
    }
  }
  return (long *)0x0;
}

