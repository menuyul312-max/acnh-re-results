
void FUN_00c26230(undefined8 *param_1)

{
  FUN_00c2bd20(param_1[4]);
  FUN_00c2af20(*param_1);
  return;
}

