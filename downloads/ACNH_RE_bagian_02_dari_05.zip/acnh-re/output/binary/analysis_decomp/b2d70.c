
ulong FUN_001b2d70(undefined8 param_1,float *param_2,ulong param_3,long param_4)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  long *plVar4;
  ulong uVar5;
  long lVar6;
  long lVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  
  puVar3 = *(uint **)(param_4 + 0x18);
  (**(code **)(*(long *)puVar3 + 0x20))();
  (*(code *)**(undefined8 **)puVar3)();
  iVar1 = (int)puVar3;
  FUN_001b2ed0();
  if (0 < (int)*puVar3) {
    lVar6 = 0;
    do {
      if (*(int *)(*(long *)(puVar3 + 2) + lVar6 * 4) == iVar1) {
        if ((int)lVar6 != -1) goto LAB_001b2df0;
        break;
      }
      lVar6 = lVar6 + 1;
    } while (lVar6 < (int)*puVar3);
  }
  lVar6 = 0;
LAB_001b2df0:
  FUN_001b2ed0();
  lVar7 = (long)(int)(uint)lVar6;
  if (*puVar3 <= (uint)lVar6) {
    lVar7 = 0;
  }
  iVar1 = *(int *)(*(long *)(puVar3 + 2) + lVar7 * 4);
  if (iVar1 == 9) {
    plVar4 = *(long **)(param_4 + 0x18);
    (**(code **)(*plVar4 + 0x20))();
    FUN_01ffa240(param_3,plVar4,param_2);
    return param_3;
  }
  if (iVar1 == 5) {
    plVar4 = *(long **)(param_4 + 0x18);
    (**(code **)(*plVar4 + 0x20))();
    uVar2 = (uint)plVar4;
    FUN_01ff9f90();
    fVar10 = *param_2;
    fVar11 = param_2[1];
    uVar5 = (ulong)(uVar2 & 1);
    fVar8 = param_2[2];
    fVar9 = param_2[3];
    *param_2 = -fVar10;
    param_2[1] = -fVar11;
    param_2[2] = -fVar8;
    param_2[4] = fVar9 * fVar10 + param_2[4];
    param_2[5] = fVar9 * fVar11 + param_2[5];
    param_2[6] = fVar9 * fVar8 + param_2[6];
  }
  else {
    uVar5 = 0;
  }
  return uVar5;
}

