
void FUN_00c340c0(long param_1,uint param_2)

{
  ulong uVar1;
  
  param_2 = param_2 & ((int)param_2 >> 0x1f ^ 0xffffffffU);
  if (0x1e < (int)param_2) {
    param_2 = 0x1f;
  }
  uVar1 = *puRam00000000033d2050;
  FUN_001c6030(uVar1);
  FUN_00c17090(param_1,uVar1 & 0xffffffff,param_2);
  *(uint *)(param_1 + 0x108) = param_2;
  return;
}

