
void thunk_FUN_001237f0(long *param_1)

{
  *param_1 = lRam00000000033d1530 + 0x10;
  FUN_00121cb0((long)param_1 + 0x1c);
  return;
}

