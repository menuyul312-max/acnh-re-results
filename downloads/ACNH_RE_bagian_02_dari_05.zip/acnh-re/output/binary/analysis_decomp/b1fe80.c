
void FUN_00c1fe80(long param_1,undefined8 param_2)

{
  long *plVar1;
  int iVar2;
  undefined8 uVar3;
  code *UNRECOVERED_JUMPTABLE;
  long lVar4;
  ulong uVar5;
  
  if ((bRam00000000036535d8 & 1) == 0) {
    iVar2 = 0x36535d8;
    __cxa_guard_acquire();
    if (iVar2 != 0) {
      iRam0000000003653b68 = 7;
      iRam0000000003653b80 = 8;
      iRam0000000003653b98 = 9;
      uRam0000000003653b78 = 0;
      uRam0000000003653b70 = uRam00000000033f4e08;
      uRam0000000003653b88 = uRam00000000033f4e10;
      uRam0000000003653b90 = 0;
      uRam0000000003653ba0 = uRam00000000033f4e18;
      iRam0000000003653bb0 = 10;
      uRam0000000003653ba8 = 0;
      uRam0000000003653bb8 = uRam00000000033f4e20;
      iRam0000000003653bc8 = 0xb;
      uRam0000000003653bc0 = 0;
      uRam0000000003653bd0 = uRam00000000033f4e28;
      iRam0000000003653be0 = 0xc;
      uRam0000000003653bd8 = 0;
      uRam0000000003653be8 = uRam00000000033f4e30;
      iRam0000000003653bf8 = 0xd;
      uRam0000000003653bf0 = 0;
      uRam0000000003653c00 = uRam00000000033f4e38;
      iRam0000000003653c10 = 0xe;
      uRam0000000003653c08 = 0;
      uRam0000000003653c18 = uRam00000000033f4e40;
      iRam0000000003653c28 = 0xf;
      uRam0000000003653c20 = 0;
      uRam0000000003653c30 = uRam00000000033f4e48;
      iRam0000000003653c40 = 0x10;
      uRam0000000003653c38 = 0;
      uRam0000000003653c48 = uRam00000000033f4e50;
      iRam0000000003653c58 = 0x11;
      uRam0000000003653c50 = 0;
      uRam0000000003653c60 = uRam00000000033f4e58;
      iRam0000000003653c70 = 0x12;
      uRam0000000003653c68 = 0;
      uRam0000000003653c78 = uRam00000000033f4e60;
      iRam0000000003653c88 = 0x13;
      uRam0000000003653c80 = 0;
      uRam0000000003653c90 = uRam00000000033f4e68;
      iRam0000000003653ca0 = 0x15;
      uRam0000000003653c98 = 0;
      uRam0000000003653ca8 = uRam00000000033f4e70;
      iRam0000000003653cb8 = 0x16;
      uRam0000000003653cb0 = 0;
      uRam0000000003653cc0 = uRam00000000033f4e78;
      iRam0000000003653cd0 = 0x17;
      uRam0000000003653cc8 = 0;
      uRam0000000003653cd8 = uRam00000000033f4e80;
      iRam0000000003653ce8 = 0x18;
      uRam0000000003653ce0 = 0;
      uRam0000000003653cf0 = uRam00000000033f4e88;
      iRam0000000003653d00 = 0x19;
      uRam0000000003653cf8 = 0;
      uRam0000000003653d08 = uRam00000000033f4e90;
      iRam0000000003653d18 = 0x1a;
      uRam0000000003653d10 = 0;
      uRam0000000003653d20 = uRam00000000033f4e98;
      iRam0000000003653d30 = 0x1b;
      uRam0000000003653d28 = 0;
      uRam0000000003653d38 = uRam00000000033f4ea0;
      iRam0000000003653d48 = 0x1c;
      uRam0000000003653d40 = 0;
      uRam0000000003653d50 = uRam00000000033f4ea8;
      iRam0000000003653d60 = 0x1d;
      uRam0000000003653d58 = 0;
      uRam0000000003653d68 = uRam00000000033f4eb0;
      iRam0000000003653d78 = 0x1e;
      uRam0000000003653d70 = 0;
      uRam0000000003653d80 = uRam00000000033f4eb8;
      iRam0000000003653d90 = 0x1f;
      uRam0000000003653d88 = 0;
      uRam0000000003653d98 = uRam00000000033f4ec0;
      iRam0000000003653da8 = 0x20;
      uRam0000000003653da0 = 0;
      uRam0000000003653db0 = uRam00000000033f4ec8;
      iRam0000000003653dc0 = 0x21;
      uRam0000000003653db8 = 0;
      uRam0000000003653dd0 = 0;
      uRam0000000003653dc8 = uRam00000000033f4ed0;
      __cxa_guard_release(0x36535d8);
    }
  }
  uVar3 = param_2;
  FUN_001222a0();
  lVar4 = 0x3653b68;
  iVar2 = (int)uVar3;
  if (((((((((iRam0000000003653b68 == iVar2) || (lVar4 = 0x3653b80, iRam0000000003653b80 == iVar2))
           || (lVar4 = 0x3653b98, iRam0000000003653b98 == iVar2)) ||
          ((lVar4 = 0x3653bb0, iRam0000000003653bb0 == iVar2 ||
           (lVar4 = 0x3653bc8, iRam0000000003653bc8 == iVar2)))) ||
         (lVar4 = 0x3653be0, iRam0000000003653be0 == iVar2)) ||
        (((lVar4 = 0x3653bf8, iRam0000000003653bf8 == iVar2 ||
          (lVar4 = 0x3653c10, iRam0000000003653c10 == iVar2)) ||
         ((lVar4 = 0x3653c28, iRam0000000003653c28 == iVar2 ||
          (((lVar4 = 0x3653c40, iRam0000000003653c40 == iVar2 ||
            (lVar4 = 0x3653c58, iRam0000000003653c58 == iVar2)) ||
           (lVar4 = 0x3653c70, iRam0000000003653c70 == iVar2)))))))) ||
       ((lVar4 = 0x3653c88, iRam0000000003653c88 == iVar2 ||
        (lVar4 = 0x3653ca0, iRam0000000003653ca0 == iVar2)))) ||
      (((lVar4 = 0x3653cb8, iRam0000000003653cb8 == iVar2 ||
        (((lVar4 = 0x3653cd0, iRam0000000003653cd0 == iVar2 ||
          (lVar4 = 0x3653ce8, iRam0000000003653ce8 == iVar2)) ||
         ((lVar4 = 0x3653d00, iRam0000000003653d00 == iVar2 ||
          (((lVar4 = 0x3653d18, iRam0000000003653d18 == iVar2 ||
            (lVar4 = 0x3653d30, iRam0000000003653d30 == iVar2)) ||
           (lVar4 = 0x3653d48, iRam0000000003653d48 == iVar2)))))))) ||
       (((lVar4 = 0x3653d60, iRam0000000003653d60 == iVar2 ||
         (lVar4 = 0x3653d78, iRam0000000003653d78 == iVar2)) ||
        (lVar4 = 0x3653d90, iRam0000000003653d90 == iVar2)))))) ||
     ((lVar4 = 0x3653da8, iRam0000000003653da8 == iVar2 ||
      (lVar4 = 0x3653dc0, iRam0000000003653dc0 == iVar2)))) {
    UNRECOVERED_JUMPTABLE = *(code **)(lVar4 + 8);
    uVar5 = *(ulong *)(lVar4 + 0x10) & 1;
    if (UNRECOVERED_JUMPTABLE != (code *)0x0 || uVar5 != 0) {
      plVar1 = (long *)(param_1 + ((long)*(ulong *)(lVar4 + 0x10) >> 1));
      if (uVar5 != 0) {
        UNRECOVERED_JUMPTABLE = *(code **)(UNRECOVERED_JUMPTABLE + *plVar1);
      }
                    /* WARNING: Could not recover jumptable at 0x00c200e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(plVar1,param_2);
      return;
    }
  }
  return;
}

