
undefined4 FUN_00c23380(long *param_1)

{
  long lVar1;
  long *plVar2;
  byte *pbVar3;
  undefined4 uVar4;
  long *plStack_30;
  char cStack_27;
  undefined4 auStack_18 [2];
  
  lVar1 = *param_1;
  FUN_00c24b30();
  if (lVar1 == 0) {
    uVar4 = 0xffffffff;
  }
  else {
    auStack_18[0] = *(undefined4 *)(lVar1 + 8);
    FUN_0013fa40(&plStack_30,auStack_18,0);
    plVar2 = plStack_30;
    if (plStack_30 != (long *)0x0) {
      if ((*pbRam00000000033d2630 & 1) == 0) {
        pbVar3 = pbRam00000000033d2630;
        __cxa_guard_acquire();
        if ((int)pbVar3 != 0) {
          *plRam00000000033d2638 = lRam00000000033d2640 + 0x10;
          __cxa_guard_release(pbRam00000000033d2630);
        }
      }
      (**(code **)(*plVar2 + 0x20))(plVar2,plRam00000000033d2638);
      if (((ulong)plVar2 & 1) == 0) {
        cStack_27 = '\0';
      }
    }
    if ((cStack_27 == '\0') || (plStack_30 == (long *)0x0)) {
      uVar4 = 0xffffffff;
    }
    else {
      uVar4 = (undefined4)plStack_30[0x89];
    }
    FUN_0013fcc0(&plStack_30);
  }
  return uVar4;
}

