
void FUN_001b3c60(long param_1,undefined8 param_2)

{
  *(undefined1 *)(param_1 + 0xe58) = 0;
  *(undefined4 *)(param_1 + 0x728) = 0;
  *(undefined8 *)(param_1 + 0x14) = 0;
  *(int *)(param_1 + 0x72c) = (int)param_2;
  *(undefined8 *)(param_1 + 0x73c) = 0;
  *(undefined4 *)(param_1 + 0xe50) = 0;
  *(int *)(param_1 + 0xe54) = (int)((ulong)param_2 >> 0x20);
  return;
}

