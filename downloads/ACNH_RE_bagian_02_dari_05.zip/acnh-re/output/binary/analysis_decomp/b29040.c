
uint FUN_00c29040(long param_1)

{
  long *plVar1;
  long *plVar2;
  
  plVar2 = (long *)(param_1 + 0x88);
  plVar1 = plVar2;
  (**(code **)(*plVar2 + 0x10))();
  if (((ulong)plVar1 & 1) != 0) {
    (**(code **)*plVar2)(plVar2);
  }
  return (uint)plVar1 & 1;
}

