
void FUN_00c33f30(long param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00c16f90(param_1,param_2);
  *(undefined4 *)(param_1 + 0x108) = param_3;
  return;
}

