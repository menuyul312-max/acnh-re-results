
ulong FUN_00c1e5e0(long *param_1,long param_2)

{
  long lVar1;
  long lVar2;
  long *plVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  uint uVar7;
  long lVar8;
  ulong uVar9;
  int iVar10;
  long lVar11;
  ulong uVar12;
  long lVar13;
  int iVar14;
  short *psVar15;
  long lStack_60;
  long lStack_58;
  
  lVar2 = lRam00000000033f4dc0;
  plVar3 = (long *)*param_1;
  lStack_60 = lRam00000000033f4dc0 + 0x10;
  lStack_58 = param_1[3];
  iVar14 = (int)param_1[1];
  lVar13 = (long)iVar14;
  (**(code **)(*plVar3 + 0x18))(plVar3);
  lVar8 = plVar3[1];
  sVar4 = *psRam00000000033d14d0;
  lVar11 = 0;
  do {
    if (*(short *)(lVar8 + lVar11 * 2) == sVar4) goto LAB_00c1e690;
    lVar1 = lVar8 + lVar11 * 2;
    if (*(short *)(lVar1 + 2) == sVar4) {
      iVar10 = (int)lVar11 + 1;
      goto joined_r0x00c1e7b8;
    }
    if (*(short *)(lVar1 + 4) == sVar4) {
      iVar10 = (int)lVar11 + 2;
      if (iVar14 < 0) goto LAB_00c1e74c;
      goto LAB_00c1e694;
    }
    uVar9 = lVar11 + 2;
    lVar11 = lVar11 + 3;
  } while (uVar9 >> 0x13 == 0);
  lVar11 = 0;
LAB_00c1e690:
  iVar10 = (int)lVar11;
joined_r0x00c1e7b8:
  if (-1 < iVar14) {
LAB_00c1e694:
    if (iVar14 <= iVar10) {
      psVar15 = (short *)(lVar8 + lVar13 * 2);
      if (*psVar15 != sVar4) {
        lVar11 = lVar2 + 0x10;
        do {
          (**(code **)(lVar11 + 0x18))(&lStack_60);
          sVar5 = *psVar15;
          uVar9 = 0;
          do {
            sVar6 = *(short *)(lStack_58 + uVar9 * 2);
            if (sVar6 == sVar4) break;
            if (sVar6 == sVar5) goto LAB_00c1e740;
            lVar11 = lStack_58 + uVar9 * 2;
            sVar6 = *(short *)(lVar11 + 2);
            if (sVar6 == sVar4) break;
            if (sVar6 == sVar5) goto LAB_00c1e740;
            sVar6 = *(short *)(lVar11 + 4);
            if (sVar6 == sVar4) break;
            if (sVar6 == sVar5) goto LAB_00c1e740;
            uVar9 = uVar9 + 3;
          } while (uVar9 < 0x80001);
          lVar13 = lVar13 + 1;
          psVar15 = (short *)(plVar3[1] + lVar13 * 2);
          lVar11 = lStack_60;
        } while (*psVar15 != sVar4);
LAB_00c1e740:
        iVar14 = (int)lVar13;
      }
      iVar14 = iVar14 + 1;
    }
  }
LAB_00c1e74c:
  uVar7 = *(uint *)(param_1 + 1);
  param_1 = (long *)*param_1;
  uVar9 = (ulong)(iVar14 + ~uVar7);
  (**(code **)(*param_1 + 0x18))(param_1);
  lVar13 = param_1[1];
  lVar11 = 0;
  do {
    if (*(short *)(lVar13 + lVar11 * 2) == sVar4) goto LAB_00c1e7d8;
    lVar2 = lVar13 + lVar11 * 2;
    if (*(short *)(lVar2 + 2) == sVar4) {
      lVar11 = lVar11 + 1;
      goto LAB_00c1e7d8;
    }
    if (*(short *)(lVar2 + 4) == sVar4) {
      lVar11 = lVar11 + 2;
      goto LAB_00c1e7d8;
    }
    uVar12 = lVar11 + 2;
    lVar11 = lVar11 + 3;
  } while (uVar12 >> 0x13 == 0);
  lVar11 = 0;
LAB_00c1e7d8:
  lVar8 = *(long *)(param_2 + 8);
  lVar2 = *(long *)(lRam00000000033f4dc8 + 8);
  if ((int)uVar7 <= (int)lVar11 && -1 < (int)uVar7) {
    lVar2 = lVar13 + (long)(int)uVar7 * 2;
  }
  if (lVar8 == lVar2) {
    uVar9 = 0;
  }
  else {
    if ((int)(iVar14 + ~uVar7) < 0) {
      uVar9 = 0;
      do {
        if (*(short *)(lVar2 + uVar9 * 2) == sVar4) goto LAB_00c1e804;
        lVar11 = lVar2 + uVar9 * 2;
        if (*(short *)(lVar11 + 2) == sVar4) {
          uVar9 = uVar9 + 1;
          goto LAB_00c1e804;
        }
        if (*(short *)(lVar11 + 4) == sVar4) {
          uVar9 = uVar9 + 2;
          goto LAB_00c1e804;
        }
        uVar12 = uVar9 + 2;
        uVar9 = uVar9 + 3;
      } while (uVar12 >> 0x13 == 0);
      uVar9 = 0;
    }
LAB_00c1e804:
    uVar7 = (uint)uVar9;
    if (*(int *)(param_2 + 0x10) <= (int)(uint)uVar9) {
      uVar7 = *(int *)(param_2 + 0x10) - 1;
    }
    uVar9 = (ulong)uVar7;
    uVar12 = -(ulong)(uVar7 >> 0x1f) & 0xfffffffe00000000 | uVar9 << 1;
    memcpy(lVar8,lVar2,uVar12);
    *(short *)(lVar8 + uVar12) = sVar4;
  }
  return uVar9;
}

