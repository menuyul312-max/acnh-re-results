
void FUN_00c24900(long param_1)

{
  FUN_00c0dc50(param_1 + 0x2608);
  return;
}

