
bool FUN_00c38480(ulong param_1,undefined4 *param_2,undefined8 param_3)

{
  bool bVar1;
  ulong uVar2;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  long lStack_68;
  undefined1 *puStack_60;
  undefined4 uStack_58;
  undefined1 auStack_54 [36];
  
  uVar2 = *puRam00000000033d3ef0;
  FUN_00c41ec0(uVar2);
  puStack_60 = auStack_54;
  lStack_68 = lRam00000000033d0670 + 0x10;
  uStack_58 = 0x20;
  FUN_01a90780(&lStack_68);
  lStack_68 = lRam00000000033d0680;
  *puStack_60 = *puRam00000000033d0660;
  lStack_68 = lStack_68 + 0x10;
  FUN_00c38550(param_1,&uStack_78,param_3,uVar2 & 0xffffffff);
  bVar1 = (param_1 & 1) != 0;
  if (bVar1) {
    *param_2 = uStack_78;
    param_2[1] = uStack_74;
    param_2[2] = uStack_70;
  }
  return bVar1;
}

