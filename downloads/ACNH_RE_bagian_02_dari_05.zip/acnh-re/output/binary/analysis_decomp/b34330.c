
void FUN_00c34330(long param_1,undefined4 param_2,long param_3)

{
  uint uVar1;
  
  uVar1 = (int)*(char *)(param_3 + 6) & ((int)*(char *)(param_3 + 6) >> 0x1f ^ 0xffffffffU);
  if (0x3a < (int)uVar1) {
    uVar1 = 0x3b;
  }
  FUN_00c17220(param_1,param_2,uVar1);
  *(uint *)(param_1 + 0x108) = uVar1;
  return;
}

