
void FUN_00c3ac50(ulong param_1)

{
  long lVar1;
  int iVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  uint uVar7;
  
  FUN_01766670();
  if ((param_1 != 0) && (uVar3 = param_1, FUN_01765e30(), (uint)uVar3 != 0)) {
    uVar7 = 0;
    do {
      uVar4 = param_1;
      FUN_01765e30();
      if ((uVar7 < (uint)uVar4) && (uVar4 = param_1, FUN_01765e40(), (int)uVar4 != 0)) {
        uVar5 = param_1;
        FUN_01765e50();
        if ((int)uVar5 != 0) {
          uVar6 = param_1;
          FUN_01765df0();
          iVar2 = 0x1c;
          if ((uVar6 & 1) == 0) {
            iVar2 = 0xc;
          }
          lVar1 = ((int)uVar4 * uVar7 + (int)uVar5 * 8 + iVar2) + param_1;
          if (lVar1 != 0) {
            FUN_00c3ad10(lVar1);
          }
        }
      }
      uVar7 = uVar7 + 1;
    } while ((uint)uVar3 != uVar7);
  }
  return;
}

