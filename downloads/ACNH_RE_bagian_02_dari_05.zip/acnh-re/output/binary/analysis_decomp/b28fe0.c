
uint FUN_00c28fe0(long param_1,undefined8 param_2)

{
  long *plVar1;
  long *plVar2;
  
  plVar2 = (long *)(param_1 + 0x68);
  plVar1 = plVar2;
  (**(code **)(*plVar2 + 0x10))();
  if (((ulong)plVar1 & 1) != 0) {
    (**(code **)*plVar2)(plVar2,param_2);
  }
  return (uint)plVar1 & 1;
}

