
undefined8 FUN_00c23c00(long *param_1)

{
  return *(undefined8 *)(*param_1 + 8);
}

