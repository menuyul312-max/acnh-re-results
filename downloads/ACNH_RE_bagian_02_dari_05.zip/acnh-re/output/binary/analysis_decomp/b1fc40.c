
void FUN_00c1fc40(long param_1,undefined8 param_2)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  ulong uVar4;
  undefined1 auStack_178 [184];
  ushort auStack_c0 [8];
  undefined1 auStack_b0 [112];
  uint uStack_34;
  
  FUN_00122290(param_2);
  uVar2 = param_2;
  FUN_001222a0();
  iVar1 = (uint)uVar2 + 2;
  if (6 < (uint)uVar2) {
    iVar1 = 2;
  }
  FUN_00122470(param_2,auStack_c0,iVar1);
  uVar2 = *(undefined8 *)(param_1 + 0x28);
  uVar3 = *(undefined8 *)(param_1 + 0x30);
  FUN_00c0dc50(uVar3);
  FUN_00c18100(auStack_178,uVar2,uVar3);
  uVar4 = param_1 + 0x38;
  FUN_016bbdc0(0x3f800000,uVar4,auStack_178,iVar1);
  uStack_34 = (uint)auStack_c0[uVar4 & 0xffffffff];
  FUN_00c0da50(auStack_b0);
  FUN_00c0e090(auStack_b0,&uStack_34,&UNK_02af8de4);
  (*(code *)**(undefined8 **)(param_1 + 8))((undefined8 *)(param_1 + 8),auStack_b0);
  FUN_00c0dad0(auStack_b0);
  FUN_00c18340(auStack_178);
  return;
}

