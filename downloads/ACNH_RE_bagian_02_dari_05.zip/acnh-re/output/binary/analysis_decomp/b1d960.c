
void FUN_00c1d960(long *param_1)

{
  *param_1 = lRam00000000033f4da0 + 0x10;
  FUN_001220d0(param_1 + 0x42);
  FUN_001219a0(param_1);
  return;
}

