
void FUN_00c204e0(long param_1)

{
  int iVar1;
  int iVar2;
  long *plVar3;
  undefined8 uVar4;
  int iVar5;
  undefined1 auStack_e0 [116];
  int iStack_6c;
  long alStack_68 [3];
  undefined1 auStack_4c [24];
  int iStack_34;
  
  iVar5 = (int)*(undefined8 *)(param_1 + 0x30);
  iVar1 = iVar5;
  FUN_00c0dc60();
  iVar2 = iVar5;
  FUN_00c0dc30();
  iStack_34 = iVar2;
  FUN_00c0dc40();
  if (((iVar5 == -1) && (iVar1 == 1)) && (iVar2 != -1)) {
    uVar4 = *(undefined8 *)(param_1 + 0x28);
    alStack_68[0] = lRam00000000033f4178 + 0x10;
    FUN_0176aa90(alStack_68,100,auStack_4c);
    alStack_68[0] = lRam00000000033f4e00 + 0x10;
    FUN_00c232e0(alStack_68,uVar4,iVar2);
    iStack_6c = 0;
    do {
      plVar3 = alStack_68;
      FUN_0176ab50(plVar3,iStack_6c);
      if (((ulong)plVar3 & 1) != 0) {
        FUN_00c0da50(auStack_e0);
        FUN_00c0e090(auStack_e0,&iStack_34,&iStack_6c);
        (*(code *)**(undefined8 **)(param_1 + 8))((undefined8 *)(param_1 + 8),auStack_e0);
        FUN_00c0dad0(auStack_e0);
      }
      iStack_6c = iStack_6c + 1;
    } while (iStack_6c < 100);
  }
  return;
}

