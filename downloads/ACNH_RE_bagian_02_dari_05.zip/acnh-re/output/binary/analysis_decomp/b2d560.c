
void FUN_00c2d560(undefined8 *param_1)

{
  FUN_01385c40(*param_1);
  return;
}

