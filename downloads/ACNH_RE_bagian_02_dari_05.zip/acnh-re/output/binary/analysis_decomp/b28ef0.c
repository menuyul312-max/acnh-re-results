
undefined8 FUN_00c28ef0(long param_1)

{
  return *(undefined8 *)(param_1 + 0x20);
}

