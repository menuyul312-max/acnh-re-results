
void FUN_00c32ec0(long *param_1,undefined1 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  long *plVar4;
  undefined1 *puVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  long lVar9;
  long lStack_88;
  undefined1 *puStack_80;
  int iStack_78;
  undefined1 auStack_74 [36];
  long lStack_50;
  undefined1 *puStack_48;
  undefined2 uStack_38;
  undefined1 uStack_36;
  
  lVar9 = lRam00000000033f5250 + 0x10;
  *param_1 = lVar9;
  FUN_00123650(param_1,param_1 + 0x1c,0x17);
  *param_1 = lVar9;
  *(undefined8 *)((long)param_1 + 0x106) = 0;
  param_1[0x1c] = 0;
  uVar6 = (long)param_1 + 0x10eU;
  if ((long)param_1 + 0x10eU <= (long)param_1 + 0xe2U) {
    uVar6 = (long)param_1 + 0xe2U;
  }
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  memset(param_1 + 0x1c,0,(uVar6 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  uStack_38 = 0x23;
  uStack_36 = 8;
  puStack_80 = auStack_74;
  lStack_88 = lRam00000000033d0670 + 0x10;
  iStack_78 = 0x20;
  FUN_01a90780(&lStack_88);
  puVar5 = puStack_80;
  lStack_88 = lRam00000000033d0678 + 0x10;
  if (puStack_80 != param_2) {
    cVar2 = *pcRam00000000033d0660;
    uVar6 = 0;
    uVar7 = 2;
    do {
      uVar8 = uVar6;
      if (param_2[uVar7 - 2] == cVar2) goto LAB_00c32ffc;
      if (param_2[uVar7 - 1] == cVar2) {
        uVar8 = uVar6 + 1;
        goto LAB_00c32ffc;
      }
      uVar8 = uVar7;
      if (param_2[uVar7] == cVar2) goto LAB_00c32ffc;
      uVar6 = uVar6 + 3;
      uVar8 = uVar7 >> 0x13;
      uVar7 = uVar7 + 3;
    } while (uVar8 == 0);
    uVar8 = 0;
LAB_00c32ffc:
    iVar1 = (int)uVar8;
    if (iStack_78 <= (int)uVar8) {
      iVar1 = iStack_78 + -1;
    }
    memcpy(puStack_80,param_2,(long)iVar1);
    puVar5[iVar1] = cVar2;
  }
  lStack_88 = lRam00000000033d0680 + 0x10;
  FUN_00dd3780(&uStack_38,&lStack_88);
  uVar6 = 0;
  FUN_00dd3400();
  if ((uVar6 & 1) != 0) {
    uVar3 = SUB84(&uStack_38,0);
    FUN_00e35570();
    lStack_88 = CONCAT44(lStack_88._4_4_,uVar3);
    plVar4 = param_1;
    FUN_00c330e0(param_1,&lStack_88);
    if (((ulong)plVar4 & 1) != 0) {
      return;
    }
  }
  lVar9 = *plRam00000000033d3788;
  puVar5 = param_2;
  FUN_00101bf0(param_2,0);
  lStack_88 = CONCAT44(lStack_88._4_4_,(int)puVar5);
  FUN_00189ce0(lVar9,&lStack_88);
  if (lVar9 != 0) {
    lStack_88 = lRam00000000033d0668 + 0x10;
    puStack_80 = &UNK_02a9c831;
    lStack_50 = lStack_88;
    puStack_48 = param_2;
    FUN_00123860(param_1,&lStack_88,&lStack_50,0);
  }
  return;
}

