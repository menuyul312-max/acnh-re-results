
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c277d0(long param_1)

{
  long lVar1;
  undefined1 *puVar2;
  undefined1 auStack_238 [520];
  
  lVar1 = *(long *)(param_1 + 0x208);
  FUN_00c24b20();
  if (lVar1 != 0) {
    FUN_00c28f20();
  }
  FUN_00bee3d0(param_1 + 0xbe0,(uint)lVar1 & 1);
  FUN_00beed40(auStack_238);
  puVar2 = auStack_238;
  FUN_00beedc0(puVar2,param_1 + 0x6f8);
  *(int *)(param_1 + 0xbd8) = (int)puVar2;
  thunk_FUN_001219a0(auStack_238);
  FUN_00be4210(_UNK_02ad5cdc,param_1 + 0x1030,param_1 + 0x1488,param_1 + 0x1af8);
  *(undefined1 *)(param_1 + 0x1480) = 0;
  FUN_0011e470(param_1);
  FUN_0011e520(param_1,param_1 + 0x6f8);
  return;
}

