
void FUN_00c30970(long param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  long lVar2;
  undefined8 uVar3;
  
  lVar1 = param_1 + 0x208;
  FUN_00c2ff80(lVar1);
  FUN_00c2ffa0(lVar1,param_2);
  FUN_010589e0(param_1 + 0x5d8,param_3);
  lVar2 = lVar1;
  FUN_00c30040(lVar1);
  FUN_00123ea0(param_1 + 0x5e0,lVar2,0);
  *(undefined1 *)(param_1 + 0x610) = 0;
  FUN_0011e470(param_1);
  uVar3 = param_2;
  FUN_00c30040(param_2);
  FUN_0011e520(param_1,uVar3);
  FUN_0011e660(param_1);
  lVar2 = lVar1;
  FUN_00c30060(lVar1);
  FUN_00123ea0(param_1 + 0x5e0,lVar2,0);
  *(undefined1 *)(param_1 + 0x610) = 1;
  FUN_0011e470(param_1);
  uVar3 = param_2;
  FUN_00c30060(param_2);
  FUN_0011e520(param_1,uVar3);
  FUN_0011e660(param_1);
  FUN_00c2ff90(param_2,lVar1);
  return;
}

