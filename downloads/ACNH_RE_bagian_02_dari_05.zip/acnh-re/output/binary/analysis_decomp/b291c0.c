
void FUN_00c291c0(long param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = (undefined8 *)(param_1 + 0x108);
  puVar2 = puVar1;
  (**(code **)(*(long *)(param_1 + 0x108) + 0x10))();
  if (((ulong)puVar2 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c29200. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*puVar1)(puVar1,param_2);
    return;
  }
  FUN_001232c0(param_2);
  return;
}

