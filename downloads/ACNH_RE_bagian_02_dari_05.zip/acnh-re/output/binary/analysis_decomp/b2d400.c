
undefined4 FUN_00c2d400(long param_1,int param_2)

{
  uint uVar1;
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    return 0;
  }
  if (5 < *(uint *)(param_1 + 0x34)) {
    return 0;
  }
  uVar1 = 1 << (ulong)(*(uint *)(param_1 + 0x34) & 0x1f);
  if ((uVar1 & 9) != 0) {
    if (param_2 == 2) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x70);
    }
    if (param_2 == 1) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x6c);
    }
    return 0;
  }
  if ((uVar1 & 0x12) == 0) {
    if (param_2 == 1) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x80);
    }
    if (param_2 == 0) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x7c);
    }
    return 0;
  }
  if (param_2 == 2) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x78);
  }
  if (param_2 == 0) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x74);
  }
  return 0;
}

