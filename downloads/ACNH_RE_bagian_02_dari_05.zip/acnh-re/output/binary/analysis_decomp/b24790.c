
uint FUN_00c24790(long param_1)

{
  int iVar1;
  ulong uVar2;
  ulong uVar3;
  
  iVar1 = *(int *)(param_1 + 0x48);
  uVar3 = param_1 + 0x2540;
  uVar2 = uVar3;
  FUN_00c0e780();
  if ((iVar1 == 0) && ((uVar2 & 1) == 0)) {
    return 1;
  }
  if (*(int *)(param_1 + 0x48) == 7) {
    return 1;
  }
  if (*(int *)(param_1 + 0x48) == 8) {
    FUN_00c0e780(uVar3);
    return ~(uint)uVar3 & 1;
  }
  return 0;
}

