
void FUN_00c30060(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c30068. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x50))();
  return;
}

