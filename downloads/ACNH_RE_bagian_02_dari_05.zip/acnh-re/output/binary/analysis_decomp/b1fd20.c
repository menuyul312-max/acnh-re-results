
void FUN_00c1fd20(long param_1)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  long lVar4;
  ulong uVar5;
  undefined8 uVar6;
  undefined1 auStack_130 [184];
  long alStack_78 [3];
  int iStack_60;
  undefined1 auStack_5c [20];
  int iStack_48;
  int iStack_44;
  
  uVar5 = *(ulong *)(param_1 + 0x30);
  uVar1 = uVar5;
  FUN_00c0dc60();
  uVar2 = uVar5;
  FUN_00c0dc30();
  uVar3 = uVar5;
  iStack_44 = (int)uVar2;
  FUN_00c0dc40();
  if ((((int)uVar3 == -1) && ((int)uVar1 == 1)) && ((int)uVar2 != -1)) {
    uVar6 = *(undefined8 *)(param_1 + 0x28);
    iStack_48 = -1;
    alStack_78[0] = lRam00000000033f4178 + 0x10;
    FUN_0176aa90(alStack_78,100,auStack_5c);
    alStack_78[0] = lRam00000000033f4e00 + 0x10;
    FUN_00c232e0(alStack_78,uVar6,uVar2 & 0xffffffff);
    FUN_00c0dc50(uVar5);
    FUN_00c18100(auStack_130,uVar6,uVar5);
    if (iStack_60 < 1) {
      FUN_00c18340(auStack_130);
    }
    else {
      lVar4 = param_1 + 0x1880;
      *(long **)(param_1 + 0x30c8) = alStack_78;
      FUN_016bbdc0(0x3f800000,lVar4,auStack_130);
      *(undefined8 *)(param_1 + 0x30c8) = 0;
      iStack_48 = (int)lVar4;
      FUN_00c18340(auStack_130);
      if (0 < (int)lVar4) {
        FUN_00c0da50(auStack_130);
        FUN_00c0e090(auStack_130,&iStack_44,&iStack_48);
        (*(code *)**(undefined8 **)(param_1 + 8))((undefined8 *)(param_1 + 8),auStack_130);
        FUN_00c0dad0(auStack_130);
      }
    }
  }
  return;
}

