
bool FUN_001b3f80(ulong param_1)

{
  ulong uVar1;
  
  uVar1 = param_1;
  FUN_001b6270();
  if ((uVar1 & 1) == 0) {
    return false;
  }
  if (*(long *)(param_1 + 0x10) != 0) {
    return true;
  }
  return *(long *)(param_1 + 8) != 0;
}

