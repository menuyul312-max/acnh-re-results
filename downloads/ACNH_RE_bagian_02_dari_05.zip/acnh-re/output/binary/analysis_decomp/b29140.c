
void FUN_00c29140(long param_1,undefined8 *param_2,undefined8 *param_3)

{
  long *plVar1;
  long *plVar2;
  
  plVar2 = (long *)(param_1 + 0xe8);
  plVar1 = plVar2;
  (**(code **)(*plVar2 + 0x10))();
  if (((ulong)plVar1 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c29190. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*plVar2)(plVar2,param_2,param_3);
    return;
  }
  if (param_2 != (undefined8 *)0x0) {
    *param_2 = 0;
    param_2[1] = 0x3f80000000000000;
  }
  if (param_3 != (undefined8 *)0x0) {
    *param_3 = 0x3f8000003f800000;
    param_3[1] = 0x3f8000003f800000;
  }
  return;
}

