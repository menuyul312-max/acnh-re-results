
void FUN_00c26890(ulong param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  ulong uVar4;
  undefined4 uStack_24;
  
  iVar1 = *(int *)(param_1 + 0xb0);
  if (iVar1 == 0) {
    uVar2 = *(undefined8 *)(param_1 + 0x20);
    FUN_00c2cff0();
    FUN_00bea870();
    uVar3 = uVar2;
    FUN_00be9e00();
    uStack_24 = (undefined4)uVar3;
    FUN_00c0e090(param_1 + 0x2540,&uStack_24,&UNK_02af8e20);
    uVar4 = param_1;
    FUN_00c269f0(param_1,uVar2);
    if (*(long *)(param_1 + 0xb8) != 0) {
      FUN_00c290f0(*(long *)(param_1 + 0xb8),uVar2);
    }
    if ((uVar4 & 1) == 0) {
      *(undefined4 *)(param_1 + 0xb0) = 0xe;
      *(undefined4 *)(param_1 + 0xb0) = 0xf;
      goto LAB_00c26934;
    }
    iVar1 = *(int *)(param_1 + 0xb0);
    *(int *)(param_1 + 0xb0) = iVar1 + 1;
  }
  else {
    *(int *)(param_1 + 0xb0) = iVar1 + 1;
  }
  if (iVar1 < 0xe) {
    return;
  }
LAB_00c26934:
  if (*(long *)(param_1 + 0xb8) != 0) {
    FUN_00c29040();
  }
  if (*(char *)(param_1 + 0x246d) != '\0') {
    FUN_00c27b00(*(undefined8 *)(param_1 + 0x28),0);
    *(undefined4 *)(param_1 + 0x2464) = 0xffffffff;
    *(undefined1 *)(param_1 + 0x2462) = 0;
    *(undefined1 *)(param_1 + 0x246e) = 0;
    *(undefined8 *)(param_1 + 0x2408) = 0xffffffffffffd8f0;
    *(undefined1 *)(param_1 + 0xac) = 0;
    *(undefined8 *)(param_1 + 0x2410) = 0;
    *(undefined4 *)(param_1 + 0x2418) = 0xffffffff;
    FUN_00122110(param_1 + 0x2420);
    *(undefined4 *)(param_1 + 0x2448) = 0;
    *(undefined2 *)(param_1 + 0x244c) = 0;
    FUN_020067b0(param_1 + 0x40,6);
    return;
  }
  FUN_00c26710(param_1);
  return;
}

