
bool FUN_00c2c4d0(undefined8 *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uStack_24;
  int iStack_18;
  uint uStack_14;
  
  FUN_00c24b40(*param_1);
  FUN_00be6790();
  uVar2 = *(uint *)((long)param_1 + 0x34);
  uVar3 = *(uint *)((long)param_1 + 0x2c);
  uVar1 = uVar2 - 3;
  if (2 < uVar2 - 3) {
    uVar1 = uVar2;
  }
  if (uVar3 == 0) {
    uVar2 = uVar1;
  }
  if ((int)(uStack_14 | uVar3) < 0) {
    return false;
  }
  if (uStack_14 != uVar3) {
    return true;
  }
  if (iStack_18 == *(int *)(param_1 + 6)) {
    return uStack_24 != uVar2;
  }
  return true;
}

