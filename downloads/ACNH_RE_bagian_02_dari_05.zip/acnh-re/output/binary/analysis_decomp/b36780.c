
uint FUN_00c36780(undefined8 param_1,undefined8 *param_2)

{
  undefined1 auStack_30 [16];
  
  FUN_0106bae0();
  FUN_00117990(auStack_30,1,*param_2);
  FUN_00c367e0(param_1,auStack_30,&UNK_02af0916);
  return (uint)param_1 & 1;
}

