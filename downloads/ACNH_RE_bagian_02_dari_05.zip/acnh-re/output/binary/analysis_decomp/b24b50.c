
void FUN_00c24b50(long param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  uVar1 = *puRam00000000033d0f28;
  FUN_00c12820(uVar1);
  uVar2 = *(undefined8 *)(param_1 + 8);
  FUN_00bfb360(uVar2);
  FUN_00c02990(uVar1,uVar2);
  return;
}

