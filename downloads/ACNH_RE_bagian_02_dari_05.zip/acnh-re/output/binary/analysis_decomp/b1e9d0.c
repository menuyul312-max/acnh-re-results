
void FUN_00c1e9d0(long param_1,undefined4 param_2)

{
  long *plVar1;
  long lVar2;
  byte *pbVar3;
  undefined4 uVar4;
  undefined4 auStack_38 [2];
  long *plStack_30;
  char cStack_28;
  char cStack_27;
  undefined4 uStack_18;
  int iStack_14;
  
  uStack_18 = param_2;
  FUN_0013fa40(&plStack_30,&uStack_18,0);
  plVar1 = plStack_30;
  if (plStack_30 != (long *)0x0) {
    if ((*pbRam00000000033d2630 & 1) == 0) {
      pbVar3 = pbRam00000000033d2630;
      __cxa_guard_acquire();
      if ((int)pbVar3 != 0) {
        *plRam00000000033d2638 = lRam00000000033d2640 + 0x10;
        __cxa_guard_release(pbRam00000000033d2630);
      }
    }
    (**(code **)(*plVar1 + 0x20))(plVar1,plRam00000000033d2638);
    if (((ulong)plVar1 & 1) == 0) {
      cStack_27 = '\0';
    }
    if (((plStack_30 != (long *)0x0) && (cStack_28 != '\0')) && (cStack_27 != '\0')) {
      if (*(char *)(param_1 + 10) == '\0') {
        lVar2 = plStack_30[0x5e];
        if (*(char *)(plStack_30[0x5f] + 0x7cc6) == '\0') {
          auStack_38[0] = *(undefined4 *)(param_1 + 0xc);
          uVar4 = NEON_ucvtf(*puRam00000000033d8b20);
          FUN_00cf8020(uVar4,lVar2,auStack_38);
        }
        else {
          iStack_14 = *(int *)(lVar2 + 0x358);
          if ((iStack_14 != 0xc) ||
             (*(int *)(*(long *)(lVar2 + 0x368) + 8) != *(int *)(param_1 + 0xc))) {
            *(undefined1 *)(param_1 + 9) = 1;
          }
        }
      }
      else {
        *(undefined1 *)(plStack_30[0x5f] + 0x7cc9) = 1;
      }
    }
  }
  FUN_0013fcc0(&plStack_30);
  return;
}

