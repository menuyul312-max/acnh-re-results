
void _INIT_2648(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655000 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655048);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655004 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655008 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000365501c = 0xffff;
  uRam0000000003655018 = 0xffffffff;
  uRam0000000003655024 = 0;
  uRam0000000003655020 = 0;
  uRam000000000365500c = (undefined4)uVar2;
  uRam0000000003655010 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655030 = 0;
  uRam0000000003655028 = uVar2;
  FUN_010588a0(0x3655038,0x1c2b);
  FUN_010588a0(0x3655040,0x142e);
  return;
}

