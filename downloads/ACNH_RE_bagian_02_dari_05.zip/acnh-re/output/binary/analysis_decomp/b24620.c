
bool FUN_00c24620(long param_1)

{
  if (*(int *)(param_1 + 0x48) == 7) {
    return true;
  }
  return *(int *)(param_1 + 0x48) == 8;
}

