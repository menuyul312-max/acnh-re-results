
void FUN_00c26580(long param_1)

{
  int iVar1;
  ulong uVar2;
  int iStack_24;
  
  FUN_00c2c5b0(*(undefined8 *)(param_1 + 0x20));
  FUN_00c2c6c0(*(undefined8 *)(param_1 + 0x20));
  FUN_00c2c7e0(*(undefined8 *)(param_1 + 0x20));
  FUN_00c2c890(*(undefined8 *)(param_1 + 0x20));
  iVar1 = (int)param_1 + 0x8c;
  iStack_24 = iVar1;
  FUN_00be6460();
  FUN_00c0e090(param_1 + 0x2540,&iStack_24,&UNK_02af8e20);
  FUN_00be6480();
  if (iVar1 != 0) {
    uVar2 = *(ulong *)(param_1 + 0x20);
    *(undefined1 *)(param_1 + 0xac) = 1;
    FUN_00c2cff0();
    FUN_00bea8d0();
    if ((uVar2 & 1) == 0) {
      *(undefined1 *)(param_1 + 0xac) = 0;
    }
  }
  return;
}

