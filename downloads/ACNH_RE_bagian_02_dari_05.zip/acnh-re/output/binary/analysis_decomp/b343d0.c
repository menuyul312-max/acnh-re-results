
undefined4 FUN_00c343d0(long param_1)

{
  return *(undefined4 *)(param_1 + 0x108);
}

