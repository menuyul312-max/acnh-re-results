
void FUN_00c2cc90(long param_1,int param_2)

{
  ulong uVar1;
  
  if (((param_2 < 6) && (*(int *)(param_1 + 0x28) == 2)) && (*(int *)(param_1 + 0x2c) == 0)) {
    uVar1 = *(ulong *)(*(long *)(param_1 + 0x20) + 0x218);
    FUN_0138b720(uVar1,param_2);
    if ((uVar1 & 1) != 0) {
      *(int *)(param_1 + 0x34) = param_2;
    }
  }
  return;
}

