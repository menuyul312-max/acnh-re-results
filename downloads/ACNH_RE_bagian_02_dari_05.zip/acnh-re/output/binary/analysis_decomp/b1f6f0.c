
void FUN_00c1f6f0(long param_1)

{
  long lVar1;
  char *pcVar2;
  int iVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  long alStack_1340 [65];
  long lStack_1138;
  long alStack_1130 [28];
  undefined1 auStack_1050 [4096];
  undefined4 uStack_44;
  
  FUN_00be60b0(alStack_1130);
  uVar4 = *(undefined8 *)(param_1 + 0x30e0);
  uVar5 = *(undefined8 *)(param_1 + 0x30d8);
  FUN_00c0dc50(uVar4);
  FUN_00be60e0(alStack_1130,uVar5,uVar4);
  iVar3 = (int)alStack_1130;
  FUN_00be6480();
  alStack_1340[0] = CONCAT44(alStack_1340[0]._4_4_,iVar3);
  pcVar2 = (char *)(param_1 + 0x30f0);
  uStack_44 = SUB84(alStack_1130,0);
  *pcVar2 = iVar3 != 0;
  FUN_00be6460();
  FUN_00be60d0(alStack_1130);
  if (*pcVar2 == '\0') {
    FUN_0011e3d0(alStack_1340);
    lStack_1138 = 0;
    alStack_1340[0] = lRam00000000033f4de0 + 0x10;
    uVar4 = *(undefined8 *)(param_1 + 0x30e0);
    uVar5 = *(undefined8 *)(param_1 + 0x30d8);
    FUN_00c0dc50(uVar4);
    lVar1 = lRam00000000033f4d40 + 0x10;
    alStack_1130[0] = lVar1;
    FUN_00123650(alStack_1130,auStack_1050,0x800);
    alStack_1130[0] = lVar1;
    memset(auStack_1050,0,0x1000);
    memset(auStack_1050,0,0x1000);
    FUN_00123860(alStack_1130,uVar5,uVar4,0);
    lStack_1138 = 0;
    FUN_0011e470(alStack_1340);
    FUN_0011e520(alStack_1340,alStack_1130);
    FUN_0011e660(alStack_1340);
    lVar1 = lStack_1138;
    FUN_001237f0(alStack_1130);
    FUN_001219a0(alStack_1340);
    if (lVar1 != 0) {
      uStack_44 = 0xffffffff;
      FUN_001220b0(alStack_1130);
      FUN_00122180(alStack_1130,lVar1,0);
      FUN_00c203a0(param_1 + 8,alStack_1130,*(undefined8 *)(param_1 + 0x30d8),
                   *(undefined8 *)(param_1 + 0x30e0));
      FUN_001220d0(alStack_1130);
    }
    if (*pcVar2 == '\0') {
      FUN_00c0da50(alStack_1130);
      FUN_00c0e090(alStack_1130,&uStack_44,&UNK_02af8d54);
      FUN_00c1f580(param_1,alStack_1130);
      FUN_00c0dad0(alStack_1130);
    }
  }
  return;
}

