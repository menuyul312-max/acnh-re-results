
void FUN_00c32a50(undefined8 param_1,undefined *param_2,undefined8 *param_3)

{
  long lVar1;
  long lVar2;
  int iVar3;
  undefined1 uVar4;
  undefined *puVar5;
  ulong uVar6;
  undefined8 *puVar7;
  ulong uVar8;
  long lStack_80;
  undefined *puStack_78;
  int iStack_70;
  undefined auStack_6c [12];
  long lStack_60;
  undefined *puStack_58;
  
  lVar2 = lRam00000000033d0668;
  uVar8 = 0;
  uVar6 = 0;
  lVar1 = lRam00000000033d0668 + 0x10;
  lStack_80 = lVar1;
  puStack_78 = param_2;
  FUN_00e34200();
  if ((uVar8 & 1) == 0) {
    lStack_80 = lVar1;
    puStack_78 = param_2;
    FUN_00e34280();
    if ((uVar6 & 1) == 0) {
      uVar8 = 0;
    }
    else {
      puStack_78 = auStack_6c;
      lStack_80 = lRam00000000033d0670 + 0x10;
      iStack_70 = 8;
      FUN_01a90780(&lStack_80);
      uVar4 = *puRam00000000033d0660;
      *puStack_78 = uVar4;
      puVar5 = puStack_78;
      lStack_80 = lRam00000000033d25e8 + 0x10;
      if (puStack_78 != param_2) {
        iVar3 = 3;
        if (iStack_70 < 4) {
          iVar3 = iStack_70 + -1;
        }
        memcpy(puStack_78,param_2,(long)iVar3);
        puVar5[iVar3] = uVar4;
      }
      lVar2 = lVar2 + 0x10;
      puStack_58 = &UNK_02a473cd;
      uVar8 = 1;
      puVar7 = param_3;
      lStack_60 = lVar2;
      (**(code **)*param_3)(param_3,param_1,&lStack_60,&lStack_80,1);
      if (((ulong)puVar7 & 1) == 0) {
        puStack_78 = &UNK_02a473cd;
        lStack_80 = lVar2;
        lStack_60 = lVar2;
        puStack_58 = param_2;
        (**(code **)*param_3)(param_3,param_1,&lStack_80,&lStack_60,1);
        uVar8 = (ulong)param_3 & 0xffffffff;
      }
      FUN_00e34840(param_2);
    }
  }
  else {
    puStack_78 = &UNK_02a51b36;
    lStack_80 = lVar1;
    lStack_60 = lVar1;
    puStack_58 = param_2;
    (**(code **)*param_3)(param_3,param_1,&lStack_80,&lStack_60,1);
    uVar8 = (ulong)param_3 & 0xffffffff;
    FUN_00e34780(param_2);
  }
  FUN_001234f0(param_1);
  FUN_00121d40();
  if ((uVar8 & 1) == 0) {
    FUN_001232c0(param_1);
  }
  return;
}

