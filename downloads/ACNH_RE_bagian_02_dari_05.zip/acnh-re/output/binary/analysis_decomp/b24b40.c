
long FUN_00c24b40(long param_1)

{
  return param_1 + 0x8c;
}

