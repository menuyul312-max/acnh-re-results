
void FUN_00c26cc0(undefined8 param_1,undefined8 param_2)

{
  FUN_0011e470();
  FUN_0011e520(param_1,param_2);
  FUN_0011e660(param_1);
  return;
}

