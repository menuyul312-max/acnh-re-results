
void FUN_00c33390(long *param_1,byte *param_2)

{
  byte bVar1;
  undefined1 *puVar2;
  byte *pbVar3;
  long *plVar4;
  long *plVar5;
  undefined1 *puVar6;
  undefined8 uVar7;
  ulong uVar8;
  long lVar9;
  long lStack_90;
  undefined1 *puStack_88;
  undefined4 uStack_80;
  undefined1 auStack_7c [40];
  undefined4 uStack_54;
  long lStack_50;
  undefined1 *puStack_48;
  long lStack_40;
  undefined *puStack_38;
  
  plVar5 = &lStack_90;
  lVar9 = lRam00000000033f5250 + 0x10;
  *param_1 = lVar9;
  FUN_00123650(param_1,param_1 + 0x1c,0x17);
  *param_1 = lVar9;
  *(undefined8 *)((long)param_1 + 0x106) = 0;
  param_1[0x1c] = 0;
  uVar8 = (long)param_1 + 0x10eU;
  if ((long)param_1 + 0x10eU <= (long)param_1 + 0xe2U) {
    uVar8 = (long)param_1 + 0xe2U;
  }
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  memset(param_1 + 0x1c,0,(uVar8 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  pbVar3 = param_2;
  FUN_00dd3400();
  if (((ulong)pbVar3 & 1) != 0) {
    pbVar3 = param_2;
    FUN_00e35570();
    uVar8 = (ulong)pbVar3 & 0xffffffff;
    uStack_54 = SUB84(pbVar3,0);
    plVar4 = param_1;
    FUN_00c330e0(param_1,&uStack_54);
    if (((ulong)plVar4 & 1) == 0) {
      FUN_00ff2ff0();
      if (uVar8 != 0) {
        FUN_00fe9350(&lStack_90,uVar8,1);
        lStack_90 = lRam00000000033f5258 + 0x10;
        lVar9 = *(long *)((long)puStack_88 + 0x10) + *(long *)((long)puStack_88 + 8);
        FUN_010e5640();
        lStack_40 = CONCAT44(lStack_40._4_4_,0x16);
        puStack_38 = (undefined *)lVar9;
        FUN_010e4670(param_1,&lStack_40);
        FUN_00fe93d0(&lStack_90);
      }
      plVar4 = param_1;
      FUN_001232e0();
      if (((ulong)plVar4 & 1) != 0) {
        puStack_88 = auStack_7c;
        lStack_90 = lRam00000000033d0670 + 0x10;
        uStack_80 = 0x20;
        FUN_01a90780();
        *puStack_88 = *puRam00000000033d0660;
        lStack_90 = lRam00000000033d0680 + 0x10;
        bVar1 = *param_2;
        if ((ulong)bVar1 < 0x23) {
          FUN_001f6b80();
          uVar7 = *(undefined8 *)((long)plVar5 + (ulong)bVar1 * 8);
        }
        else {
          uVar7 = 0x2ab9d8f;
        }
        FUN_01a90820(&lStack_90,&UNK_02a3ea8f,uVar7,param_2[1]);
        (**(code **)(lStack_90 + 0x18))(&lStack_90);
        puVar2 = puStack_88;
        lVar9 = *plRam00000000033d3788;
        puVar6 = puStack_88;
        FUN_00101bf0(puStack_88,0);
        lStack_40 = CONCAT44(lStack_40._4_4_,(int)puVar6);
        FUN_00189ce0(lVar9,&lStack_40);
        if (lVar9 != 0) {
          lStack_50 = lRam00000000033d0668 + 0x10;
          puStack_38 = &UNK_02a9c831;
          puStack_48 = puVar2;
          lStack_40 = lStack_50;
          FUN_00123860(param_1,&lStack_40,&lStack_50,0);
        }
      }
    }
  }
  return;
}

