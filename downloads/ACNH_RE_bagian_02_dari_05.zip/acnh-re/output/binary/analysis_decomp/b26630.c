
void FUN_00c26630(long param_1,ulong param_2)

{
  uint uVar1;
  ulong uVar2;
  undefined8 uVar3;
  long lVar4;
  undefined8 uVar5;
  
  if ((param_2 & 1) == 0) {
    if (*(char *)(param_1 + 0x2461) != '\0') {
      return;
    }
  }
  else {
    *(char *)(param_1 + 0x2461) = '\x01';
  }
  uVar2 = *(ulong *)(param_1 + 0x28);
  FUN_00c27af0();
  if ((uVar2 & 1) == 0) {
    FUN_00c277d0(*(undefined8 *)(param_1 + 0x28));
    uVar2 = param_1 + 0x8c;
    FUN_00be6bc0();
    if ((uVar2 & 1) == 0) {
      uVar3 = *(undefined8 *)(param_1 + 0x28);
      FUN_00c27b80(uVar3);
      uVar1 = (uint)uVar3;
    }
    else {
      uVar1 = 1;
    }
    FUN_00c2c8f0(*(undefined8 *)(param_1 + 0x20),uVar1 & 1);
  }
  else {
    FUN_00c27ac0();
  }
  uVar3 = *(undefined8 *)(param_1 + 0x28);
  FUN_00c27900(uVar3);
  lVar4 = *(long *)(param_1 + 0x20);
  FUN_00c2c3e0();
  FUN_00bf2fb0(*(undefined8 *)(param_1 + 0x18));
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(undefined8 *)(lVar4 + 0x48);
  }
  FUN_00bf2fd0(*(undefined8 *)(param_1 + 0x18),uVar5,uVar3);
  return;
}

