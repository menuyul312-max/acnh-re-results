
bool FUN_00c2ce40(long param_1)

{
  return *(int *)(*(long *)(param_1 + 0x18) + 8) == 2;
}

