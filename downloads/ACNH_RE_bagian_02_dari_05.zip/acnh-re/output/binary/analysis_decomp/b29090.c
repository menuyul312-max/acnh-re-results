
uint FUN_00c29090(long param_1)

{
  long *plVar1;
  long *plVar2;
  
  plVar2 = (long *)(param_1 + 0xa8);
  plVar1 = plVar2;
  (**(code **)(*plVar2 + 0x10))();
  if (((ulong)plVar1 & 1) != 0) {
    (**(code **)*plVar2)(plVar2);
    *plVar2 = lRam00000000033d1478 + 0x10;
  }
  return (uint)plVar1 & 1;
}

