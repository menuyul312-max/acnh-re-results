
void FUN_00c2c2a0(long param_1)

{
  ulong uVar1;
  long *plVar2;
  
  plVar2 = *(long **)(param_1 + 0x18);
  if ((int)plVar2[1] == 2) {
    if (*(int *)(*plVar2 + 0x244) == 1) {
      *(undefined1 *)(*(long *)(*plVar2 + 0x220) + 0x305) = 1;
      *(undefined4 *)(plVar2 + 1) = 3;
    }
  }
  plVar2 = *(long **)(param_1 + 0x20);
  (**(code **)(*plVar2 + 0xf8))();
  if (((ulong)plVar2 & 1) != 0) {
    uVar1 = *(ulong *)(param_1 + 0x20);
    FUN_01385d00();
    if (((uVar1 & 1) == 0) && (*(int *)(*(long *)(param_1 + 0x18) + 8) == 0)) {
      *(undefined8 *)(param_1 + 0x28) = 0xffffffff00000003;
      *(undefined8 *)(param_1 + 0x30) = 0xffffffffffffffff;
      FUN_0177e240(*(undefined8 *)(param_1 + 0x20));
      return;
    }
  }
  return;
}

