
void FUN_00c26dc0(undefined8 param_1,long *param_2,long param_3,long param_4)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  long *plVar4;
  long lVar5;
  undefined8 uVar6;
  
  FUN_0011e3d0();
  lVar5 = lRam00000000033f4fd8;
  param_2[0x41] = param_3;
  param_2[0x42] = param_4;
  plVar1 = param_2 + 0x5f;
  lVar2 = lRam00000000033f4fe0 + 0x10;
  *param_2 = lVar5 + 0x10;
  param_2[0x43] = lVar2;
  FUN_00123650(param_2 + 0x43,plVar1,0x200);
  param_2[0x43] = lVar2;
  memset(plVar1,0,0x400);
  plVar4 = param_2 + 0xdf;
  plVar3 = plVar4;
  if (plVar4 <= (long *)((long)param_2 + 0x2fa)) {
    plVar3 = (long *)((long)param_2 + 0x2fa);
  }
  memset(plVar1,0,(long)plVar3 + (-0x2f7 - (long)param_2) & 0xfffffffffffffffe);
  plVar1 = param_2 + 0xfb;
  param_2[0xdf] = lVar2;
  FUN_00123650(plVar4,plVar1,0x200);
  param_2[0xdf] = lVar2;
  memset(plVar1,0,0x400);
  plVar4 = param_2 + 0x17b;
  if (param_2 + 0x17b <= (long *)((long)param_2 + 0x7da)) {
    plVar4 = (long *)((long)param_2 + 0x7da);
  }
  memset(plVar1,0,(long)plVar4 + (-0x7d7 - (long)param_2) & 0xfffffffffffffffe);
  *(undefined4 *)(param_2 + 0x17b) = 0;
  FUN_00bee1c0(param_2 + 0x17c,3);
  FUN_00be4140(param_2 + 0x206);
  *(undefined1 *)(param_2 + 0x290) = 0;
  FUN_00be53b0(param_2 + 0x291);
  FUN_00be53b0(param_2 + 0x35f);
  lVar2 = lRam00000000033f4fe8;
  param_2[0x42d] = param_3;
  param_2[0x35f] = lVar2 + 0x10;
  FUN_00c2de60(param_2 + 0x42e);
  *(undefined8 *)((long)param_2 + 0x2184) = 0;
  *(undefined8 *)((long)param_2 + 0x218c) = 0xffffffff;
  *(undefined1 *)((long)param_2 + 0x2194) = 0;
  FUN_00c1fb10(param_2 + 0x433,param_3);
  memset(param_2 + 0xa4d,0,0x824);
  FUN_00c26fd0(param_2);
  FUN_00c2a890();
  uVar6 = param_1;
  FUN_00c2a8e0();
  FUN_00c2de90(param_1,uVar6,param_2 + 0x42e);
  param_2[0x435] = (long)param_2;
  param_2[0x436] = lRam00000000033f4ff0;
  lVar2 = lRam00000000033f4ff8;
  param_2[0x437] = 0;
  param_2[0x434] = lVar2 + 0x10;
  return;
}

