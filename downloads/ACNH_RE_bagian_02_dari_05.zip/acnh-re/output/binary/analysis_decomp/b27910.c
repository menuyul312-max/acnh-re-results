
void FUN_00c27910(long param_1)

{
  FUN_00c2dec0(param_1 + 0x2170);
  *(undefined4 *)(param_1 + 0x2184) = 0;
  *(undefined4 *)(param_1 + 0x218c) = 0xffffffff;
  FUN_001232c0(param_1 + 0x218);
  FUN_001232c0(param_1 + 0x6f8);
  *(undefined4 *)(param_1 + 0xbd8) = 0;
  FUN_00c2c360(*(undefined8 *)(param_1 + 0x210));
  return;
}

