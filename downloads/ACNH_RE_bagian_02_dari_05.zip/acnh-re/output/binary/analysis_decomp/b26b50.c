
void _INIT_2634(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003653dd8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3653e20);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003653ddc = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003653de0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003653e04 = 0xffff;
  uRam0000000003653e00 = 0xffffffff;
  uRam0000000003653e0c = 0;
  uRam0000000003653e08 = 0;
  uRam0000000003653de4 = (undefined4)uVar2;
  uRam0000000003653de8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003653dec = 0x200000003;
  uRam0000000003653e10 = uVar2;
  uRam0000000003653e18 = 0;
  iRam0000000003653df4 = -*piRam00000000033d0630;
  iRam0000000003653df8 = *piRam00000000033d0630;
  lRam0000000003653e30 = lRam00000000033d0668 + 0x10;
  puRam0000000003653e38 = &UNK_02a4fd5c;
  return;
}

