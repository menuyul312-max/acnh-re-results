
void _INIT_2643(void)

{
  long *plVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uRam0000000003654e98 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654ed0);
  uVar2 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654e9c = uVar2;
  uVar2 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654ea0 = uVar2;
  uVar3 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654eb4 = 0xffff;
  uRam0000000003654eb0 = 0xffffffff;
  uRam0000000003654ebc = 0;
  uRam0000000003654eb8 = 0;
  uRam0000000003654ea4 = (undefined4)uVar3;
  uRam0000000003654ea8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  plVar1 = plRam00000000033f5210;
  uRam0000000003654ec8 = 0;
  uRam0000000003654ec0 = uVar3;
  *plRam00000000033f5210 = lRam00000000033d0668 + 0x10;
  plVar1[1] = (long)&UNK_02aa6e91;
  return;
}

