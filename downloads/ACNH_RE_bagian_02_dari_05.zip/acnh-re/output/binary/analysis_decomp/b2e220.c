
void FUN_00c2e220(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c2e228. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x18))();
  return;
}

