
void FUN_00c3d7f0(long param_1,undefined8 param_2)

{
  FUN_01766240(param_1 + 8);
  FUN_01766240(param_1 + 0x208,param_2);
  FUN_01766240(param_1 + 0x408,param_2);
  FUN_01766240(param_1 + 0x608,param_2);
  return;
}

