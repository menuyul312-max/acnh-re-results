
void FUN_00c31530(undefined8 param_1,undefined8 param_2,ulong param_3)

{
  ulong uVar1;
  undefined1 *puVar2;
  undefined4 *puVar3;
  undefined8 uVar4;
  undefined1 auStack_48 [8];
  undefined4 auStack_40 [6];
  undefined1 auStack_28 [8];
  
  uVar1 = param_3;
  FUN_01058d00();
  if ((uVar1 & 1) != 0) {
    FUN_010589b0(auStack_28,param_3);
    FUN_00b9c290(auStack_40,auStack_28);
    uVar1 = 0;
    FUN_00b9c3a0();
    if ((uVar1 & 1) != 0) {
      uVar1 = 0;
      FUN_00bb4060();
      if ((uVar1 & 1) != 0) {
        FUN_00bb7990(auStack_48,auStack_40);
        FUN_010589e0(auStack_28,auStack_48);
      }
    }
    uVar1 = 0;
    FUN_01058d00();
    if ((uVar1 & 1) != 0) {
      puVar2 = auStack_28;
      auStack_40[0] = 0x16a2;
      FUN_01058a10(puVar2,auStack_40);
      if (((ulong)puVar2 & 1) != 0) {
        FUN_00b9c290(auStack_40,auStack_28);
        uVar4 = *puRam00000000033d3ce0;
        puVar3 = auStack_40;
        FUN_00bb78e0(puVar3);
        FUN_00fdbb50(auStack_48,uVar4,(ulong)puVar3 & 0xffffffff);
        FUN_010589e0(auStack_28,auStack_48);
      }
      FUN_01058d00(auStack_28);
    }
    FUN_010589b0(param_1,auStack_28);
    return;
  }
  FUN_010589b0(param_1,param_3);
  return;
}

