
void FUN_00c2aea0(undefined8 *param_1,undefined8 param_2)

{
  *param_1 = param_2;
  *(undefined4 *)(param_1 + 1) = 0;
  param_1[2] = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined4 *)((long)param_1 + 0x1c) = 0;
  FUN_0174fcd0(param_1 + 4);
  FUN_00c2f780(param_1 + 0xb);
  FUN_00bf0f60(param_1 + 0x2b);
  return;
}

