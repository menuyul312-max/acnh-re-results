
void FUN_00c2a9f0(long *param_1)

{
  long lVar1;
  long lVar2;
  long *plVar3;
  
  FUN_00c2e1d0();
  lVar1 = lRam00000000033f5198 + 0x10;
  lVar2 = lRam00000000033d0670 + 0x10;
  param_1[2] = (long)param_1 + 0x1c;
  *param_1 = lVar1;
  plVar3 = param_1 + 1;
  *plVar3 = lVar2;
  *(undefined4 *)(param_1 + 3) = 0x40;
  FUN_01a90780(plVar3);
  lVar1 = lRam00000000033d1298 + 0x10;
  *(undefined1 *)param_1[2] = *puRam00000000033d0660;
  *plVar3 = lVar1;
  FUN_00c0da50(param_1 + 0xc);
  return;
}

