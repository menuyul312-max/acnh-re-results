
long FUN_00c3c420(long *param_1,long param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  long *plVar2;
  long *plVar3;
  long lVar4;
  
  lVar4 = param_2;
  FUN_01766670();
  if (lVar4 != 0) {
    if (*(long *)(param_2 + 0xb0) != 0) {
      plVar2 = param_1;
      FUN_017661b0(param_1,param_3);
      *puRam00000000033f5318 = 1;
      puVar1 = puRam00000000033f5320;
      *(undefined4 *)(puRam00000000033f5320 + 2) = 0xffffffff;
      *puVar1 = 0xffffffffffffffff;
      puVar1[1] = 0xffffffffffffffff;
      param_1[0x16] = *(long *)(param_2 + 0xb0);
      plVar3 = plVar2;
      if (plVar2 == (long *)0x0) {
        plVar3 = (long *)*plRam00000000033d08a8;
        FUN_01a89270();
      }
      param_1[0x15] = (long)plVar3;
      param_1[0x17] = param_2;
      if (**(char **)(param_2 + 0x10) != *pcRam00000000033d0660) {
        (**(code **)(*param_1 + 0x40))(param_1,param_2 + 8,plVar2);
        FUN_017669f0(*puRam00000000033d4890,param_1);
        return 1;
      }
      (**(code **)(*param_1 + 0x38))(param_1);
    }
    lVar4 = 0;
  }
  return lVar4;
}

