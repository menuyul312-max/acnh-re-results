
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c3d8f0(ulong param_1,int *param_2,int param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  uint uVar2;
  ushort uVar3;
  int iVar4;
  float fVar5;
  char *pcVar6;
  uint *puVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  undefined1 *puVar11;
  uint *puVar12;
  uint *puVar13;
  ulong uVar14;
  uint *puVar15;
  undefined2 uVar16;
  uint uVar17;
  long lVar18;
  char *pcVar19;
  uint *puVar20;
  uint *puVar21;
  undefined8 *puVar22;
  uint *puVar23;
  uint uVar24;
  undefined8 *puVar25;
  int *piVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar31;
  float fVar32;
  undefined8 uStack_1b0;
  undefined1 auStack_190 [8];
  float fStack_188;
  float fStack_184;
  float fStack_180;
  undefined4 uStack_17c;
  undefined1 auStack_178 [8];
  undefined1 auStack_170 [56];
  undefined1 auStack_138 [32];
  undefined1 auStack_118 [56];
  undefined1 auStack_e0 [32];
  uint uStack_c0;
  undefined1 uStack_bc;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  long lStack_a0;
  long lStack_98;
  float fVar30;
  
  if (param_2 != (int *)0x0) {
    if (0 < *param_2) {
      lVar18 = 0;
      puVar25 = *(undefined8 **)(param_2 + 4);
      do {
        puVar22 = *(undefined8 **)(*(long *)(param_2 + 2) + lVar18 * 8);
        *puVar22 = puVar25;
        lVar18 = lVar18 + 1;
        *(undefined8 **)(param_2 + 4) = puVar22;
        puVar25 = puVar22;
      } while (lVar18 < *param_2);
    }
    uStack_1b0 = 0;
    *param_2 = 0;
    if (param_3 < 0x17f77b87) {
      if (param_3 < -0xe632453) {
        if (param_3 == -0x477aafe0) {
          uStack_1b0 = 5;
        }
        else if (param_3 == -0x2099c902) {
          uStack_1b0 = 9;
        }
        else if (param_3 == -0x15fdefdb) {
          uStack_1b0 = 7;
        }
      }
      else if (param_3 == -0xe632453) {
        uStack_1b0 = 3;
      }
      else if (param_3 == -0x83ceb3d) {
        uStack_1b0 = 4;
      }
      else if (param_3 == -0x169521c) {
        uStack_1b0 = 1;
      }
    }
    else if (param_3 < 0x337f0c42) {
      if (param_3 == 0x17f77b87) {
        uStack_1b0 = 8;
      }
      else if (param_3 == 0x23f13b17) {
        uStack_1b0 = 10;
      }
      else if (param_3 == 0x3072bd3f) {
        uStack_1b0 = 0xb;
      }
    }
    else if (param_3 == 0x337f0c42) {
      uStack_1b0 = 0xc;
    }
    else if (param_3 == 0x3b3bf38a) {
      uStack_1b0 = 6;
    }
    else if (param_3 == 0x3fce6459) {
      uStack_1b0 = 2;
    }
    uVar14 = param_1;
    FUN_00fecf00();
    if (uVar14 != 0) {
      FUN_00fe9350(&lStack_a0,uVar14 + 0x20a168,1);
      puVar25 = puRam00000000033f5498;
      piVar1 = (int *)(param_1 + 8);
      uVar24 = 0;
      lStack_a0 = lRam00000000033d8a08 + 0x10;
      piVar8 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
      if (0 < (int)*(uint *)(param_1 + 0x1c8)) goto LAB_00c3db88;
LAB_00c3db5c:
      piVar8 = piVar1;
      FUN_01766670();
      if (piVar8 == (int *)0x0) goto LAB_00c3db88;
      FUN_01765e30();
      if (uVar24 < (uint)piVar8) {
LAB_00c3db90:
        piVar8 = piVar1;
        FUN_00c3eb20(piVar1,uVar24);
        if (piVar8 != (int *)0x0) {
          FUN_00c3ec70(&fStack_188);
          if (*piVar8 != 0) {
            do {
              piVar26 = piVar8;
              if (*pcRam00000000033f5488 == '\0') {
                *pcRam00000000033f5488 = '\x01';
                *puVar25 = 0xffffffffffffffff;
                puVar25[1] = 0xffffffffffffffff;
                puVar25[2] = 0xffffffffffffffff;
                *(undefined4 *)(puVar25 + 3) = 0xffffffff;
                FUN_01765e80();
              }
              else {
                iVar4 = *(int *)(puVar25 + 1);
                if (-1 < iVar4) {
                  if ((undefined2 *)((long)iVar4 + (long)piVar8) != (undefined2 *)0x0) {
                    uVar16 = *(undefined2 *)((long)iVar4 + (long)piVar8);
                    goto LAB_00c3dc88;
                  }
                  break;
                }
                if (iVar4 != -1) break;
                FUN_01765e80();
              }
              if ((piVar26 == (int *)0x0) ||
                 (piVar9 = piVar26, FUN_01765e60(), piVar9 == (int *)0x0)) break;
              FUN_01765e50();
              *(undefined4 *)(puVar25 + 1) = 0xfffffffe;
              if ((uint)piVar26 == 0) break;
              uVar17 = 0;
              piVar10 = piVar9 + 1;
              while (piVar9[(ulong)uVar17 * 2] != -0x489482c9) {
                uVar17 = uVar17 + 1;
                piVar10 = piVar10 + 2;
                if ((uint)piVar26 <= uVar17) goto LAB_00c3dc84;
              }
              iVar4 = 0;
              if (*piVar10 != -1) {
                iVar4 = *piVar10;
              }
              *(int *)(puVar25 + 1) = iVar4;
              if (*piVar8 == 0) break;
            } while( true );
          }
LAB_00c3dc84:
          uVar16 = 0xfffe;
LAB_00c3dc88:
          FUN_010588a0(auStack_190,uVar16);
          FUN_010589e0(auStack_178,auStack_190);
          if (*piVar8 != 0) {
            do {
              piVar26 = piVar8;
              if (*pcRam00000000033f5488 == '\0') {
                *pcRam00000000033f5488 = '\x01';
                *puVar25 = 0xffffffffffffffff;
                puVar25[1] = 0xffffffffffffffff;
                puVar25[2] = 0xffffffffffffffff;
                *(undefined4 *)(puVar25 + 3) = 0xffffffff;
                FUN_01765e80();
              }
              else {
                iVar4 = *(int *)((long)puVar25 + 4);
                if (-1 < iVar4) {
                  if ((ushort *)((long)iVar4 + (long)piVar8) != (ushort *)0x0) {
                    uVar17 = (uint)*(ushort *)((long)iVar4 + (long)piVar8);
                    goto LAB_00c3dd78;
                  }
                  break;
                }
                if (iVar4 != -1) break;
                FUN_01765e80();
              }
              if ((piVar26 == (int *)0x0) ||
                 (piVar9 = piVar26, FUN_01765e60(), piVar9 == (int *)0x0)) break;
              FUN_01765e50();
              *(undefined4 *)((long)puVar25 + 4) = 0xfffffffe;
              if ((uint)piVar26 == 0) break;
              uVar17 = 0;
              piVar10 = piVar9 + 1;
              while (piVar9[(ulong)uVar17 * 2] != 0x4765b463) {
                uVar17 = uVar17 + 1;
                piVar10 = piVar10 + 2;
                if ((uint)piVar26 <= uVar17) goto LAB_00c3dd74;
              }
              iVar4 = 0;
              if (*piVar10 != -1) {
                iVar4 = *piVar10;
              }
              *(int *)((long)puVar25 + 4) = iVar4;
              if (*piVar8 == 0) break;
            } while( true );
          }
LAB_00c3dd74:
          uVar17 = 0x4c7b;
LAB_00c3dd78:
          uVar17 = uVar17 - *(ushort *)(param_1 + 0x400);
          if ((*(uint *)(param_1 + 0x3e0) <= uVar17) ||
             (piVar26 = *(int **)(*(long *)(param_1 + 1000) + (long)(int)uVar17 * 8),
             piVar26 == (int *)0x0)) goto LAB_00c3db78;
          while (*piVar26 != 0) {
            piVar9 = piVar26;
            if (*pcRam00000000033f54c0 == '\0') {
              *pcRam00000000033f54c0 = '\x01';
              puVar20 = puRam00000000033f54c8;
              puVar20[0] = 0xffffffff;
              puVar20[1] = 0xffffffff;
              puVar20[10] = 0xffffffff;
              puVar20[0xb] = 0xffffffff;
              puVar20[0xc] = 0xffffffff;
              puVar20[0xd] = 0xffffffff;
              puVar20[6] = 0xffffffff;
              puVar20[7] = 0xffffffff;
              puVar20[8] = 0xffffffff;
              puVar20[9] = 0xffffffff;
              puVar20[2] = 0xffffffff;
              puVar20[3] = 0xffffffff;
              puVar20[4] = 0xffffffff;
              puVar20[5] = 0xffffffff;
              FUN_01765e80();
            }
            else {
              uVar17 = puRam00000000033f54c8[0xd];
              if (-1 < (int)uVar17) {
                if (((char *)((long)(int)uVar17 + (long)piVar26) != (char *)0x0) &&
                   (*(char *)((long)(int)uVar17 + (long)piVar26) != '\0')) {
                  uVar14 = param_1;
                  FUN_00c3f030(param_1,&fStack_188,piVar26,param_4);
                  if ((uVar14 & 1) == 0) goto LAB_00c3db78;
                  iVar4 = *piVar8;
                  goto joined_r0x00c3deb8;
                }
                break;
              }
              if (uVar17 != 0xffffffff) break;
              FUN_01765e80();
            }
            if ((piVar9 == (int *)0x0) || (piVar10 = piVar9, FUN_01765e60(), piVar10 == (int *)0x0))
            break;
            FUN_01765e50();
            puRam00000000033f54c8[0xd] = 0xfffffffe;
            if ((uint)piVar9 == 0) break;
            uVar17 = 0;
            puVar20 = (uint *)(piVar10 + 1);
            while (piVar10[(ulong)uVar17 * 2] != -0xa7ef60b) {
              uVar17 = uVar17 + 1;
              puVar20 = puVar20 + 2;
              if ((uint)piVar9 <= uVar17) goto LAB_00c3df70;
            }
            uVar17 = 0;
            if (*puVar20 != 0xffffffff) {
              uVar17 = *puVar20;
            }
            puRam00000000033f54c8[0xd] = uVar17;
          }
LAB_00c3df70:
          if ((param_5 & 1) != 0) {
            uVar14 = *(long *)(lStack_98 + 0x10) + *(long *)(lStack_98 + 8);
            FUN_01077f60(uVar14,auStack_178);
            if ((uVar14 & 1) == 0) goto LAB_00c3db78;
          }
          if (*piVar8 != 0) {
            do {
              piVar26 = piVar8;
              if (*pcRam00000000033f5488 == '\0') {
                *pcRam00000000033f5488 = '\x01';
                *puVar25 = 0xffffffffffffffff;
                puVar25[1] = 0xffffffffffffffff;
                puVar25[2] = 0xffffffffffffffff;
                *(undefined4 *)(puVar25 + 3) = 0xffffffff;
                FUN_01765e80();
              }
              else {
                iVar4 = *(int *)((long)puVar25 + 4);
                if (-1 < iVar4) {
                  if ((undefined2 *)((long)iVar4 + (long)piVar8) != (undefined2 *)0x0) {
                    uVar16 = *(undefined2 *)((long)iVar4 + (long)piVar8);
                    goto LAB_00c3e070;
                  }
                  break;
                }
                if (iVar4 != -1) break;
                FUN_01765e80();
              }
              if ((piVar26 == (int *)0x0) ||
                 (piVar9 = piVar26, FUN_01765e60(), piVar9 == (int *)0x0)) break;
              FUN_01765e50();
              *(undefined4 *)((long)puVar25 + 4) = 0xfffffffe;
              if ((uint)piVar26 == 0) break;
              uVar17 = 0;
              piVar10 = piVar9 + 1;
              while (piVar9[(ulong)uVar17 * 2] != 0x4765b463) {
                uVar17 = uVar17 + 1;
                piVar10 = piVar10 + 2;
                if ((uint)piVar26 <= uVar17) goto LAB_00c3e06c;
              }
              iVar4 = 0;
              if (*piVar10 != -1) {
                iVar4 = *piVar10;
              }
              *(int *)((long)puVar25 + 4) = iVar4;
              if (*piVar8 == 0) break;
            } while( true );
          }
LAB_00c3e06c:
          uVar16 = 0x4c7b;
LAB_00c3e070:
          uVar14 = param_1;
          FUN_00c3f5e0(param_1,&fStack_188,uStack_1b0,uVar16);
          if ((uVar14 & 1) == 0) goto LAB_00c3db78;
          uVar14 = *puRam00000000033d3ed0;
          puVar11 = auStack_178;
          FUN_01058a90(auStack_178);
          FUN_00abbe50(uVar14,(ulong)puVar11 & 0xffffffff);
          goto joined_r0x00c3e178;
        }
        goto LAB_00c3db78;
      }
LAB_00c3e180:
      puVar7 = puRam00000000033f5550;
      pcVar6 = pcRam00000000033f54c0;
      fVar5 = _UNK_02ad6388;
      fVar30 = 0.0;
      fVar29 = 0.0;
      uVar24 = 0;
      puVar20 = (uint *)(param_1 + 0x208);
      puVar12 = (uint *)(ulong)*(uint *)(param_1 + 0x3c8);
      puVar23 = puRam00000000033f54c8;
      if (0 < (int)*(uint *)(param_1 + 0x3c8)) goto LAB_00c3eac4;
LAB_00c3e1c0:
      puVar12 = puVar20;
      FUN_01766670();
      if (puVar12 == (uint *)0x0) goto LAB_00c3eac4;
      FUN_01765e30();
      if (uVar24 < (uint)puVar12) {
LAB_00c3eacc:
        puVar12 = puVar20;
        FUN_00c405d0(puVar20,uVar24);
        if ((puVar12 != (uint *)0x0) && (*puVar12 != 0)) {
          do {
            puVar13 = puVar12;
            if (*pcVar6 == '\0') {
              *pcVar6 = '\x01';
              puVar23[10] = 0xffffffff;
              puVar23[0xb] = 0xffffffff;
              puVar23[0xc] = 0xffffffff;
              puVar23[0xd] = 0xffffffff;
              puVar23[0] = 0xffffffff;
              puVar23[1] = 0xffffffff;
              puVar23[6] = 0xffffffff;
              puVar23[7] = 0xffffffff;
              puVar23[8] = 0xffffffff;
              puVar23[9] = 0xffffffff;
              puVar23[2] = 0xffffffff;
              puVar23[3] = 0xffffffff;
              puVar23[4] = 0xffffffff;
              puVar23[5] = 0xffffffff;
              FUN_01765e80();
            }
            else {
              uVar17 = puVar23[0xc];
              if (-1 < (int)uVar17) {
                if (((char *)((long)(int)uVar17 + (long)puVar12) != (char *)0x0) &&
                   (*(char *)((long)(int)uVar17 + (long)puVar12) != '\0')) {
                  uVar14 = *puRam00000000033d3ed0;
                  FUN_00abbf40();
                  if ((uVar14 & 1) != 0) {
                    FUN_00c3ec70(&fStack_188);
                    fVar28 = 0.0;
                    fVar31 = fVar28;
                    fVar32 = fVar29;
                    fVar27 = fVar29;
                    if (*puVar12 != 0) goto LAB_00c3e2dc;
                    goto LAB_00c3e550;
                  }
                }
                break;
              }
              if (uVar17 != 0xffffffff) break;
              FUN_01765e80();
            }
            if ((puVar13 == (uint *)0x0) ||
               (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0)) break;
            FUN_01765e50();
            puVar23[0xc] = 0xfffffffe;
            if ((uint)puVar13 == 0) break;
            uVar17 = 0;
            puVar21 = puVar15 + 1;
            while (puVar15[(ulong)uVar17 * 2] != 0x91eaeedd) {
              uVar17 = uVar17 + 1;
              puVar21 = puVar21 + 2;
              if ((uint)puVar13 <= uVar17) goto LAB_00c3eab4;
            }
            uVar17 = 0;
            if (*puVar21 != 0xffffffff) {
              uVar17 = *puVar21;
            }
            puVar23[0xc] = uVar17;
            if (*puVar12 == 0) break;
          } while( true );
        }
        goto LAB_00c3eab4;
      }
LAB_00c3eaec:
      FUN_00fe93d0(&lStack_a0);
    }
  }
  return;
joined_r0x00c3deb8:
  if (iVar4 == 0) goto LAB_00c3e164;
  if (*pcRam00000000033f5488 == '\0') {
    *pcRam00000000033f5488 = '\x01';
    *puVar25 = 0xffffffffffffffff;
    puVar25[1] = 0xffffffffffffffff;
    puVar25[2] = 0xffffffffffffffff;
    *(undefined4 *)(puVar25 + 3) = 0xffffffff;
  }
  else {
    iVar4 = *(int *)((long)puVar25 + 4);
    if (-1 < iVar4) {
      if ((undefined2 *)((long)iVar4 + (long)piVar8) != (undefined2 *)0x0) {
        uVar16 = *(undefined2 *)((long)iVar4 + (long)piVar8);
        goto LAB_00c3e168;
      }
      goto LAB_00c3e164;
    }
    if (iVar4 != -1) goto LAB_00c3e164;
  }
  piVar26 = piVar8;
  FUN_01765e80();
  if ((piVar26 == (int *)0x0) || (piVar9 = piVar26, FUN_01765e60(), piVar9 == (int *)0x0))
  goto LAB_00c3e164;
  FUN_01765e50();
  *(undefined4 *)((long)puVar25 + 4) = 0xfffffffe;
  if ((uint)piVar26 == 0) goto LAB_00c3e164;
  uVar17 = 0;
  piVar10 = piVar9 + 1;
  while (piVar9[(ulong)uVar17 * 2] != 0x4765b463) {
    uVar17 = uVar17 + 1;
    piVar10 = piVar10 + 2;
    if ((uint)piVar26 <= uVar17) goto LAB_00c3e164;
  }
  iVar4 = 0;
  if (*piVar10 != -1) {
    iVar4 = *piVar10;
  }
  *(int *)((long)puVar25 + 4) = iVar4;
  iVar4 = *piVar8;
  goto joined_r0x00c3deb8;
LAB_00c3e164:
  uVar16 = 0x4c7b;
LAB_00c3e168:
  uVar14 = param_1;
  FUN_00c3f5e0(param_1,&fStack_188,uStack_1b0,uVar16);
joined_r0x00c3e178:
  if ((uVar14 & 1) != 0) {
    piVar26 = piVar8;
    FUN_00c400d0(piVar8);
    FUN_01a90820(auStack_170,piVar26);
    piVar26 = piVar8;
    FUN_00c40210(piVar8);
    FUN_01a90820(auStack_138,piVar26);
    piVar26 = piVar8;
    FUN_00c40350(piVar8);
    FUN_01a90820(auStack_118,piVar26);
    FUN_00c40490(piVar8);
    FUN_01a90820(auStack_e0,piVar8);
    if (*param_2 < param_2[1]) {
      puVar22 = *(undefined8 **)(param_2 + 4);
      if (puVar22 != (undefined8 *)0x0) {
        *(undefined8 *)(param_2 + 4) = *puVar22;
      }
      FUN_00c4abf0(puVar22,&fStack_188);
      if (*param_2 < param_2[1]) {
        *(undefined8 **)(*(long *)(param_2 + 2) + (long)*param_2 * 8) = puVar22;
        *param_2 = *param_2 + 1;
      }
    }
  }
LAB_00c3db78:
  uVar24 = uVar24 + 1;
  piVar8 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
  if ((int)*(uint *)(param_1 + 0x1c8) < 1) goto LAB_00c3db5c;
LAB_00c3db88:
  if ((uint)piVar8 <= uVar24) goto LAB_00c3e180;
  goto LAB_00c3db90;
LAB_00c3e2dc:
  do {
    fVar31 = fVar30;
    fVar27 = fVar28;
    if (*pcVar6 != '\0') {
      uVar17 = puVar23[2];
      if ((int)uVar17 < 0) {
        if (uVar17 == 0xffffffff) goto LAB_00c3e314;
LAB_00c3e3a0:
        uVar2 = *puVar12;
      }
      else {
        if ((float *)((long)(int)uVar17 + (long)puVar12) == (float *)0x0) goto LAB_00c3e3dc;
        uVar2 = *puVar12;
        fVar31 = *(float *)((long)(int)uVar17 + (long)puVar12);
      }
      goto joined_r0x00c3e3c4;
    }
    *pcVar6 = '\x01';
    puVar23[10] = 0xffffffff;
    puVar23[0xb] = 0xffffffff;
    puVar23[0xc] = 0xffffffff;
    puVar23[0xd] = 0xffffffff;
    puVar23[0] = 0xffffffff;
    puVar23[1] = 0xffffffff;
    puVar23[6] = 0xffffffff;
    puVar23[7] = 0xffffffff;
    puVar23[8] = 0xffffffff;
    puVar23[9] = 0xffffffff;
    puVar23[2] = 0xffffffff;
    puVar23[3] = 0xffffffff;
    puVar23[4] = 0xffffffff;
    puVar23[5] = 0xffffffff;
LAB_00c3e314:
    puVar13 = puVar12;
    FUN_01765e80();
    if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0))
    goto LAB_00c3e3a0;
    FUN_01765e50();
    puVar23[2] = 0xfffffffe;
    if ((uint)puVar13 == 0) goto LAB_00c3e3a0;
    uVar17 = 0;
    puVar21 = puVar15 + 1;
    while (puVar15[(ulong)uVar17 * 2] != 0x2633f2c1) {
      uVar17 = uVar17 + 1;
      puVar21 = puVar21 + 2;
      if ((uint)puVar13 <= uVar17) goto LAB_00c3e3a0;
    }
    uVar17 = 0;
    if (*puVar21 != 0xffffffff) {
      uVar17 = *puVar21;
    }
    puVar23[2] = uVar17;
  } while (*puVar12 != 0);
  fVar31 = fVar29;
  fVar32 = 0.0;
LAB_00c3e550:
  fStack_188 = fVar31;
  fStack_184 = fVar32;
  fStack_180 = fVar27;
  if (*puVar12 != 0) {
    do {
      if (*pcVar6 == '\0') {
        *pcVar6 = '\x01';
        puVar23[10] = 0xffffffff;
        puVar23[0xb] = 0xffffffff;
        puVar23[0xc] = 0xffffffff;
        puVar23[0xd] = 0xffffffff;
        puVar23[0] = 0xffffffff;
        puVar23[1] = 0xffffffff;
        puVar23[6] = 0xffffffff;
        puVar23[7] = 0xffffffff;
        puVar23[8] = 0xffffffff;
        puVar23[9] = 0xffffffff;
        puVar23[2] = 0xffffffff;
        puVar23[3] = 0xffffffff;
        puVar23[4] = 0xffffffff;
        puVar23[5] = 0xffffffff;
      }
      else {
        uVar17 = puVar23[5];
        if (-1 < (int)uVar17) {
          fVar28 = 0.0;
          if ((float *)((long)(int)uVar17 + (long)puVar12) != (float *)0x0) {
            fVar28 = *(float *)((long)(int)uVar17 + (long)puVar12);
          }
          break;
        }
        if (uVar17 != 0xffffffff) break;
      }
      puVar13 = puVar12;
      FUN_01765e80();
      if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0))
      break;
      FUN_01765e50();
      puVar23[5] = 0xfffffffe;
      if ((uint)puVar13 == 0) break;
      uVar17 = 0;
      puVar21 = puVar15 + 1;
      while (puVar15[(ulong)uVar17 * 2] != 0xd200ffd3) {
        uVar17 = uVar17 + 1;
        puVar21 = puVar21 + 2;
        if ((uint)puVar13 <= uVar17) goto LAB_00c3e620;
      }
      uVar17 = 0;
      if (*puVar21 != 0xffffffff) {
        uVar17 = *puVar21;
      }
      puVar23[5] = uVar17;
      if (*puVar12 == 0) break;
    } while( true );
  }
LAB_00c3e620:
  uStack_17c = (undefined4)(long)(fVar28 * fVar5);
  puVar13 = puVar12;
  FUN_01765ea0();
  if ((*puVar7 <= (uint)puVar13) ||
     (uVar3 = *(ushort *)(*(long *)(puVar7 + 2) + (long)(int)(uint)puVar13 * 2),
     uStack_c0 = (uint)uVar3, 2 < uVar3)) {
    uStack_c0 = 0;
  }
  uVar17 = *puVar12;
  while (pcVar19 = (char *)(ulong)uVar17, uVar17 != 0) {
    if (*pcVar6 != '\0') {
      uVar17 = puVar23[0xc];
      if ((int)uVar17 < 0) {
        if (uVar17 == 0xffffffff) goto LAB_00c3e69c;
LAB_00c3e718:
        pcVar19 = (char *)0x0;
      }
      else {
        pcVar19 = (char *)((long)(int)uVar17 + (long)puVar12);
        if (pcVar19 != (char *)0x0) {
          pcVar19 = (char *)(ulong)(*pcVar19 != '\0');
        }
      }
      break;
    }
    *pcVar6 = '\x01';
    puVar23[10] = 0xffffffff;
    puVar23[0xb] = 0xffffffff;
    puVar23[0xc] = 0xffffffff;
    puVar23[0xd] = 0xffffffff;
    puVar23[0] = 0xffffffff;
    puVar23[1] = 0xffffffff;
    puVar23[6] = 0xffffffff;
    puVar23[7] = 0xffffffff;
    puVar23[8] = 0xffffffff;
    puVar23[9] = 0xffffffff;
    puVar23[2] = 0xffffffff;
    puVar23[3] = 0xffffffff;
    puVar23[4] = 0xffffffff;
    puVar23[5] = 0xffffffff;
LAB_00c3e69c:
    puVar13 = puVar12;
    FUN_01765e80();
    if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0))
    goto LAB_00c3e718;
    FUN_01765e50();
    puVar23[0xc] = 0xfffffffe;
    pcVar19 = (char *)0x0;
    if ((uint)puVar13 == 0) break;
    puVar21 = puVar15 + 1;
    while (puVar15[(long)pcVar19 * 2] != 0x91eaeedd) {
      uVar17 = (int)pcVar19 + 1;
      pcVar19 = (char *)(ulong)uVar17;
      puVar21 = puVar21 + 2;
      if ((uint)puVar13 <= uVar17) goto LAB_00c3e718;
    }
    uVar17 = 0;
    if (*puVar21 != 0xffffffff) {
      uVar17 = *puVar21;
    }
    puVar23[0xc] = uVar17;
    uVar17 = *puVar12;
  }
  uStack_bc = SUB81(pcVar19,0);
  fVar31 = fVar29;
  fVar32 = fVar29;
  fVar27 = fVar30;
  if (*puVar12 != 0) {
    do {
      fVar31 = fVar30;
      if (*pcVar6 != '\0') {
        uVar17 = puVar23[8];
        if ((int)uVar17 < 0) {
          if (uVar17 == 0xffffffff) goto LAB_00c3e76c;
LAB_00c3e7f8:
          uVar2 = *puVar12;
        }
        else {
          if ((float *)((long)(int)uVar17 + (long)puVar12) == (float *)0x0) goto LAB_00c3e870;
          uVar2 = *puVar12;
          fVar31 = *(float *)((long)(int)uVar17 + (long)puVar12);
        }
        goto joined_r0x00c3e858;
      }
      *pcVar6 = '\x01';
      puVar23[10] = 0xffffffff;
      puVar23[0xb] = 0xffffffff;
      puVar23[0xc] = 0xffffffff;
      puVar23[0xd] = 0xffffffff;
      puVar23[0] = 0xffffffff;
      puVar23[1] = 0xffffffff;
      puVar23[6] = 0xffffffff;
      puVar23[7] = 0xffffffff;
      puVar23[8] = 0xffffffff;
      puVar23[9] = 0xffffffff;
      puVar23[2] = 0xffffffff;
      puVar23[3] = 0xffffffff;
      puVar23[4] = 0xffffffff;
      puVar23[5] = 0xffffffff;
LAB_00c3e76c:
      puVar13 = puVar12;
      FUN_01765e80();
      if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0))
      goto LAB_00c3e7f8;
      FUN_01765e50();
      puVar23[8] = 0xfffffffe;
      if ((uint)puVar13 == 0) goto LAB_00c3e7f8;
      uVar17 = 0;
      puVar21 = puVar15 + 1;
      while (puVar15[(ulong)uVar17 * 2] != 0x1f3893e5) {
        uVar17 = uVar17 + 1;
        puVar21 = puVar21 + 2;
        if ((uint)puVar13 <= uVar17) goto LAB_00c3e7f8;
      }
      uVar17 = 0;
      if (*puVar21 != 0xffffffff) {
        uVar17 = *puVar21;
      }
      puVar23[8] = uVar17;
    } while (*puVar12 != 0);
    fVar32 = 0.0;
  }
LAB_00c3e9e4:
  fStack_a4 = fVar27;
  puVar23 = puRam00000000033f54c8;
  fStack_ac = fVar31;
  fStack_a8 = fVar32;
  if (*param_2 < param_2[1]) {
    puVar25 = *(undefined8 **)(param_2 + 4);
    if (puVar25 != (undefined8 *)0x0) {
      *(undefined8 *)(param_2 + 4) = *puVar25;
    }
    FUN_00c4abf0(puVar25,&fStack_188);
    puVar23 = puRam00000000033f54c8;
    if (*param_2 < param_2[1]) {
      *(undefined8 **)(*(long *)(param_2 + 2) + (long)*param_2 * 8) = puVar25;
      *param_2 = *param_2 + 1;
      puVar23 = puRam00000000033f54c8;
    }
  }
LAB_00c3eab4:
  uVar24 = uVar24 + 1;
  puVar12 = (uint *)(ulong)*(uint *)(param_1 + 0x3c8);
  if ((int)*(uint *)(param_1 + 0x3c8) < 1) goto LAB_00c3e1c0;
LAB_00c3eac4:
  if ((uint)puVar12 <= uVar24) goto LAB_00c3eaec;
  goto LAB_00c3eacc;
joined_r0x00c3e3c4:
  if (uVar2 == 0) goto LAB_00c3e550;
  if (*pcVar6 != '\0') {
    uVar17 = puVar23[3];
    if ((int)uVar17 < 0) {
      if (uVar17 == 0xffffffff) goto LAB_00c3e41c;
      goto LAB_00c3e808;
    }
    if ((float *)((long)(int)uVar17 + (long)puVar12) == (float *)0x0) {
LAB_00c3e484:
      uVar2 = *puVar12;
      fVar32 = 0.0;
    }
    else {
      uVar2 = *puVar12;
      fVar32 = *(float *)((long)(int)uVar17 + (long)puVar12);
    }
joined_r0x00c3ea70:
    if (uVar2 != 0) goto LAB_00c3e48c;
    goto LAB_00c3e550;
  }
  *pcVar6 = '\x01';
  puVar23[10] = 0xffffffff;
  puVar23[0xb] = 0xffffffff;
  puVar23[0xc] = 0xffffffff;
  puVar23[0xd] = 0xffffffff;
  puVar23[0] = 0xffffffff;
  puVar23[1] = 0xffffffff;
  puVar23[6] = 0xffffffff;
  puVar23[7] = 0xffffffff;
  puVar23[8] = 0xffffffff;
  puVar23[9] = 0xffffffff;
  puVar23[2] = 0xffffffff;
  puVar23[3] = 0xffffffff;
  puVar23[4] = 0xffffffff;
  puVar23[5] = 0xffffffff;
LAB_00c3e41c:
  puVar13 = puVar12;
  FUN_01765e80();
  if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0)) {
LAB_00c3e808:
    uVar2 = *puVar12;
    goto joined_r0x00c3ea70;
  }
  FUN_01765e50();
  puVar23[3] = 0xfffffffe;
  if ((uint)puVar13 == 0) goto LAB_00c3e808;
  uVar17 = 0;
  puVar21 = puVar15 + 1;
  while (puVar15[(ulong)uVar17 * 2] != 0x1b53db71) {
    uVar17 = uVar17 + 1;
    puVar21 = puVar21 + 2;
    if ((uint)puVar13 <= uVar17) goto LAB_00c3e484;
  }
  uVar17 = 0;
  if (*puVar21 != 0xffffffff) {
    uVar17 = *puVar21;
  }
  puVar23[3] = uVar17;
LAB_00c3e3dc:
  uVar2 = *puVar12;
  goto joined_r0x00c3e3c4;
LAB_00c3e48c:
  if (*pcVar6 == '\0') {
    *pcVar6 = '\x01';
    puVar23[10] = 0xffffffff;
    puVar23[0xb] = 0xffffffff;
    puVar23[0xc] = 0xffffffff;
    puVar23[0xd] = 0xffffffff;
    puVar23[0] = 0xffffffff;
    puVar23[1] = 0xffffffff;
    puVar23[6] = 0xffffffff;
    puVar23[7] = 0xffffffff;
    puVar23[8] = 0xffffffff;
    puVar23[9] = 0xffffffff;
    puVar23[2] = 0xffffffff;
    puVar23[3] = 0xffffffff;
    puVar23[4] = 0xffffffff;
    puVar23[5] = 0xffffffff;
  }
  else {
    uVar17 = puVar23[4];
    if (-1 < (int)uVar17) {
      if ((float *)((long)(int)uVar17 + (long)puVar12) != (float *)0x0) {
        fVar27 = *(float *)((long)(int)uVar17 + (long)puVar12);
      }
      goto LAB_00c3e550;
    }
    if (uVar17 != 0xffffffff) goto LAB_00c3e550;
  }
  puVar13 = puVar12;
  FUN_01765e80();
  if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0))
  goto LAB_00c3e550;
  FUN_01765e50();
  puVar23[4] = 0xfffffffe;
  if ((uint)puVar13 == 0) goto LAB_00c3e550;
  uVar17 = 0;
  puVar21 = puVar15 + 1;
  while (puVar15[(ulong)uVar17 * 2] != 0x5cf3a1a1) {
    uVar17 = uVar17 + 1;
    puVar21 = puVar21 + 2;
    if ((uint)puVar13 <= uVar17) goto LAB_00c3e550;
  }
  uVar17 = 0;
  if (*puVar21 != 0xffffffff) {
    uVar17 = *puVar21;
  }
  puVar23[4] = uVar17;
  if (*puVar12 == 0) goto LAB_00c3e550;
  goto LAB_00c3e48c;
joined_r0x00c3e858:
  fVar32 = fVar30;
  if (uVar2 == 0) goto LAB_00c3e9e4;
  if (*pcVar6 != '\0') {
    uVar17 = puVar23[1];
    if ((int)uVar17 < 0) {
      if (uVar17 == 0xffffffff) goto LAB_00c3e8b0;
      goto LAB_00c3ea4c;
    }
    if ((float *)((long)(int)uVar17 + (long)puVar12) == (float *)0x0) {
LAB_00c3e918:
      uVar2 = *puVar12;
    }
    else {
      uVar2 = *puVar12;
      fVar32 = *(float *)((long)(int)uVar17 + (long)puVar12);
    }
joined_r0x00c3ea8c:
    if (uVar2 != 0) goto LAB_00c3e920;
    goto LAB_00c3e9e4;
  }
  *pcVar6 = '\x01';
  puVar23[10] = 0xffffffff;
  puVar23[0xb] = 0xffffffff;
  puVar23[0xc] = 0xffffffff;
  puVar23[0xd] = 0xffffffff;
  puVar23[0] = 0xffffffff;
  puVar23[1] = 0xffffffff;
  puVar23[6] = 0xffffffff;
  puVar23[7] = 0xffffffff;
  puVar23[8] = 0xffffffff;
  puVar23[9] = 0xffffffff;
  puVar23[2] = 0xffffffff;
  puVar23[3] = 0xffffffff;
  puVar23[4] = 0xffffffff;
  puVar23[5] = 0xffffffff;
LAB_00c3e8b0:
  puVar13 = puVar12;
  FUN_01765e80();
  if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0)) {
LAB_00c3ea4c:
    uVar2 = *puVar12;
    goto joined_r0x00c3ea8c;
  }
  FUN_01765e50();
  puVar23[1] = 0xfffffffe;
  if ((uint)puVar13 == 0) goto LAB_00c3ea4c;
  uVar17 = 0;
  puVar21 = puVar15 + 1;
  while (puVar15[(ulong)uVar17 * 2] != 0x2258ba55) {
    uVar17 = uVar17 + 1;
    puVar21 = puVar21 + 2;
    if ((uint)puVar13 <= uVar17) goto LAB_00c3e918;
  }
  uVar17 = 0;
  if (*puVar21 != 0xffffffff) {
    uVar17 = *puVar21;
  }
  puVar23[1] = uVar17;
LAB_00c3e870:
  uVar2 = *puVar12;
  goto joined_r0x00c3e858;
LAB_00c3e920:
  if (*pcVar6 == '\0') {
    *pcVar6 = '\x01';
    puVar23[10] = 0xffffffff;
    puVar23[0xb] = 0xffffffff;
    puVar23[0xc] = 0xffffffff;
    puVar23[0xd] = 0xffffffff;
    puVar23[0] = 0xffffffff;
    puVar23[1] = 0xffffffff;
    puVar23[6] = 0xffffffff;
    puVar23[7] = 0xffffffff;
    puVar23[8] = 0xffffffff;
    puVar23[9] = 0xffffffff;
    puVar23[2] = 0xffffffff;
    puVar23[3] = 0xffffffff;
    puVar23[4] = 0xffffffff;
    puVar23[5] = 0xffffffff;
  }
  else {
    uVar17 = *puVar23;
    if (-1 < (int)uVar17) {
      if ((float *)((long)(int)uVar17 + (long)puVar12) != (float *)0x0) {
        fVar27 = *(float *)((long)(int)uVar17 + (long)puVar12);
      }
      goto LAB_00c3e9e4;
    }
    if (uVar17 != 0xffffffff) goto LAB_00c3e9e4;
  }
  puVar13 = puVar12;
  FUN_01765e80();
  if ((puVar13 == (uint *)0x0) || (puVar15 = puVar13, FUN_01765e60(), puVar15 == (uint *)0x0))
  goto LAB_00c3e9e4;
  FUN_01765e50();
  *puVar23 = 0xfffffffe;
  if ((uint)puVar13 == 0) goto LAB_00c3e9e4;
  uVar17 = 0;
  puVar21 = puVar15 + 1;
  while (puVar15[(ulong)uVar17 * 2] != 0x65f8c085) {
    uVar17 = uVar17 + 1;
    puVar21 = puVar21 + 2;
    if ((uint)puVar13 <= uVar17) goto LAB_00c3e9e4;
  }
  uVar17 = 0;
  if (*puVar21 != 0xffffffff) {
    uVar17 = *puVar21;
  }
  *puVar23 = uVar17;
  if (*puVar12 == 0) goto LAB_00c3e9e4;
  goto LAB_00c3e920;
}

