
bool FUN_00c2b2c0(long param_1)

{
  return (*(uint *)(param_1 + 8) & 0xfffffffe) == 2;
}

