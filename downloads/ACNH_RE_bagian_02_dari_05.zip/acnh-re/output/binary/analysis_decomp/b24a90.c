
void FUN_00c24a90(long param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x2408) = param_2;
  return;
}

