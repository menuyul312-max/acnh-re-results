
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c2c9d0(float param_1,long param_2,ulong param_3)

{
  int iVar1;
  long *plVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  long lVar6;
  long *plVar7;
  long lStack_50;
  undefined4 uStack_48;
  
  lVar6 = *(long *)(param_2 + 0x20);
  if (lVar6 != 0) {
    iVar1 = *(int *)(param_2 + 0x2c);
    if (iVar1 == 2) {
      plVar2 = *(long **)(lVar6 + 0x228);
    }
    else if (iVar1 == 1) {
      plVar2 = *(long **)(lVar6 + 0x220);
    }
    else {
      if (iVar1 != 0) {
        return;
      }
      plVar2 = *(long **)(lVar6 + 0x218);
    }
    if ((plVar2 != (long *)0x0) && ((**(code **)(*plVar2 + 0x220))(), plVar2 != (long *)0x0)) {
      plVar7 = (long *)plVar2[9];
      if (plVar7 != (long *)0x0) {
        lStack_50 = lRam00000000033f51d8 + 0x10;
        uStack_48 = 0x41;
        param_1 = param_1 * _UNK_02ad6108;
        (**(code **)(*plVar7 + 0x18))(plVar7,&lStack_50);
        (**(code **)(plVar7[3] + 0x428))(param_1,plVar7[1],1);
      }
      uVar3 = param_3;
      FUN_001233a0(param_3);
      uVar4 = param_3;
      FUN_00123350(param_3);
      uVar5 = param_3;
      FUN_00123520(param_3);
      FUN_00123530(param_3);
      FUN_01785ec0(plVar2,uVar3,uVar4 & 0xffffffff,uVar5,param_3);
    }
  }
  return;
}

