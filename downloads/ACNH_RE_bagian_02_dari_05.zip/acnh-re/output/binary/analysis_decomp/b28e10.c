
void FUN_00c28e10(long param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  uVar1 = *puRam00000000033d0f28;
  FUN_00c127d0();
  FUN_00c24aa0();
  *(undefined8 *)(param_1 + 0x10) = uVar1;
  *(undefined8 *)(param_1 + 0x18) = param_2;
  return;
}

