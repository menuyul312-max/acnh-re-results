
void _INIT_267(void)

{
  int iVar1;
  char cVar2;
  char cVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  ulong uVar7;
  long lVar8;
  long lStack_40;
  undefined *puStack_38;
  
  lStack_40 = CONCAT44(lStack_40._4_4_,2);
  uRam0000000003450058 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x34500a0);
  uVar5 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000345005c = uVar5;
  uVar5 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003450060 = uVar5;
  uVar6 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003450084 = 0xffff;
  uRam0000000003450080 = 0xffffffff;
  uRam000000000345008c = 0;
  uRam0000000003450088 = 0;
  uRam0000000003450064 = (undefined4)uVar6;
  uRam0000000003450068 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003450098 = 0;
  lRam00000000034500b0 = lRam00000000033d0670 + 0x10;
  lVar8 = lRam00000000033d0668 + 0x10;
  puStack_38 = &UNK_02ac0a89;
  puRam00000000034500b8 = (undefined *)0x34500c4;
  iRam00000000034500c0 = 0x20;
  uRam0000000003450090 = uVar6;
  lStack_40 = lVar8;
  FUN_01a90780(0x34500b0);
  puVar4 = puRam00000000034500b8;
  lRam00000000034500b0 = lRam00000000033d0678 + 0x10;
  if (puRam00000000034500b8 != &UNK_02ac0a89) {
    cVar2 = *pcRam00000000033d0660;
    uVar7 = 0;
    cVar3 = UNK_02ac0a89;
    while (cVar3 != cVar2) {
      if (uVar7 >> 0x13 != 0) {
        uVar7 = 0;
        break;
      }
      if ((&UNK_02ac0a8a)[uVar7] == cVar2) {
        uVar7 = uVar7 + 1;
        break;
      }
      cVar3 = (&UNK_02ac0a8b)[uVar7];
      uVar7 = uVar7 + 2;
    }
    iVar1 = (int)uVar7;
    if (iRam00000000034500c0 <= (int)uVar7) {
      iVar1 = iRam00000000034500c0 + -1;
    }
    memcpy(puRam00000000034500b8,&UNK_02ac0a89,(long)iVar1);
    puVar4[iVar1] = cVar2;
    lVar8 = lStack_40;
  }
  lRam00000000034500b0 = lRam00000000033d0680 + 0x10;
  (**(code **)(lVar8 + 0x18))(&lStack_40);
  FUN_00101bf0(puStack_38,0);
  uRam00000000034500e8 = (int)puStack_38;
  uRam000000000345006c = 0x200000003;
  iRam0000000003450074 = -*piRam00000000033d0630;
  iRam0000000003450078 = *piRam00000000033d0630;
  return;
}

