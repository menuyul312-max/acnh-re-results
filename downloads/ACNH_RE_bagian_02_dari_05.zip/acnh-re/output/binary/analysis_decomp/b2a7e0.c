
void _INIT_2637(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654340 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654380);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654344 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654348 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000365435c = 0xffff;
  uRam0000000003654358 = 0xffffffff;
  uRam0000000003654364 = 0;
  uRam0000000003654360 = 0;
  uRam000000000365434c = (undefined4)uVar2;
  uRam0000000003654350 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654368 = uVar2;
  uRam0000000003654370 = 0;
  return;
}

