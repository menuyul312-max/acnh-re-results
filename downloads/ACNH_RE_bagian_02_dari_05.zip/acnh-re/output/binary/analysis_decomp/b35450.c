
long FUN_00c35450(long param_1)

{
  return param_1 + 8;
}

