
void FUN_00c35d70(long param_1)

{
  byte bVar1;
  long lVar2;
  uint uVar3;
  long lStack_48;
  long lStack_40;
  undefined4 auStack_30 [2];
  long lStack_28;
  
  lVar2 = param_1;
  FUN_00fecf00();
  FUN_00fe9350(&lStack_48,lVar2 + 0xe7118,1);
  lStack_48 = lRam00000000033d4cb0 + 0x10;
  lStack_28 = *(long *)(lStack_40 + 0x10) + *(long *)(lStack_40 + 8) + 4;
  auStack_30[0] = 10;
  FUN_010e4670(param_1,auStack_30);
  bVar1 = *(byte *)(*(long *)(lStack_40 + 0x10) + *(long *)(lStack_40 + 8) + 0x18);
  uVar3 = 2;
  if (bVar1 < 4) {
    uVar3 = (uint)bVar1;
  }
  *(uint *)(param_1 + 0xf8) = uVar3;
  FUN_00fe93d0(&lStack_48);
  return;
}

