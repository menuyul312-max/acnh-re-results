
void FUN_00c2bee0(long *param_1)

{
  long lVar1;
  undefined1 auStack_30 [16];
  
  (**(code **)(*(long *)param_1[4] + 0xf0))();
  FUN_00c2bf50(param_1);
  FUN_0177e1b0(param_1[4]);
  lVar1 = *param_1;
  FUN_00c24b20();
  if (lVar1 != 0) {
    FUN_00c28f30();
  }
  FUN_01385ac0(param_1[4],auStack_30);
  *(undefined4 *)(param_1 + 5) = 1;
  return;
}

