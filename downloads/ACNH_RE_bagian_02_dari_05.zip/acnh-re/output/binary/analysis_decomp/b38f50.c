
/* WARNING: Type propagation algorithm not settling */

uint FUN_00c38f50(long param_1,short *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined1 *puVar3;
  long *plVar4;
  long lVar5;
  ulong uVar6;
  int iVar7;
  undefined1 auStack_830 [8];
  undefined1 auStack_828 [24];
  long alStack_810 [238];
  undefined1 auStack_a0 [24];
  long lStack_88;
  long lStack_80;
  long lStack_70;
  long *plStack_68;
  uint uStack_60;
  char cStack_5c;
  int aiStack_48 [2];
  
  if ((*param_2 == -2) || (FUN_00fecf00(), param_1 == 0)) {
    uVar2 = 0;
    goto LAB_00c3925c;
  }
  FUN_00fe9350(&lStack_88,param_1 + 0x20a168,1);
  lStack_88 = lRam00000000033d8a08 + 0x10;
  FUN_00b9c290(auStack_a0,param_2);
  puVar3 = auStack_a0;
  FUN_00b9cb60(puVar3,0x46);
  if (((ulong)puVar3 & 1) == 0) {
LAB_00c39250:
    uVar2 = 0;
  }
  else {
    aiStack_48[0] = (int)auStack_a0;
    FUN_00bb09d0();
    if (aiStack_48[0] != 0) {
      FUN_00b0ee00(alStack_810);
      (**(code **)(alStack_810[0] + 0x18))(alStack_810);
      memset();
      FUN_00b0fdf0(&lStack_70,aiStack_48);
      FUN_002af3a0(alStack_810,&lStack_70);
      plVar4 = alStack_810;
      (**(code **)(alStack_810[0] + 0x20))();
      uVar2 = 0;
      plStack_68 = plVar4;
      cStack_5c = '\x01';
      uStack_60 = 0;
      do {
        uVar1 = uVar2;
        if ((1 << (ulong)(uVar2 & 0x1f) & *(uint *)((long)plVar4 + (ulong)(uVar2 >> 5) * 4)) != 0)
        break;
        uVar2 = uVar2 + 1;
        uVar1 = uStack_60;
      } while (uVar2 >> 3 < 0x753);
      uStack_60 = uVar1;
      uVar1 = uStack_60;
      lStack_70 = lRam00000000033d7888 + 0x10;
      plVar4 = alStack_810;
      (**(code **)(alStack_810[0] + 0x20))();
      uVar2 = 15000;
      do {
        if ((1 << (ulong)(uVar2 - 1 & 0x1f) & *(uint *)((long)plVar4 + (ulong)(uVar2 - 1 >> 5) * 4))
            != 0) break;
        uVar2 = uVar2 - 1;
      } while (uVar2 != 0);
joined_r0x00c390d8:
      if (uVar2 != uVar1) {
        do {
          FUN_00b0f610(auStack_830,&lStack_70);
          FUN_00b9c290(auStack_828,auStack_830);
          puVar3 = auStack_828;
          FUN_00b9cb60(puVar3,0x46);
          if (((ulong)puVar3 & 1) != 0) {
            uVar6 = *(long *)(lStack_80 + 0x10) + *(long *)(lStack_80 + 8);
            FUN_00b0f610(auStack_828,&lStack_70);
            FUN_01077f60(uVar6,auStack_828);
            if ((uVar6 & 1) != 0) {
              uVar2 = 1;
              goto LAB_00c39254;
            }
          }
          while (uStack_60 = uStack_60 + 1, uStack_60 >> 3 < 0x753) {
            uVar1 = uStack_60;
            if (((*(uint *)((long)plStack_68 + (ulong)(uStack_60 >> 5) * 4) &
                 1 << (ulong)(uStack_60 & 0x1f)) != 0) == (bool)cStack_5c) goto joined_r0x00c390d8;
          }
          uStack_60 = 0x3a95;
          iVar7 = 14999;
          do {
            if ((cStack_5c != '\0') ==
                ((1 << (ulong)(uStack_60 + 2 & 0x1f) &
                 *(uint *)((long)plStack_68 + (ulong)(uStack_60 + 2 >> 5) * 4)) != 0)) {
LAB_00c39228:
              uStack_60 = iVar7 + 1;
              uVar1 = uStack_60;
              goto joined_r0x00c390d8;
            }
            if ((cStack_5c != '\0') ==
                ((1 << (ulong)(uStack_60 + 1 & 0x1f) &
                 *(uint *)((long)plStack_68 + (ulong)(uStack_60 + 1 >> 5) * 4)) != 0)) {
              iVar7 = iVar7 + -1;
              goto LAB_00c39228;
            }
            if ((cStack_5c != '\0') ==
                ((1 << (ulong)(uStack_60 & 0x1f) &
                 *(uint *)((long)plStack_68 + (ulong)(uStack_60 >> 5) * 4)) != 0)) {
              uStack_60 = uStack_60 + 1;
              uVar1 = uStack_60;
              goto joined_r0x00c390d8;
            }
            uStack_60 = uStack_60 - 3;
            iVar7 = iVar7 + -3;
          } while (uStack_60 != 0xfffffffd);
          uStack_60 = 0;
        } while (uVar2 != 0);
      }
      goto LAB_00c39250;
    }
    lVar5 = *(long *)(lStack_80 + 0x10) + *(long *)(lStack_80 + 8);
    FUN_01077f60(lVar5,param_2);
    uVar2 = (uint)lVar5;
  }
LAB_00c39254:
  FUN_00fe93d0(&lStack_88);
LAB_00c3925c:
  return uVar2 & 1;
}

