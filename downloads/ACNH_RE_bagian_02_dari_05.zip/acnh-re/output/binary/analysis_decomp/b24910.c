
void FUN_00c24910(long param_1,byte param_2,byte param_3)

{
  *(undefined1 *)(param_1 + 0x246f) = 1;
  *(byte *)(param_1 + 0x2470) = param_2 & 1;
  *(byte *)(param_1 + 0x2471) = param_3 & 1;
  *(undefined1 *)(param_1 + 0x2472) = 0;
  return;
}

