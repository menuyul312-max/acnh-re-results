
/* WARNING: Type propagation algorithm not settling */

void FUN_00c3f030(long param_1,long param_2,uint *param_3,uint param_4)

{
  int iVar1;
  char *pcVar2;
  undefined8 *puVar3;
  uint *puVar4;
  uint *puVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  
  puVar3 = puRam00000000033f54c8;
  pcVar2 = pcRam00000000033f54c0;
  puVar5 = (uint *)(param_1 + 0x608);
  uVar6 = *param_3;
  while (puVar7 = (uint *)(ulong)uVar6, uVar6 != 0) {
    puVar8 = param_3;
    if (*pcVar2 != '\0') {
      iVar1 = *(int *)((long)puVar3 + 0x1c);
      if (iVar1 < 0) {
        if ((iVar1 == -1) && (FUN_01765e80(), puVar8 != (uint *)0x0)) goto LAB_00c3f0ac;
      }
      else {
        puVar7 = (uint *)((long)iVar1 + (long)param_3);
        if ((puVar7 == (uint *)0x0) ||
           (uVar6 = *puVar7, puVar7 = (uint *)(ulong)uVar6, uVar6 < 0x11)) break;
      }
LAB_00c3f154:
      puVar7 = (uint *)0x0;
      break;
    }
    *pcVar2 = '\x01';
    *puVar3 = 0xffffffffffffffff;
    puVar3[5] = 0xffffffffffffffff;
    puVar3[6] = 0xffffffffffffffff;
    puVar3[3] = 0xffffffffffffffff;
    puVar3[4] = 0xffffffffffffffff;
    puVar3[1] = 0xffffffffffffffff;
    puVar3[2] = 0xffffffffffffffff;
    FUN_01765e80();
    if (puVar8 == (uint *)0x0) goto LAB_00c3f154;
LAB_00c3f0ac:
    puVar4 = puVar8;
    FUN_01765e60();
    if (puVar4 == (uint *)0x0) goto LAB_00c3f154;
    FUN_01765e50();
    puVar7 = (uint *)0x0;
    *(undefined4 *)((long)puVar3 + 0x1c) = 0xfffffffe;
    if ((uint)puVar8 == 0) break;
    puVar9 = puVar4 + 1;
    while (puVar4[(long)puVar7 * 2] != 0x3e884a6d) {
      uVar6 = (int)puVar7 + 1;
      puVar7 = (uint *)(ulong)uVar6;
      puVar9 = puVar9 + 2;
      if ((uint)puVar8 <= uVar6) goto LAB_00c3f154;
    }
    uVar6 = 0;
    if (*puVar9 != 0xffffffff) {
      uVar6 = *puVar9;
    }
    *(uint *)((long)puVar3 + 0x1c) = uVar6;
    uVar6 = *param_3;
  }
  FUN_00c42bc0(puVar5,(uint)puVar7 & 0xffff);
  puVar7 = puRam00000000033f5538;
  pcVar2 = pcRam00000000033f5530;
  if (puVar5 == (uint *)0x0) {
    return;
  }
  puVar8 = (uint *)(ulong)*puVar5;
  if (*puVar5 == 0) {
LAB_00c3f250:
    if (param_4 != (ushort)puVar8) {
      return;
    }
  }
  else {
    do {
      puVar8 = puVar5;
      if (*pcVar2 != '\0') {
        uVar6 = puVar7[2];
        if ((int)uVar6 < 0) {
          if ((uVar6 == 0xffffffff) && (FUN_01765e80(), puVar8 != (uint *)0x0)) goto LAB_00c3f1c0;
LAB_00c3f248:
          puVar8 = (uint *)0x0;
          goto LAB_00c3f250;
        }
        puVar8 = (uint *)((long)(int)uVar6 + (long)puVar5);
        if ((puVar8 == (uint *)0x0) ||
           (uVar6 = *puVar8, puVar8 = (uint *)(ulong)uVar6, uVar6 < 0x23)) goto LAB_00c3f250;
        break;
      }
      *pcVar2 = '\x01';
      puVar7[0] = 0xffffffff;
      puVar7[1] = 0xffffffff;
      puVar7[2] = 0xffffffff;
      puVar7[3] = 0xffffffff;
      puVar7[4] = 0xffffffff;
      puVar7[5] = 0xffffffff;
      FUN_01765e80();
      if (puVar8 == (uint *)0x0) goto LAB_00c3f248;
LAB_00c3f1c0:
      puVar4 = puVar8;
      FUN_01765e60();
      if (puVar4 == (uint *)0x0) goto LAB_00c3f248;
      FUN_01765e50();
      puVar7[2] = 0xfffffffe;
      if ((uint)puVar8 == 0) goto LAB_00c3f248;
      uVar6 = 0;
      puVar9 = puVar4 + 1;
      while (puVar4[(ulong)uVar6 * 2] != 0x110ca7b2) {
        uVar6 = uVar6 + 1;
        puVar9 = puVar9 + 2;
        if ((uint)puVar8 <= uVar6) goto LAB_00c3f248;
      }
      uVar6 = 0;
      if (*puVar9 != 0xffffffff) {
        uVar6 = *puVar9;
      }
      puVar7[2] = uVar6;
    } while (*puVar5 != 0);
    if (param_4 != 0) {
      return;
    }
  }
  uVar10 = 0;
  *(undefined1 *)(param_2 + 0xcd) = 1;
  puVar7 = puRam00000000033f5538;
  pcVar2 = pcRam00000000033f5530;
  if (*puVar5 != 0) {
    do {
      puVar8 = puVar5;
      if (*pcVar2 == '\0') {
        *pcVar2 = '\x01';
        puVar7[2] = 0xffffffff;
        puVar7[3] = 0xffffffff;
        puVar7[4] = 0xffffffff;
        puVar7[5] = 0xffffffff;
        puVar7[0] = 0xffffffff;
        puVar7[1] = 0xffffffff;
        FUN_01765e80();
      }
      else {
        uVar6 = puVar7[3];
        if (-1 < (int)uVar6) {
          if ((undefined4 *)((long)(int)uVar6 + (long)puVar5) == (undefined4 *)0x0) break;
          *(undefined4 *)(param_2 + 0xd0) = *(undefined4 *)((long)(int)uVar6 + (long)puVar5);
          uVar6 = *puVar5;
          pcVar2 = pcRam00000000033f5530;
          puVar7 = puRam00000000033f5538;
          goto joined_r0x00c3f57c;
        }
        if (uVar6 != 0xffffffff) goto LAB_00c3f338;
        FUN_01765e80();
      }
      if ((puVar8 == (uint *)0x0) || (puVar4 = puVar8, FUN_01765e60(), puVar4 == (uint *)0x0))
      goto LAB_00c3f338;
      FUN_01765e50();
      puVar7[3] = 0xfffffffe;
      if ((uint)puVar8 == 0) goto LAB_00c3f338;
      uVar6 = 0;
      puVar9 = puVar4 + 1;
      while (puVar4[(ulong)uVar6 * 2] != 0xf230d34) {
        uVar6 = uVar6 + 1;
        puVar9 = puVar9 + 2;
        if ((uint)puVar8 <= uVar6) goto LAB_00c3f354;
      }
      uVar6 = 0;
      if (*puVar9 != 0xffffffff) {
        uVar6 = *puVar9;
      }
      puVar7[3] = uVar6;
      if (*puVar5 == 0) goto LAB_00c3f338;
    } while( true );
  }
LAB_00c3f354:
  *(undefined4 *)(param_2 + 0xd0) = 0;
  uVar6 = *puVar5;
  pcVar2 = pcRam00000000033f5530;
  puVar7 = puRam00000000033f5538;
joined_r0x00c3f57c:
  pcRam00000000033f5530 = pcVar2;
  puRam00000000033f5538 = puVar7;
  if (uVar6 != 0) {
    do {
      puVar8 = puVar5;
      if (*pcVar2 == '\0') {
        *pcVar2 = '\x01';
        puVar7[2] = 0xffffffff;
        puVar7[3] = 0xffffffff;
        puVar7[4] = 0xffffffff;
        puVar7[5] = 0xffffffff;
        puVar7[0] = 0xffffffff;
        puVar7[1] = 0xffffffff;
        FUN_01765e80();
      }
      else {
        uVar6 = puVar7[1];
        if (-1 < (int)uVar6) {
          if ((undefined4 *)((long)(int)uVar6 + (long)puVar5) == (undefined4 *)0x0) break;
          *(undefined4 *)(param_2 + 0xd4) = *(undefined4 *)((long)(int)uVar6 + (long)puVar5);
          uVar6 = *puVar5;
          pcVar2 = pcRam00000000033f5530;
          puVar7 = puRam00000000033f5538;
          goto joined_r0x00c3f43c;
        }
        if (uVar6 != 0xffffffff) goto LAB_00c3f430;
        FUN_01765e80();
      }
      if ((puVar8 == (uint *)0x0) || (puVar4 = puVar8, FUN_01765e60(), puVar4 == (uint *)0x0))
      goto LAB_00c3f430;
      FUN_01765e50();
      puVar7[1] = 0xfffffffe;
      if ((uint)puVar8 == 0) goto LAB_00c3f430;
      uVar6 = 0;
      puVar9 = puVar4 + 1;
      while (puVar4[(ulong)uVar6 * 2] != 0x32432484) {
        uVar6 = uVar6 + 1;
        puVar9 = puVar9 + 2;
        if ((uint)puVar8 <= uVar6) goto LAB_00c3f448;
      }
      uVar6 = 0;
      if (*puVar9 != 0xffffffff) {
        uVar6 = *puVar9;
      }
      puVar7[1] = uVar6;
      if (*puVar5 == 0) goto LAB_00c3f430;
    } while( true );
  }
LAB_00c3f448:
  *(undefined4 *)(param_2 + 0xd4) = 0;
  uVar6 = *puVar5;
  pcVar2 = pcRam00000000033f5530;
  puVar7 = puRam00000000033f5538;
joined_r0x00c3f43c:
  do {
    uVar11 = 0;
    if (uVar6 == 0) {
LAB_00c3f5b0:
      *(undefined4 *)(param_2 + 0xd8) = uVar11;
      return;
    }
    puVar8 = puVar5;
    uVar11 = uVar10;
    if (*pcVar2 == '\0') {
      *pcVar2 = '\x01';
      ((uint *)((long)puVar7 + 8U))[0] = 0xffffffff;
      ((uint *)((long)puVar7 + 8U))[1] = 0xffffffff;
      ((uint *)((long)puVar7 + 0x10U))[0] = 0xffffffff;
      ((uint *)((long)puVar7 + 0x10U))[1] = 0xffffffff;
      *(undefined8 *)puVar7 = 0xffffffffffffffff;
      FUN_01765e80();
    }
    else {
      uVar6 = *puVar7;
      if (-1 < (int)uVar6) {
        if ((undefined4 *)((long)(int)uVar6 + (long)puVar5) != (undefined4 *)0x0) {
          uVar11 = *(undefined4 *)((long)(int)uVar6 + (long)puVar5);
        }
        goto LAB_00c3f5b0;
      }
      if (uVar6 != 0xffffffff) goto LAB_00c3f5b0;
      FUN_01765e80();
    }
    if ((puVar8 == (uint *)0x0) || (puVar4 = puVar8, FUN_01765e60(), puVar4 == (uint *)0x0))
    goto LAB_00c3f5b0;
    FUN_01765e50();
    *puVar7 = 0xfffffffe;
    if ((uint)puVar8 == 0) goto LAB_00c3f5b0;
    uVar6 = 0;
    puVar9 = puVar4 + 1;
    while (puVar4[(ulong)uVar6 * 2] != 0x75e35e54) {
      uVar6 = uVar6 + 1;
      puVar9 = puVar9 + 2;
      if ((uint)puVar8 <= uVar6) goto LAB_00c3f5b0;
    }
    uVar6 = 0;
    if (*puVar9 != 0xffffffff) {
      uVar6 = *puVar9;
    }
    *puVar7 = uVar6;
    uVar6 = *puVar5;
  } while( true );
LAB_00c3f338:
  *(undefined4 *)(param_2 + 0xd0) = 0;
  uVar6 = *puVar5;
  pcVar2 = pcRam00000000033f5530;
  puVar7 = puRam00000000033f5538;
  goto joined_r0x00c3f57c;
LAB_00c3f430:
  *(undefined4 *)(param_2 + 0xd4) = 0;
  uVar6 = *puVar5;
  pcVar2 = pcRam00000000033f5530;
  puVar7 = puRam00000000033f5538;
  goto joined_r0x00c3f43c;
}

