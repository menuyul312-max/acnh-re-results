
void FUN_00c37c70(long *param_1)

{
  undefined8 *puVar1;
  
  puVar1 = puRam00000000033f52e8;
  *param_1 = lRam00000000033f52e0 + 0x10;
  if ((long *)*puVar1 != param_1) {
    FUN_01a83cd0(param_1);
    return;
  }
  *puVar1 = 0;
  puVar1 = puRam00000000033d3ef8;
  (*(code *)**(undefined8 **)*puRam00000000033d3ef8)();
  *puVar1 = 0;
  FUN_01a83cd0(param_1);
  return;
}

