
void FUN_00c3a1b0(long param_1)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  
  puVar2 = puRam00000000033f5338;
  if (*(long *)(puRam00000000033f5338 + 2) != 0) {
    _ZdaPv();
    *(undefined8 *)(puVar2 + 2) = 0;
    *puVar2 = 0;
  }
  *puRam00000000033f5318 = 1;
  puVar1 = puRam00000000033f5320;
  *puRam00000000033f5320 = 0xffffffffffffffff;
  puVar1[1] = 0xffffffffffffffff;
  *(undefined4 *)(puVar1 + 2) = 0xffffffff;
  *(undefined8 *)(param_1 + 0xb0) = 0;
  if (*(long *)(param_1 + 0xd0) != 0) {
    _ZdaPv();
    *(undefined8 *)(param_1 + 0xd0) = 0;
    *(undefined4 *)(param_1 + 200) = 0;
  }
  if (*(long *)(param_1 + 0x1b8) != 0) {
    _ZdaPv();
    *(undefined8 *)(param_1 + 0x1b8) = 0;
    *(undefined4 *)(param_1 + 0x1b0) = 0;
  }
  *(undefined4 *)(param_1 + 0x1c0) = 0xffffffff;
  if (*(long *)(param_1 + 0x1d0) != 0) {
    _ZdaPv();
    *(undefined8 *)(param_1 + 0x1d0) = 0;
    *(undefined4 *)(param_1 + 0x1c8) = 0;
  }
  return;
}

