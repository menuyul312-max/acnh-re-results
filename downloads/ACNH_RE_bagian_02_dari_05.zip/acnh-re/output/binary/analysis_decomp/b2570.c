
void FUN_001b2570(long param_1,long param_2)

{
  int *piVar1;
  int *piVar2;
  undefined8 uVar3;
  long lVar4;
  
  if (*(char *)(param_1 + 0x1928) == '\0') {
    return;
  }
  FUN_01aa25a0(param_1 + 0x1930);
  piVar1 = (int *)(param_1 + 8);
  piVar2 = piVar1 + (long)(int)*(uint *)(param_2 + 0x24) * 0x324;
  if (1 < *(uint *)(param_2 + 0x24)) {
    piVar2 = piVar1;
  }
  if (0 < *piVar2) {
    lVar4 = 0;
    do {
      uVar3 = *(undefined8 *)(*(long *)(piVar2 + 2) + lVar4 * 8);
      FUN_001b1450(uVar3,param_2);
      if ((int)uVar3 == 0) {
        if ((int)lVar4 != -1) goto LAB_001b2640;
        break;
      }
      lVar4 = lVar4 + 1;
    } while (lVar4 < *piVar2);
  }
  piVar2 = (int *)(param_1 + (long)(int)*(uint *)(param_2 + 0x24) * 0xc90 + 8);
  if (1 < *(uint *)(param_2 + 0x24)) {
    piVar2 = piVar1;
  }
  if (*piVar2 < piVar2[1]) {
    *(long *)(*(long *)(piVar2 + 2) + (long)*piVar2 * 8) = param_2;
    *piVar2 = *piVar2 + 1;
  }
LAB_001b2640:
  FUN_01aa25c0(param_1 + 0x1930);
  return;
}

