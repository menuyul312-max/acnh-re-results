
void FUN_001b3ee0(ulong param_1,undefined8 param_2)

{
  ulong uVar1;
  undefined1 *puVar2;
  undefined1 auStack_38 [8];
  undefined1 auStack_28 [8];
  
  FUN_001b60c0();
  *(undefined8 *)(param_1 + 0x10) = 0;
  *(long *)(param_1 + 8) = 0;
  uVar1 = param_1;
  FUN_001b6270();
  if ((uVar1 & 1) != 0) {
    uVar1 = param_1;
    FUN_001b62b0();
    if ((uVar1 & 1) == 0) {
      FUN_001b60c0(auStack_38,param_2);
      puVar2 = auStack_38;
      FUN_00fed070();
      *(long *)(param_1 + 8) = (long)puVar2;
      puVar2 = auStack_38;
    }
    else {
      FUN_001b60c0(auStack_28,param_2);
      puVar2 = auStack_28;
      FUN_00fed430();
      *(undefined1 **)(param_1 + 0x10) = puVar2;
      puVar2 = auStack_28;
    }
    FUN_001b6250(puVar2);
  }
  return;
}

