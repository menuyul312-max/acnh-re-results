
void FUN_00c31070(long *param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  long *plVar2;
  long lVar3;
  long *plVar4;
  
  lVar3 = lRam00000000033f5238;
  lVar1 = lRam00000000033d96e8;
  *(undefined4 *)(param_1 + 1) = 0;
  lVar1 = lVar1 + 0x10;
  *param_1 = lVar3 + 0x10;
  plVar4 = param_1 + 2;
  *plVar4 = lVar1;
  FUN_00123650(plVar4,param_1 + 0x1e,0x80);
  *plVar4 = lVar1;
  plVar4 = param_1 + 0x3e;
  plVar2 = plVar4;
  if (plVar4 <= (long *)((long)param_1 + 0xf2)) {
    plVar2 = (long *)((long)param_1 + 0xf2);
  }
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  memset(param_1 + 0x1e,0,(long)plVar2 + (-0xef - (long)param_1) & 0xfffffffffffffffe);
  param_1[0x3e] = lVar1;
  FUN_00123650(plVar4,param_1 + 0x5a,0x80);
  plVar4 = param_1 + 0x7a;
  if (param_1 + 0x7a <= (long *)((long)param_1 + 0x2d2)) {
    plVar4 = (long *)((long)param_1 + 0x2d2);
  }
  param_1[0x3e] = lVar1;
  param_1[0x79] = 0;
  param_1[0x78] = 0;
  param_1[0x77] = 0;
  param_1[0x76] = 0;
  param_1[0x75] = 0;
  param_1[0x74] = 0;
  param_1[0x73] = 0;
  param_1[0x72] = 0;
  param_1[0x71] = 0;
  param_1[0x70] = 0;
  param_1[0x6f] = 0;
  param_1[0x6e] = 0;
  param_1[0x6d] = 0;
  param_1[0x6c] = 0;
  param_1[0x6b] = 0;
  param_1[0x6a] = 0;
  param_1[0x69] = 0;
  param_1[0x68] = 0;
  param_1[0x67] = 0;
  param_1[0x66] = 0;
  param_1[0x65] = 0;
  param_1[100] = 0;
  param_1[99] = 0;
  param_1[0x62] = 0;
  param_1[0x61] = 0;
  param_1[0x60] = 0;
  param_1[0x5f] = 0;
  param_1[0x5e] = 0;
  param_1[0x5d] = 0;
  param_1[0x5c] = 0;
  param_1[0x5b] = 0;
  param_1[0x5a] = 0;
  memset(param_1 + 0x5a,0,(long)plVar4 + (-0x2cf - (long)param_1) & 0xfffffffffffffffe);
  FUN_00c31230(param_1,param_2,param_3);
  return;
}

