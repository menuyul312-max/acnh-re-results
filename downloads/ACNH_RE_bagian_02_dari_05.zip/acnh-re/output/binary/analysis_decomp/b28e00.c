
void FUN_00c28e00(long param_1)

{
  *(undefined1 *)(param_1 + 0xc) = 0xff;
  return;
}

