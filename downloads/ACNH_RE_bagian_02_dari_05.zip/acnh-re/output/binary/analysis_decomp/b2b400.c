
void FUN_00c2b400(ulong *param_1)

{
  long lVar1;
  undefined1 uVar2;
  ulong uVar3;
  ulong *puVar4;
  undefined8 uStack_60;
  long *plStack_58;
  long lStack_50;
  undefined1 uStack_48;
  undefined1 *puStack_40;
  ushort uStack_38;
  undefined4 uStack_34;
  undefined1 auStack_30 [16];
  
  lVar1 = (ulong)(uint)param_1[1] * 0x10;
  (**(code **)(lVar1 + 0x31ced88))((long)param_1 + (*(long *)(lVar1 + 0x31ced90) >> 1));
  uVar3 = *param_1;
  FUN_00c24b20();
  puVar4 = param_1 + 4;
  if ((uVar3 != 0) && (*(char *)(uVar3 + 0x1a0) != '\0')) {
    puVar4 = (ulong *)(uVar3 + 0x168);
  }
  uVar3 = *param_1;
  FUN_00c24b20();
  if (uVar3 != 0) {
    FUN_00c28f30();
  }
  uStack_48 = 0;
  puStack_40 = (undefined1 *)0x0;
  uStack_38 = 1;
  uStack_34 = 0;
  lStack_50 = lRam00000000033f51a8 + 0x10;
  if ((uVar3 & 1) != 0) {
    puStack_40 = auStack_30;
  }
  uVar2 = (undefined1)*param_1;
  FUN_00c24c30();
  uStack_38 = CONCAT11(uVar2,(undefined1)uStack_38) & 0x1ff;
  uStack_34 = *(undefined4 *)((long)param_1 + 0x1c);
  plStack_58 = &lStack_50;
  uStack_60 = 0;
  FUN_017500d0(puVar4,&uStack_60);
  if ((int)param_1[1] != 0) {
    *(undefined4 *)((long)param_1 + 0x1c) = 0;
  }
  return;
}

