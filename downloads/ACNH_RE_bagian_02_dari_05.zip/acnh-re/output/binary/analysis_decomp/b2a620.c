
bool FUN_00c2a620(int *param_1)

{
  return *param_1 == 1;
}

