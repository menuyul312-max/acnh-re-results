
long * FUN_00c28780(long *param_1,undefined8 param_2,long *param_3)

{
  long lVar1;
  long *plVar2;
  undefined1 *puVar3;
  ulong uVar4;
  long *plVar5;
  long lVar6;
  long *plVar7;
  undefined1 auStack_48 [8];
  
  if ((int)param_1[3] < *(int *)((long)param_1 + 0x1c)) {
    plVar7 = (long *)param_1[1];
    if (plVar7 != (long *)0x0) {
      param_1[1] = *plVar7;
    }
    *plVar7 = lRam00000000033f4aa8 + 0x10;
    FUN_00122d60(plVar7 + 4);
    plVar7[2] = 0;
    plVar7[3] = 0;
    *plVar7 = lRam00000000033f50c0 + 0x10;
    plVar7[1] = 0;
    lVar6 = param_3[1];
    plVar5 = plVar7 + 5;
    plVar7[5] = *param_3;
    plVar7[6] = lVar6;
    plVar7[7] = (long)param_1;
    FUN_00122e00(plVar7 + 4,param_2);
    *(int *)(param_1 + 3) = (int)param_1[3] + 1;
    plVar2 = param_1;
    FUN_00bf7ec0(param_1,*param_1,plVar7);
    *param_1 = (long)plVar2;
    plVar2[3] = 1;
  }
  else {
    FUN_00122da0(auStack_48,param_2);
    for (lVar6 = *param_1; lVar6 != 0; lVar6 = *(long *)(lVar6 + 8)) {
      while( true ) {
        uVar4 = lVar6 + 0x20;
        puVar3 = auStack_48;
        FUN_00122e60(puVar3,uVar4);
        if (((ulong)puVar3 & 1) != 0) break;
        FUN_00122e60(uVar4,auStack_48);
        if (((uVar4 & 1) == 0) || (lVar6 = *(long *)(lVar6 + 0x10), lVar6 == 0)) goto LAB_00c2888c;
      }
    }
LAB_00c2888c:
    FUN_00122dc0(auStack_48);
    plVar5 = (long *)(lVar6 + 0x28);
    if (lVar6 == 0) {
      plVar5 = (long *)0x0;
    }
    else {
      lVar1 = param_3[1];
      *plVar5 = *param_3;
      *(long *)(lVar6 + 0x30) = lVar1;
    }
  }
  return plVar5;
}

