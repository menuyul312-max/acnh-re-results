
undefined1 FUN_001b2550(long param_1)

{
  return *(undefined1 *)(param_1 + 0x1928);
}

