
undefined8 * FUN_00c29bf0(long param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  byte *pbVar3;
  
  puVar1 = (undefined8 *)(param_1 + 0x168);
  FUN_01750090();
  if (((*pbRam00000000033f5118 & 1) == 0) &&
     (pbVar3 = pbRam00000000033f5118, __cxa_guard_acquire(), (int)pbVar3 != 0)) {
    *plRam00000000033f5120 = lRam00000000033f5128 + 0x10;
    __cxa_guard_release(pbRam00000000033f5118);
  }
  if (puVar1 == (undefined8 *)0x0) {
    return (undefined8 *)0x0;
  }
  puVar2 = puVar1;
  (**(code **)*puVar1)(puVar1,plRam00000000033f5120);
  if (((ulong)puVar2 & 1) == 0) {
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

