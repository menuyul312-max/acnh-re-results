
long FUN_00c248f0(long param_1)

{
  return param_1 + 0x25b0;
}

