
void FUN_00c2e1d0(long *param_1)

{
  *param_1 = lRam00000000033f5218 + 0x10;
  return;
}

