
bool FUN_00c2a610(int *param_1)

{
  return *param_1 == 0;
}

