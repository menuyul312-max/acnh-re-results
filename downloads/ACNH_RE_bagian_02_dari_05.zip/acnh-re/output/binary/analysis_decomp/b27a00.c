
void FUN_00c27a00(long param_1)

{
  FUN_0011e470();
  FUN_00c2dec0(param_1 + 0x2170);
  *(undefined4 *)(param_1 + 0x2184) = 0;
  *(undefined4 *)(param_1 + 0x218c) = 0xffffffff;
  FUN_001232c0(param_1 + 0x218);
  FUN_001232c0(param_1 + 0x6f8);
  *(undefined4 *)(param_1 + 0xbd8) = 0;
  FUN_00c2c360(*(undefined8 *)(param_1 + 0x210));
  FUN_00bee5a0(param_1 + 0xbe0);
  FUN_00be4c80(param_1 + 0x1030);
  *(undefined1 *)(param_1 + 0x1480) = 0;
  FUN_00be56c0(param_1 + 0x1488);
  FUN_00be56c0(param_1 + 0x1af8);
  *(undefined1 *)(param_1 + 0x2194) = 0;
  *(undefined4 *)(param_1 + 0x2190) = 0;
  FUN_00c20600(param_1 + 0x2198);
  *(undefined4 *)(param_1 + 0x2188) = 0;
  return;
}

