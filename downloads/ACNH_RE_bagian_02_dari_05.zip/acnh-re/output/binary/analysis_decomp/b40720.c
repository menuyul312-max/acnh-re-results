
void FUN_00c40720(long param_1,int *param_2,int param_3)

{
  ulong uVar1;
  uint uVar2;
  ushort uVar3;
  uint *puVar4;
  ulong uVar5;
  ulong uVar6;
  long lVar7;
  undefined8 *puVar8;
  uint uVar9;
  undefined8 *puVar10;
  uint auStack_b0 [14];
  undefined1 auStack_78 [36];
  uint uStack_54;
  
  if (param_2 != (int *)0x0) {
    if (0 < *param_2) {
      lVar7 = 0;
      puVar10 = *(undefined8 **)(param_2 + 4);
      do {
        puVar8 = *(undefined8 **)(*(long *)(param_2 + 2) + lVar7 * 8);
        *puVar8 = puVar10;
        lVar7 = lVar7 + 1;
        *(undefined8 **)(param_2 + 4) = puVar8;
        puVar10 = puVar8;
      } while (lVar7 < *param_2);
    }
    uStack_54 = 0;
    *param_2 = 0;
    puVar4 = puRam00000000033f5580;
    if (param_3 < 0x17f77b87) {
      if (param_3 < -0xe632453) {
        if (param_3 == -0x477aafe0) {
          uStack_54 = 5;
        }
        else if (param_3 == -0x2099c902) {
          uStack_54 = 9;
        }
        else if (param_3 == -0x15fdefdb) {
          uStack_54 = 7;
        }
      }
      else if (param_3 == -0xe632453) {
        uStack_54 = 3;
      }
      else if (param_3 == -0x83ceb3d) {
        uStack_54 = 4;
      }
      else if (param_3 == -0x169521c) {
        uStack_54 = 1;
      }
    }
    else if (param_3 < 0x337f0c42) {
      if (param_3 == 0x17f77b87) {
        uStack_54 = 8;
      }
      else if (param_3 == 0x23f13b17) {
        uStack_54 = 10;
      }
      else if (param_3 == 0x3072bd3f) {
        uStack_54 = 0xb;
      }
    }
    else if (param_3 == 0x337f0c42) {
      uStack_54 = 0xc;
    }
    else if (param_3 == 0x3b3bf38a) {
      uStack_54 = 6;
    }
    else if (param_3 == 0x3fce6459) {
      uStack_54 = 2;
    }
    uVar9 = 0;
    uVar1 = param_1 + 0x408;
    uVar2 = *(uint *)(param_1 + 0x5c8);
    while( true ) {
      uVar5 = (ulong)uVar2;
      if (((int)uVar2 < 1) && (uVar5 = uVar1, FUN_01766670(), uVar5 != 0)) {
        FUN_01765e30();
      }
      if ((uint)uVar5 <= uVar9) break;
      uVar5 = uVar1;
      FUN_00c40a10(uVar1,uVar9);
      uVar2 = uStack_54;
      if (uVar5 != 0) {
        uVar6 = uVar5;
        FUN_01765ea0();
        if ((*puVar4 <= (uint)uVar6) ||
           (uVar3 = *(ushort *)(*(long *)(puVar4 + 2) + (long)(int)(uint)uVar6 * 2),
           auStack_b0[0] = (uint)uVar3, 0xc < uVar3)) {
          auStack_b0[0] = 0;
        }
        if (uVar2 == auStack_b0[0]) {
          FUN_00c40b60(auStack_b0);
          uVar6 = uVar5;
          FUN_00c40d30(uVar5);
          FUN_01a90820(auStack_b0,uVar6);
          FUN_00c40e60(uVar5);
          FUN_01a90820(auStack_78,uVar5);
          if (*param_2 < param_2[1]) {
            puVar10 = *(undefined8 **)(param_2 + 4);
            if (puVar10 != (undefined8 *)0x0) {
              *(undefined8 *)(param_2 + 4) = *puVar10;
            }
            FUN_00c4b050(puVar10,auStack_b0);
            if (*param_2 < param_2[1]) {
              *(undefined8 **)(*(long *)(param_2 + 2) + (long)*param_2 * 8) = puVar10;
              *param_2 = *param_2 + 1;
            }
          }
        }
      }
      uVar9 = uVar9 + 1;
      uVar2 = *(uint *)(param_1 + 0x5c8);
    }
  }
  return;
}

