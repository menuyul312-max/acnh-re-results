
void FUN_00c35e10(long *param_1,undefined8 param_2)

{
  long lVar1;
  ulong uVar2;
  
  lVar1 = lRam00000000033d5200 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0xb);
  uVar2 = (long)param_1 + 0xf6U;
  if ((long)param_1 + 0xf6U <= (long)param_1 + 0xe2U) {
    uVar2 = (long)param_1 + 0xe2U;
  }
  *param_1 = lVar1;
  *(undefined8 *)((long)param_1 + 0xee) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  memset(param_1 + 0x1c,0,(uVar2 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  *(undefined4 *)(param_1 + 0x1f) = 2;
  FUN_00c35eb0(param_1,param_2);
  return;
}

