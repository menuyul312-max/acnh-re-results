
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c3d840(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  if (param_2 != (float *)0x0) {
    fVar1 = (float)NEON_ucvtf(param_1[3]);
    fVar7 = param_1[0x39];
    fVar5 = param_1[0x37];
    fVar6 = param_1[0x38];
    fVar1 = fVar1 * _UNK_02ad63cc;
    fVar2 = fVar1;
    cosf();
    sinf();
    fVar3 = *param_1;
    fVar4 = param_1[2];
    param_2[1] = fVar6 + param_1[1];
    *param_2 = fVar3 + fVar5 * fVar2 + fVar7 * fVar1;
    param_2[2] = (fVar7 * fVar2 - fVar5 * fVar1) + fVar4;
  }
  return;
}

