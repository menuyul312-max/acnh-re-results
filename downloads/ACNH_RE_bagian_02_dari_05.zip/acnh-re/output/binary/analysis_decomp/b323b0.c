
void FUN_00c323b0(long *param_1,uint param_2,undefined8 param_3)

{
  long lVar1;
  undefined1 *puVar2;
  ulong uVar3;
  long *plVar4;
  long lStack_70;
  long lStack_68;
  undefined1 auStack_58 [8];
  undefined4 auStack_50 [2];
  long lStack_48;
  undefined1 auStack_38 [8];
  
  lVar1 = lRam00000000033f4800 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0x10);
  plVar4 = param_1 + 0x20;
  if (param_1 + 0x20 <= (long *)((long)param_1 + 0xe2)) {
    plVar4 = (long *)((long)param_1 + 0xe2);
  }
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  *param_1 = lVar1;
  memset(param_1 + 0x1c,0,(long)plVar4 + (-0xdf - (long)param_1) & 0xfffffffffffffffe);
  FUN_00ea3fc0(auStack_38,param_3);
  FUN_00ea3fc0(auStack_58,auStack_38);
  puVar2 = auStack_58;
  thunk_FUN_00faafd0();
  if (puVar2 == (undefined1 *)0x0) {
    return;
  }
  FUN_00fe9350(&lStack_70,puVar2,1);
  lVar1 = lRam00000000033d4d20;
  lStack_70 = lRam00000000033d4d20 + 0x10;
  uVar3 = (ulong)param_2;
  FUN_00ff1f20(uVar3,*(long *)(lStack_68 + 0x10) + *(long *)(lStack_68 + 8) + 0xaf98);
  FUN_00fe93d0(&lStack_70);
  if (uVar3 == 0) {
    FUN_00fe9350(&lStack_70,puVar2 + 0x165e0,1);
    lStack_48 = *(long *)(lStack_68 + 0x10) + *(long *)(lStack_68 + 8);
  }
  else {
    FUN_00fe9350(&lStack_70,uVar3,1);
    lStack_70 = lRam00000000033d9ab0 + 0x10;
    auStack_50[0] = 10;
    lStack_48 = *(long *)(lStack_68 + 0x10) + *(long *)(lStack_68 + 8) + 0x138;
    FUN_010e4670(param_1,auStack_50);
    FUN_00fe93d0(&lStack_70);
    plVar4 = param_1;
    FUN_001232e0();
    if (((ulong)plVar4 & 1) == 0) goto LAB_00c32598;
    FUN_00fe9350(&lStack_70,puVar2 + 0x165e0,1);
    lStack_48 = *(long *)(lStack_68 + 0x10) + *(long *)(lStack_68 + 8);
  }
  lStack_70 = lRam00000000033d98a0 + 0x10;
  auStack_50[0] = 10;
  lStack_48 = lStack_48 + 4;
  FUN_010e4670(param_1,auStack_50);
  FUN_00fe93d0(&lStack_70);
LAB_00c32598:
  FUN_00fe9350(&lStack_70,puVar2,1);
  lStack_70 = lVar1 + 0x10;
  FUN_00fe93d0(&lStack_70);
  FUN_001234f0(param_1);
  FUN_00121d40();
  return;
}

