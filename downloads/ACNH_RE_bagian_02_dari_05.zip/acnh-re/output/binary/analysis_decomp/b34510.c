
void _INIT_2660(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655898 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36558e8);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000365589c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam00000000036558a0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036558bc = 0xffff;
  uRam00000000036558b8 = 0xffffffff;
  uRam00000000036558c4 = 0;
  uRam00000000036558c0 = 0;
  uRam00000000036558a4 = (undefined4)uVar2;
  uRam00000000036558a8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036558d0 = 0;
  uRam00000000036558c8 = uVar2;
  FUN_010588a0(0x36558d8,0x1c2b);
  FUN_010588a0(0x36558e0,0x142e);
  iRam00000000036558ac = -*piRam00000000033d0630;
  iRam00000000036558b0 = *piRam00000000033d0630;
  return;
}

