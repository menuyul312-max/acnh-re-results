
void FUN_00c2cde0(long param_1)

{
  long *plVar1;
  
  plVar1 = *(long **)(param_1 + 0x18);
  if ((*(int *)(*plVar1 + 0x244) == 1) && ((int)plVar1[1] == 2)) {
    *(undefined1 *)(*(long *)(*plVar1 + 0x220) + 0x305) = 1;
    *(undefined4 *)(plVar1 + 1) = 3;
  }
  return;
}

