
void FUN_00c2b3e0(long param_1,int param_2)

{
  if (*(int *)(param_1 + 8) == 2) {
    *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + param_2;
  }
  return;
}

