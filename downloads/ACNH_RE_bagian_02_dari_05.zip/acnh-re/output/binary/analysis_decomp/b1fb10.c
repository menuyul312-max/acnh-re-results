
void FUN_00c1fb10(undefined8 *param_1,undefined8 param_2)

{
  long lVar1;
  
  *param_1 = param_2;
  lVar1 = lRam00000000033f4df0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[1] = lVar1 + 0x10;
  FUN_00c18c50(param_1 + 7);
  FUN_00c18c50(param_1 + 0x310);
  lVar1 = lRam00000000033f4df8;
  param_1[0x619] = 0;
  param_1[0x310] = lVar1 + 0x10;
  FUN_016bbd80(param_1 + 7,8);
  FUN_016bbd80(param_1 + 0x310,8);
  return;
}

