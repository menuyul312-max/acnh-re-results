
void FUN_00c29220(long param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = (undefined8 *)(param_1 + 0x128);
  puVar2 = puVar1;
  (**(code **)(*(long *)(param_1 + 0x128) + 0x10))();
  if (((ulong)puVar2 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c29260. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*puVar1)(puVar1,param_2);
    return;
  }
  return;
}

