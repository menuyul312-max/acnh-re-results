
bool FUN_00c38b20(undefined8 param_1,ulong param_2)

{
  int iVar1;
  ulong uVar2;
  undefined1 *puVar3;
  long *plVar4;
  int iVar5;
  long lVar6;
  long alStack_7e0 [238];
  int aiStack_70 [2];
  undefined1 auStack_68 [24];
  undefined4 auStack_50 [8];
  
  plVar4 = alStack_7e0;
  uVar2 = param_2;
  FUN_01058d00();
  if ((uVar2 & 1) != 0) {
    FUN_00b9c290(auStack_68,param_2);
    puVar3 = auStack_68;
    FUN_00b9cb60(puVar3,0x46);
    if (((ulong)puVar3 & 1) != 0) {
      aiStack_70[0] = (int)auStack_68;
      FUN_00bb09d0();
      if (aiStack_70[0] != 0) {
        FUN_00b0ee00(alStack_7e0);
        (**(code **)(alStack_7e0[0] + 0x18))(alStack_7e0);
        memset();
        FUN_00b0fdf0(auStack_50,aiStack_70);
        FUN_002af3a0(alStack_7e0,auStack_50);
        auStack_50[0] = 0x46;
        FUN_0039cb90(alStack_7e0,auStack_50);
        (**(code **)(alStack_7e0[0] + 0x20))();
        lVar6 = 0;
        iVar5 = 0;
        do {
          iVar1 = *(int *)((long)plVar4 + lVar6);
          FUN_01a8b590(iVar1);
          lVar6 = lVar6 + 4;
          iVar5 = iVar1 + iVar5;
        } while (lVar6 != 0x754);
        return iVar5 == 1;
      }
      return true;
    }
  }
  return false;
}

