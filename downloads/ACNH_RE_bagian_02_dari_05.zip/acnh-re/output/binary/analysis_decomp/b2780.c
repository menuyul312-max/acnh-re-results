
undefined4 FUN_001b2780(float *param_1,long param_2,int *param_3)

{
  float *pfVar1;
  long *plVar2;
  long lVar3;
  float *pfVar4;
  ulong *puVar5;
  long lVar6;
  undefined4 uVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  
  pfVar1 = pfRam00000000033d06b0;
  uVar7 = 0;
  if ((param_2 != 0) && (param_3 != (int *)0x0)) {
    fVar12 = pfRam00000000033d06b0[2];
    fVar10 = *pfRam00000000033d06b0;
    fVar11 = pfRam00000000033d06b0[1];
    if (param_1[2] == 0.0) {
      fVar14 = 0.0;
      uVar7 = 0;
      fVar13 = fVar14;
    }
    else {
      fVar14 = 0.0;
      puVar5 = *(ulong **)(param_1 + 4);
      lVar6 = (long)(int)param_1[2] << 3;
      uVar7 = 0;
      fVar13 = fVar14;
      do {
        pfVar4 = (float *)*puVar5;
        fVar8 = pfVar1[2];
        lVar3 = *(long *)pfVar1;
        FUN_001b29a0();
        if (((ulong)param_1 & 1) != 0) {
          if (*param_3 < param_3[1]) {
            plVar2 = *(long **)(param_3 + 4);
            if (plVar2 != (long *)0x0) {
              *(long *)(param_3 + 4) = *plVar2;
            }
            *plVar2 = (long)(pfVar4 + 2);
            *(float *)(plVar2 + 4) = fVar8;
            plVar2[2] = (ulong)(uint)fVar8;
            plVar2[3] = lVar3;
            plVar2[1] = lVar3;
            if (*param_3 < param_3[1]) {
              *(long **)(*(long *)(param_3 + 2) + (long)*param_3 * 8) = plVar2;
              *param_3 = *param_3 + 1;
            }
          }
          fVar8 = pfVar4[0xd];
          if (fVar13 == fVar8 || fVar13 < fVar8 != (NAN(fVar13) || NAN(fVar8))) {
            fVar13 = fVar8;
          }
          fVar14 = fVar14 + fVar8;
          (**(code **)(*(long *)pfVar4 + 0x50))();
          (**(code **)(*(long *)pfVar4 + 0x28))();
          fVar11 = fVar11 + pfVar4[1];
          fVar10 = fVar10 + *pfVar4;
          fVar12 = fVar12 + pfVar4[2];
          fVar9 = fVar10 * fVar10 + fVar11 * fVar11 + fVar12 * fVar12;
          fVar8 = SQRT(fVar9);
          if (NAN(fVar8)) {
            fVar8 = fVar9;
            sqrtf();
            if (5.0 < fVar14) {
              fVar14 = 5.0;
            }
            if (fVar8 != 0.0 && fVar8 < 0.0 == NAN(fVar8)) {
LAB_001b292c:
              fVar8 = 1.0 / fVar8;
              fVar10 = fVar10 * fVar8;
              fVar11 = fVar11 * fVar8;
              fVar12 = fVar12 * fVar8;
            }
          }
          else {
            if (5.0 < fVar14) {
              fVar14 = 5.0;
            }
            if (fVar8 != 0.0 && fVar8 < 0.0 == NAN(fVar8)) goto LAB_001b292c;
          }
          uVar7 = 1;
          param_1 = pfVar4;
        }
        puVar5 = puVar5 + 1;
        lVar6 = lVar6 + -8;
      } while (lVar6 != 0);
    }
    param_3[0xcb] = (int)fVar13;
    param_3[0xcc] = (int)fVar14;
    param_3[200] = (int)fVar10;
    param_3[0xc9] = (int)fVar11;
    param_3[0xca] = (int)fVar12;
  }
  return uVar7;
}

