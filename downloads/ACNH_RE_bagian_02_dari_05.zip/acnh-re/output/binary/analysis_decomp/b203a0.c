
void FUN_00c203a0(long param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  *(undefined8 *)(param_1 + 0x28) = param_3;
  *(undefined8 *)(param_1 + 0x30) = param_4;
  FUN_00122290(param_2);
  uVar1 = param_2;
  FUN_001222a0();
  if ((uint)uVar1 < 7) {
    FUN_00c20420(param_1,param_2);
  }
  else if ((uint)uVar1 == 0x14) {
    FUN_00c204e0(param_1);
  }
  else {
    FUN_00c1fe80(param_1,param_2);
  }
  *(undefined8 *)(param_1 + 0x28) = 0;
  *(undefined8 *)(param_1 + 0x30) = 0;
  return;
}

