
void FUN_00c2cb00(long *param_1)

{
  long lVar1;
  long lVar2;
  ulong uVar3;
  long lVar4;
  long lStack_568;
  undefined *puStack_560;
  undefined8 uStack_488;
  undefined8 uStack_480;
  undefined8 uStack_478;
  undefined8 uStack_470;
  undefined8 uStack_468;
  undefined8 uStack_460;
  undefined8 uStack_458;
  undefined8 uStack_450;
  undefined8 uStack_448;
  undefined8 uStack_440;
  undefined8 uStack_438;
  undefined8 uStack_430;
  undefined8 uStack_428;
  undefined8 uStack_420;
  undefined8 uStack_418;
  undefined8 uStack_410;
  long lStack_408;
  undefined *puStack_400;
  undefined1 auStack_3f8 [952];
  
  lVar2 = *param_1;
  FUN_00c24b20();
  lVar4 = *(long *)(param_1[4] + 0x218);
  if (lVar2 == 0) {
    FUN_0138b7e0();
    if (lVar4 != 0) {
      FUN_00c1b690(auStack_3f8);
      lStack_568 = lRam00000000033d0668 + 0x10;
      puStack_560 = &UNK_02a51b36;
      puStack_400 = &UNK_02a92bb9;
      lStack_408 = lStack_568;
      FUN_00c1aa20(auStack_3f8,lVar4,&lStack_568,&lStack_408);
      FUN_00c1af00(auStack_3f8);
      FUN_00c1a960(auStack_3f8);
    }
  }
  else {
    lVar1 = lRam00000000033d96b0 + 0x10;
    lStack_568 = lVar1;
    FUN_00123650(&lStack_568,&uStack_488,0x40);
    uStack_418 = 0;
    uStack_410 = 0;
    uStack_428 = 0;
    uStack_420 = 0;
    uStack_438 = 0;
    uStack_430 = 0;
    uStack_448 = 0;
    uStack_440 = 0;
    uStack_458 = 0;
    uStack_450 = 0;
    uStack_468 = 0;
    uStack_460 = 0;
    uStack_478 = 0;
    uStack_470 = 0;
    uStack_488 = 0;
    uStack_480 = 0;
    lStack_568 = lVar1;
    memset(&uStack_488,0,0x80);
    FUN_00c291c0(lVar2,&lStack_568);
    uVar3 = 0;
    FUN_001232e0();
    if ((uVar3 & 1) == 0) {
      lVar2 = lVar4;
      FUN_0138b7e0();
      if (lVar2 != 0) {
        FUN_0138b6f0(lVar4,1);
        FUN_00c1b690(auStack_3f8);
        FUN_00c1ac10(auStack_3f8,lVar2,&lStack_568);
        FUN_00c1aef0(auStack_3f8);
        FUN_00c1af00(auStack_3f8);
        FUN_00c1a960(auStack_3f8);
      }
    }
    else {
      FUN_0138b6f0(lVar4,0);
    }
    FUN_001237f0(&lStack_568);
  }
  return;
}

