
uint FUN_00c24990(long param_1)

{
  undefined8 uVar1;
  uint uVar2;
  
  if (*(char *)(param_1 + 0x246f) == '\0') {
    uVar2 = 0;
  }
  else {
    uVar2 = (uint)(*(char *)(param_1 + 0x2471) != '\0');
  }
  uVar1 = *(undefined8 *)(param_1 + 0x20);
  FUN_00c2ce80(uVar1);
  return uVar2 & (uint)uVar1;
}

