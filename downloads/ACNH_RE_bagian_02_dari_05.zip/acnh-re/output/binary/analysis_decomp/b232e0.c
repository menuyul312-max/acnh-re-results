
void FUN_00c232e0(undefined8 param_1,ulong param_2,undefined4 param_3)

{
  undefined1 *puVar1;
  ulong uVar2;
  int iStack_9c;
  undefined1 auStack_98 [116];
  undefined4 uStack_24;
  
  uStack_24 = param_3;
  FUN_0176aad0();
  FUN_00c0da50(auStack_98);
  iStack_9c = 1;
  do {
    FUN_00c0dae0(auStack_98);
    FUN_00c0e090(auStack_98,&uStack_24,&iStack_9c);
    puVar1 = auStack_98;
    FUN_00c0dc50(puVar1);
    uVar2 = param_2;
    FUN_00c1a520(param_2,puVar1);
    if ((uVar2 & 1) != 0) {
      FUN_0176ac00(param_1,iStack_9c);
    }
    iStack_9c = iStack_9c + 1;
  } while (iStack_9c < 100);
  FUN_00c0dad0(auStack_98);
  return;
}

