
void FUN_00c2a650(uint *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c2a668. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)((ulong)*param_1 * 0x10 + 0x31cecd0))
            ((long)param_1 + (*(long *)((ulong)*param_1 * 0x10 + 0x31cecd8) >> 1));
  return;
}

