
void _INIT_2646(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654f70 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654fa8);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654f74 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654f78 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654f8c = 0xffff;
  uRam0000000003654f88 = 0xffffffff;
  uRam0000000003654f94 = 0;
  uRam0000000003654f90 = 0;
  uRam0000000003654f7c = (undefined4)uVar2;
  uRam0000000003654f80 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654f98 = uVar2;
  uRam0000000003654fa0 = 0;
  return;
}

