
undefined8 FUN_00c2f6b0(undefined8 param_1,uint param_2)

{
  int iVar1;
  
  FUN_00c2f1e0();
  iVar1 = (int)param_1;
  if ((param_2 & 1) == 0) {
    if (iVar1 == 0x107) {
      param_1 = 0x108;
    }
  }
  else if ((((0x2e < iVar1 - 0xdaU) ||
            ((1L << ((ulong)(iVar1 - 0xdaU) & 0x3f) & 0x40000000001fU) == 0)) && (1 < iVar1 - 0xa6U)
           ) && (iVar1 != 0)) {
    return 0x9f;
  }
  return param_1;
}

