
void FUN_00c26220(long param_1)

{
  FUN_00c2bcb0(*(undefined8 *)(param_1 + 0x20));
  return;
}

