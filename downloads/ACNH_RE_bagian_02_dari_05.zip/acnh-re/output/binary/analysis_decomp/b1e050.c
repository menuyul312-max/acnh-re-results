
void FUN_00c1e050(char *param_1)

{
  long lVar1;
  long lVar2;
  long lVar3;
  long lVar4;
  undefined4 *puVar5;
  char cVar6;
  short sVar7;
  short sVar8;
  char *pcVar9;
  undefined4 uVar10;
  long *plVar11;
  uint *puVar12;
  int iVar13;
  long lVar14;
  long lVar15;
  ulong uVar16;
  int iVar17;
  long lVar18;
  int iVar19;
  long *plVar20;
  short *psVar21;
  long lStack_e8;
  char *pcStack_e0;
  undefined4 uStack_d8;
  char acStack_d4 [40];
  uint uStack_ac;
  long *plStack_a8;
  int iStack_a0;
  long lStack_98;
  undefined *puStack_90;
  long lStack_88;
  char *pcStack_80;
  
  plVar20 = (long *)(param_1 + 0x10);
  (**(code **)(*plVar20 + 0x18))(plVar20);
  sVar7 = *psRam00000000033d14d0;
  lVar14 = 0;
  do {
    if (*(short *)(*(long *)(param_1 + 0x18) + lVar14 * 2) == sVar7) {
LAB_00c1e0e8:
      iVar19 = (int)lVar14 + 1;
      goto LAB_00c1e0ec;
    }
    lVar3 = *(long *)(param_1 + 0x18) + lVar14 * 2;
    if (*(short *)(lVar3 + 2) == sVar7) {
      lVar14 = lVar14 + 1;
      goto LAB_00c1e0e8;
    }
    if (*(short *)(lVar3 + 4) == sVar7) {
      lVar14 = lVar14 + 2;
      goto LAB_00c1e0e8;
    }
    uVar16 = lVar14 + 2;
    lVar14 = lVar14 + 3;
  } while (uVar16 >> 0x13 == 0);
  iVar19 = 1;
LAB_00c1e0ec:
  iStack_a0 = 0;
  lVar14 = lRam00000000033f4dc0 + 0x10;
  puStack_90 = &UNK_02af0de2;
  if (iVar19 != 0) {
    cVar6 = *pcRam00000000033d0660;
    lVar3 = lRam00000000033d0670 + 0x10;
    lVar1 = lRam00000000033d0680 + 0x10;
    lVar2 = lRam00000000033d0668 + 0x10;
    plStack_a8 = plVar20;
    lStack_98 = lVar14;
    do {
      FUN_00c1e5e0(&plStack_a8,param_1 + 0xa8);
      if (*(int *)(param_1 + 0xb8) < 1) {
        if (*psRam00000000033d14d0 != 0x4e) goto LAB_00c1e268;
LAB_00c1e1c0:
        if (param_1[8] == '\0') {
          uStack_ac = 0xffffffff;
          uStack_d8 = 0x20;
          lStack_e8 = lVar3;
          pcStack_e0 = acStack_d4;
          FUN_01a90780(&lStack_e8);
          *pcStack_e0 = cVar6;
          lStack_e8 = lVar1;
          (**(code **)(*(long *)(param_1 + 0xa8) + 0x18))(param_1 + 0xa8);
          lVar15 = *(long *)(param_1 + 0xb0);
          lVar18 = 0;
          do {
            if (*(short *)(lVar15 + lVar18 * 2) == sVar7) {
LAB_00c1e2a8:
              iVar17 = (int)lVar18;
joined_r0x00c1e2ac:
              if (0 < iVar17) {
                pcStack_80 = (char *)(lVar15 + 2);
                goto LAB_00c1e2d0;
              }
              break;
            }
            lVar4 = lVar15 + lVar18 * 2;
            if (*(short *)(lVar4 + 2) == sVar7) {
              lVar18 = lVar18 + 1;
              goto LAB_00c1e2a8;
            }
            if (*(short *)(lVar4 + 4) == sVar7) {
              iVar17 = (int)lVar18 + 2;
              goto joined_r0x00c1e2ac;
            }
            uVar16 = lVar18 + 2;
            lVar18 = lVar18 + 3;
          } while (uVar16 >> 0x13 == 0);
          pcStack_80 = *(char **)(lRam00000000033f4dc8 + 8);
LAB_00c1e2d0:
          lStack_88 = lVar14;
          (**(code **)(lStack_e8 + 0x18))(&lStack_e8);
          uVar10 = uStack_d8;
          pcVar9 = pcStack_e0;
          (**(code **)(lStack_88 + 0x18))(&lStack_88);
          FUN_01a95150(pcVar9,uVar10,pcStack_80,0xffffffff);
          puVar12 = &uStack_ac;
          thunk_FUN_01a92e60(puVar12,&lStack_e8,0xffffffff);
          if (((ulong)puVar12 & 1) == 0) {
            pcStack_80 = "A";
            lStack_88 = lVar2;
            (**(code **)(lStack_e8 + 0x18))(&lStack_e8);
            (**(code **)(lStack_e8 + 0x18))(&lStack_e8);
            pcVar9 = pcStack_e0;
            (**(code **)(lStack_88 + 0x18))(&lStack_88);
            if (pcVar9 == pcStack_80) {
LAB_00c1e420:
              lStack_88 = 0x31ce690;
              pcStack_80 = param_1;
              FUN_00da2ac0(*plRam00000000033d3e18,&lStack_88);
            }
            else {
              uVar16 = 0;
              do {
                if (pcStack_e0[uVar16] != pcStack_80[uVar16]) break;
                if (pcStack_e0[uVar16] == cVar6) goto LAB_00c1e420;
                if (pcStack_e0[uVar16 + 1] != pcStack_80[uVar16 + 1]) break;
                if (pcStack_e0[uVar16 + 1] == cVar6) goto LAB_00c1e420;
                if (pcStack_e0[uVar16 + 2] != pcStack_80[uVar16 + 2]) break;
                if (pcStack_e0[uVar16 + 2] == cVar6) goto LAB_00c1e420;
                uVar16 = uVar16 + 3;
              } while (uVar16 < 0x80001);
            }
          }
          else {
            puVar5 = (undefined4 *)(*plRam00000000033d3e18 + 0xa08) + (int)uStack_ac;
            if (0x11 < uStack_ac) {
              puVar5 = (undefined4 *)(*plRam00000000033d3e18 + 0xa08);
            }
            FUN_00c1e9d0(param_1,*puVar5);
          }
        }
      }
      else {
        if (**(short **)(param_1 + 0xb0) == 0x4e) goto LAB_00c1e1c0;
LAB_00c1e268:
        if (*(int *)(param_1 + 0xb8) < 1) {
          sVar8 = *psRam00000000033d14d0;
        }
        else {
          sVar8 = **(short **)(param_1 + 0xb0);
        }
        if (sVar8 == 0x50) {
          FUN_00c1e8b0(param_1);
        }
      }
      iVar17 = iStack_a0;
      plVar11 = plStack_a8;
      lVar15 = (long)iStack_a0;
      (**(code **)(*plStack_a8 + 0x18))(plStack_a8);
      lVar18 = 0;
      do {
        if (*(short *)(plVar11[1] + lVar18 * 2) == sVar7) goto LAB_00c1e4a0;
        lVar4 = plVar11[1] + lVar18 * 2;
        if (*(short *)(lVar4 + 2) == sVar7) {
          iVar13 = (int)lVar18 + 1;
          goto joined_r0x00c1e190;
        }
        if (*(short *)(lVar4 + 4) == sVar7) {
          iVar13 = (int)lVar18 + 2;
          goto joined_r0x00c1e190;
        }
        uVar16 = lVar18 + 2;
        lVar18 = lVar18 + 3;
      } while (uVar16 >> 0x13 == 0);
      lVar18 = 0;
LAB_00c1e4a0:
      iVar13 = (int)lVar18;
joined_r0x00c1e190:
      if ((-1 < iVar17) && (iVar17 <= iVar13)) {
        psVar21 = (short *)(plStack_a8[1] + lVar15 * 2);
        if (*psVar21 != sVar7) {
          do {
            (**(code **)(lStack_98 + 0x18))(&lStack_98);
            sVar8 = *psVar21;
            uVar16 = 0;
            do {
              if (*(short *)(puStack_90 + uVar16 * 2) == sVar7) break;
              if (*(short *)(puStack_90 + uVar16 * 2) == sVar8) goto LAB_00c1e548;
              if (*(short *)(puStack_90 + uVar16 * 2 + 2) == sVar7) break;
              if (*(short *)(puStack_90 + uVar16 * 2 + 2) == sVar8) goto LAB_00c1e548;
              if (*(short *)(puStack_90 + uVar16 * 2 + 4) == sVar7) break;
              if (*(short *)(puStack_90 + uVar16 * 2 + 4) == sVar8) goto LAB_00c1e548;
              uVar16 = uVar16 + 3;
            } while (uVar16 < 0x80001);
            lVar15 = lVar15 + 1;
            psVar21 = (short *)(plStack_a8[1] + lVar15 * 2);
          } while (*psVar21 != sVar7);
LAB_00c1e548:
          iVar17 = (int)lVar15;
        }
        iStack_a0 = iVar17 + 1;
      }
    } while ((plStack_a8 != plVar20) || (iStack_a0 != iVar19));
  }
  return;
}

