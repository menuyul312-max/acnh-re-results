
void FUN_00c29bc0(long param_1)

{
  FUN_01750570(param_1 + 0x168,0);
  *(undefined1 *)(param_1 + 0x1a0) = 0;
  return;
}

