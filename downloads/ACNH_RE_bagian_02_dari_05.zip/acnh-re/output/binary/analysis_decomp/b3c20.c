
void FUN_001b3c20(long param_1)

{
  *(undefined8 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x728) = 0;
  *(undefined8 *)(param_1 + 0x73c) = 0;
  *(undefined4 *)(param_1 + 0xe50) = 0;
  *(undefined1 *)(param_1 + 0xe58) = 0;
  return;
}

