
void FUN_00c2ce80(long param_1)

{
  FUN_01385bd0(**(undefined8 **)(param_1 + 0x18));
  return;
}

