
void _INIT_2644(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654ee0 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654f18);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654ee4 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654ee8 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654efc = 0xffff;
  uRam0000000003654ef8 = 0xffffffff;
  uRam0000000003654f04 = 0;
  uRam0000000003654f00 = 0;
  uRam0000000003654eec = (undefined4)uVar2;
  uRam0000000003654ef0 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654f08 = uVar2;
  uRam0000000003654f10 = 0;
  return;
}

