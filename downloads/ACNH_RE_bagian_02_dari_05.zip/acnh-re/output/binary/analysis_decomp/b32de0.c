
void _INIT_2657(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655390 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36553c8);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655394 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655398 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036553ac = 0xffff;
  uRam00000000036553a8 = 0xffffffff;
  uRam00000000036553b4 = 0;
  uRam00000000036553b0 = 0;
  uRam000000000365539c = (undefined4)uVar2;
  uRam00000000036553a0 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036553b8 = uVar2;
  uRam00000000036553c0 = 0;
  lRam00000000036553d8 = lRam00000000033d0668 + 0x10;
  puRam00000000036553e0 = &UNK_02a913f9;
  lRam00000000036553e8 = lRam00000000036553d8;
  puRam00000000036553f0 = &UNK_02aaf160;
  lRam00000000036553f8 = lRam00000000036553d8;
  puRam0000000003655400 = &UNK_02a24204;
  return;
}

