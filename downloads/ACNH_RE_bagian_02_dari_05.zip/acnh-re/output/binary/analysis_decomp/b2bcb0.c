
void FUN_00c2bcb0(long param_1)

{
  long lVar1;
  ulong uVar2;
  ulong uVar3;
  
  lVar1 = param_1;
  FUN_016908b0();
  *(long *)(param_1 + 0x20) = lVar1;
  uVar3 = *(ulong *)(lVar1 + 0x98);
  uVar2 = uVar3;
  FUN_0177fc40(uVar3,lVar1);
  if ((uVar2 & 1) == 0) {
    FUN_0177fa50(uVar3,*(undefined8 *)(param_1 + 0x20));
  }
  **(undefined8 **)(param_1 + 8) = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)(*(long *)(param_1 + 0x10) + 0x2160) = *(undefined8 *)(param_1 + 0x20);
  **(undefined8 **)(param_1 + 0x18) = *(undefined8 *)(param_1 + 0x20);
  return;
}

