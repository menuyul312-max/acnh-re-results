
undefined4 FUN_00c263b0(long param_1)

{
  long lVar1;
  long lVar2;
  int iVar3;
  long lVar4;
  ulong uVar5;
  ulong uVar6;
  undefined1 *puVar7;
  undefined4 uVar8;
  undefined1 auStack_1368 [568];
  long alStack_1130 [28];
  undefined1 auStack_1050 [4096];
  
  lVar1 = lRam00000000033f4d40 + 0x10;
  alStack_1130[0] = lVar1;
  FUN_00123650(alStack_1130,auStack_1050,0x800);
  alStack_1130[0] = lVar1;
  memset(auStack_1050,0,0x1000);
  memset(auStack_1050,0,0x1000);
  uVar6 = param_1 + 0x2540;
  lVar2 = param_1 + 0x24d0;
  lVar1 = param_1 + 0x240;
  do {
    FUN_00c0dae0(uVar6);
    FUN_001232c0(alStack_1130);
    lVar4 = lVar2;
    FUN_00c0dc50(lVar2);
    FUN_00123860(alStack_1130,param_1 + 0x2478,lVar4,0);
    FUN_00bf0d80(auStack_1368);
    FUN_00bf0e40(auStack_1368,lVar1,alStack_1130);
    FUN_00bf0dc0(auStack_1368);
    FUN_00bef8a0(auStack_1368);
    FUN_00bef970(auStack_1368,lVar1);
    uVar5 = 0;
    FUN_00bef9d0();
    if ((uVar5 & 1) == 0) {
      FUN_00bef9e0(auStack_1368);
      uVar6 = 0;
      FUN_00befa00();
      if ((uVar6 & 1) != 0) {
        puVar7 = auStack_1368;
        FUN_00befa10(puVar7);
        iVar3 = (int)auStack_1368;
        FUN_00befa20();
        if (iVar3 < 0) {
          iVar3 = iVar3 + 1;
        }
        *(int *)(param_1 + 0x2418) = iVar3 >> 1;
        FUN_00122130(param_1 + 0x2420,puVar7);
      }
      uVar8 = 1;
LAB_00c26540:
      FUN_00bef8f0(auStack_1368);
      FUN_001237f0(alStack_1130);
      return uVar8;
    }
    FUN_00c26cc0(*(undefined8 *)(param_1 + 0x30),lVar1);
    uVar5 = uVar6;
    FUN_00c0e780();
    if ((uVar5 & 1) == 0) {
      uVar8 = 0;
      goto LAB_00c26540;
    }
    FUN_00c0db10(lVar2,uVar6);
    FUN_00c0db10(param_1 + 0x2608,lVar2);
    FUN_00bef8f0(auStack_1368);
  } while( true );
}

