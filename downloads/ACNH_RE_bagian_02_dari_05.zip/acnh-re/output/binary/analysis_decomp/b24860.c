
void FUN_00c24860(long param_1)

{
  FUN_00c2cff0(*(undefined8 *)(param_1 + 0x20));
  FUN_00bea6a0();
  return;
}

