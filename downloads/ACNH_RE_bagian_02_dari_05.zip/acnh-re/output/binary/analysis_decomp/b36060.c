
void FUN_00c36060(long param_1,long param_2)

{
  uint uVar1;
  undefined4 auStack_30 [2];
  long lStack_28;
  
  lStack_28 = param_2 + 4;
  auStack_30[0] = 10;
  FUN_010e4670(param_1,auStack_30);
  uVar1 = 2;
  if (*(byte *)(param_2 + 0x18) < 4) {
    uVar1 = (uint)*(byte *)(param_2 + 0x18);
  }
  *(uint *)(param_1 + 0xf8) = uVar1;
  return;
}

