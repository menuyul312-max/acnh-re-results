
long FUN_00c3cd40(undefined8 param_1)

{
  long *plVar1;
  long lVar2;
  
  plVar1 = plRam00000000033d3ef0;
  lVar2 = *plRam00000000033d3ef0;
  if (lVar2 == 0) {
    lVar2 = 0x828;
    FUN_01a67780(0x828,param_1,8);
    FUN_01a83c30(lVar2 + 0x808,param_1,3);
    *(long *)(lVar2 + 0x808) = lRam00000000033f5458 + 0x10;
    *plRam00000000033f5460 = lVar2 + 0x808;
    FUN_00c3cdd0(lVar2);
    *plVar1 = lVar2;
  }
  return lVar2;
}

