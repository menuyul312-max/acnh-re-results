
bool FUN_00c24610(long param_1)

{
  return *(int *)(param_1 + 0x48) == 8;
}

