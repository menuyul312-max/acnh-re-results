
void FUN_00c1d720(long *param_1)

{
  long lVar1;
  long lVar2;
  long lVar3;
  
  lVar1 = 600;
  _Znwm();
  FUN_00c04240();
  lVar2 = 0x4d0;
  _Znwm();
  FUN_00c00580();
  FUN_00121e30(param_1);
  lVar3 = 0x208;
  *param_1 = lRam00000000033f4d58 + 0x10;
  param_1[0xb] = lVar1;
  param_1[0xc] = lVar2;
  _Znwm();
  FUN_00bed850();
  param_1[0xd] = lVar3;
  *(undefined1 *)(param_1 + 0xe) = 0;
  lVar1 = lRam00000000033f4d98;
  *(undefined4 *)((long)param_1 + 0x74) = 100;
  *param_1 = lVar1 + 0x10;
  return;
}

