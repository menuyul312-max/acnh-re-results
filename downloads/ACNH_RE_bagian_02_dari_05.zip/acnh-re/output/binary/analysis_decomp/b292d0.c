
void FUN_00c292d0(long param_1,uint *param_2)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  long *plVar4;
  byte *pbVar5;
  undefined8 uVar6;
  long lVar7;
  long lStack_138;
  undefined *puStack_130;
  uint auStack_128 [2];
  long **pplStack_120;
  long lStack_118;
  undefined8 uStack_110;
  long lStack_108;
  undefined8 uStack_100;
  long lStack_f8;
  undefined8 uStack_f0;
  long lStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined1 auStack_d0 [16];
  long *plStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  long lStack_a8;
  undefined8 uStack_a0;
  undefined8 uStack_98;
  ulong uStack_90;
  long lStack_88;
  undefined *puStack_80;
  long lStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  
  auStack_128[0] = *param_2;
  FUN_00140080(&plStack_c0,auStack_128,1);
  plVar4 = plStack_c0;
  FUN_00128790();
  iVar1 = *piRam00000000033d6188;
  FUN_00140040(&plStack_c0);
  if ((int)plVar4 == iVar1) {
    FUN_00140080(&plStack_c0,param_2,0);
    plVar4 = plStack_c0;
    if (plStack_c0 != (long *)0x0) {
      if (((*pbRam00000000033d2630 & 1) == 0) &&
         (pbVar5 = pbRam00000000033d2630, __cxa_guard_acquire(), (int)pbVar5 != 0)) {
        *plRam00000000033d2638 = lRam00000000033d2640 + 0x10;
        __cxa_guard_release(pbRam00000000033d2630);
      }
      (**(code **)(*plVar4 + 0x20))(plVar4,plRam00000000033d2638);
      if (((ulong)plVar4 & 1) == 0) {
        uStack_b8._0_3_ = (uint3)(ushort)uStack_b8;
      }
    }
    if ((uStack_b8._2_1_ != '\0') && (plStack_c0 != (long *)0x0)) {
      FUN_00c295d0(param_1,plStack_c0 + 100);
      FUN_00140040(&plStack_c0);
      return;
    }
    FUN_00140040(&plStack_c0);
  }
  auStack_128[0] = *param_2;
  FUN_00140080(&plStack_c0,auStack_128,1);
  iVar3 = (int)plStack_c0;
  FUN_00128790();
  iVar1 = *piRam00000000033da5e0;
  FUN_00140040(&plStack_c0);
  if (iVar3 == iVar1) {
    FUN_01a89270(*puRam00000000033d08a8);
    uVar6 = 0x39;
    uStack_90 = 0xffff0039ffffffff;
  }
  else {
    auStack_128[0] = *param_2;
    FUN_00140080(&plStack_c0,auStack_128,1);
    iVar3 = (int)plStack_c0;
    FUN_00128790();
    iVar1 = *piRam00000000033f5110;
    FUN_00140040(&plStack_c0);
    if (iVar3 != iVar1) {
      return;
    }
    FUN_01a89270(*puRam00000000033d08a8);
    uVar6 = 0x3a;
    uStack_90 = 0xffff003affffffff;
  }
  uVar2 = uRam00000000033d0660;
  plStack_c0 = (long *)(lRam00000000033f5108 + 0x10);
  lVar7 = lRam00000000033d0668 + 0x10;
  uStack_68 = 0;
  puStack_80 = &UNK_02a88a06;
  uStack_98 = 0;
  uStack_90 = uStack_90 & 0xffffffffffff;
  uStack_b8 = lVar7;
  uStack_b0 = uRam00000000033d0660;
  lStack_a8 = lVar7;
  uStack_a0 = uRam00000000033d0660;
  lStack_88 = lVar7;
  lStack_78 = lVar7;
  uStack_70 = uRam00000000033d0660;
  FUN_01170f10(auStack_d0,0xffffffff,uVar6);
  auStack_128[0] = auStack_128[0] & 0xffff0000;
  uStack_110 = uVar2;
  uStack_100 = uVar2;
  uStack_f0 = uVar2;
  uStack_e0 = uVar2;
  uStack_d8 = 0;
  puStack_130 = &UNK_02a7bae5;
  lStack_138 = lVar7;
  pplStack_120 = &plStack_c0;
  lStack_118 = lVar7;
  lStack_108 = lVar7;
  lStack_f8 = lVar7;
  lStack_e8 = lVar7;
  FUN_01a904f0(&lStack_e8,&lStack_138);
  FUN_01a904f0(&lStack_118,auStack_d0);
  uStack_d8 = 0;
  FUN_01750020(param_1 + 0x168,auStack_128);
  *(undefined1 *)(param_1 + 0x1a0) = 1;
  return;
}

