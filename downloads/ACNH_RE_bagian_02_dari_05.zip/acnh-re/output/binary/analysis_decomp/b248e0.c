
long FUN_00c248e0(long param_1)

{
  return param_1 + 0x24d0;
}

