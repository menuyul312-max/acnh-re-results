
void FUN_00c2ea30(long param_1)

{
  if (param_1 != 0) {
    FUN_012559a0();
    return;
  }
  return;
}

