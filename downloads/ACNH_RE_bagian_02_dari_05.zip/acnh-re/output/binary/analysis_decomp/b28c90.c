
void FUN_00c28c90(long *param_1)

{
  *param_1 = lRam00000000033f50d0 + 0x10;
  FUN_00c127d0(*puRam00000000033d0f28);
  FUN_00c24ab0();
  param_1[2] = 0;
  if ((undefined8 *)param_1[3] != (undefined8 *)0x0) {
    *(undefined8 *)param_1[3] = 0;
    param_1[3] = 0;
  }
  FUN_0174fcf0(param_1 + 0x2d);
  FUN_00c19140(param_1);
  return;
}

