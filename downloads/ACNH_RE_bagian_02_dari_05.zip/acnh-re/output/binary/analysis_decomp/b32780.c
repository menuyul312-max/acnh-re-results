
void _INIT_2656(void)

{
  int iVar1;
  char cVar2;
  char cVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  ulong uVar7;
  long lVar8;
  long lStack_40;
  undefined *puStack_38;
  
  lStack_40 = CONCAT44(lStack_40._4_4_,2);
  uRam00000000036552c0 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655310);
  uVar5 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036552c4 = uVar5;
  uVar5 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam00000000036552c8 = uVar5;
  uVar6 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036552e4 = 0xffff;
  uRam00000000036552e0 = 0xffffffff;
  uRam00000000036552ec = 0;
  uRam00000000036552e8 = 0;
  uRam00000000036552cc = (undefined4)uVar6;
  uRam00000000036552d0 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036552f8 = 0;
  uRam00000000036552f0 = uVar6;
  FUN_010588a0(0x3655300,0x1c2b);
  FUN_010588a0(0x3655308,0x142e);
  lVar8 = lRam00000000033d0668 + 0x10;
  puRam0000000003655328 = &UNK_02a913f9;
  lRam0000000003655350 = lRam00000000033d0670 + 0x10;
  puRam0000000003655338 = &UNK_02aaf160;
  puRam0000000003655348 = &UNK_02a24204;
  puStack_38 = &UNK_02ac0a89;
  puRam0000000003655358 = (undefined *)0x3655364;
  iRam0000000003655360 = 0x20;
  lRam0000000003655320 = lVar8;
  lRam0000000003655330 = lVar8;
  lRam0000000003655340 = lVar8;
  lStack_40 = lVar8;
  FUN_01a90780(0x3655350);
  puVar4 = puRam0000000003655358;
  lRam0000000003655350 = lRam00000000033d0678 + 0x10;
  if (puRam0000000003655358 != &UNK_02ac0a89) {
    cVar2 = *pcRam00000000033d0660;
    uVar7 = 0;
    cVar3 = UNK_02ac0a89;
    while (cVar3 != cVar2) {
      if (uVar7 >> 0x13 != 0) {
        uVar7 = 0;
        break;
      }
      if ((&UNK_02ac0a8a)[uVar7] == cVar2) {
        uVar7 = uVar7 + 1;
        break;
      }
      cVar3 = (&UNK_02ac0a8b)[uVar7];
      uVar7 = uVar7 + 2;
    }
    iVar1 = (int)uVar7;
    if (iRam0000000003655360 <= (int)uVar7) {
      iVar1 = iRam0000000003655360 + -1;
    }
    memcpy(puRam0000000003655358,&UNK_02ac0a89,(long)iVar1);
    puVar4[iVar1] = cVar2;
    lVar8 = lStack_40;
  }
  lRam0000000003655350 = lRam00000000033d0680 + 0x10;
  (**(code **)(lVar8 + 0x18))(&lStack_40);
  FUN_00101bf0(puStack_38,0);
  uRam0000000003655388 = (int)puStack_38;
  uRam00000000036552d4 = 0x200000003;
  return;
}

