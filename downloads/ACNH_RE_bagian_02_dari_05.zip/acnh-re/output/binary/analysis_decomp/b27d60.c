
long FUN_00c27d60(long param_1)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  undefined4 uVar6;
  
  iVar2 = (int)*(undefined8 *)(param_1 + 0x208);
  FUN_00c24b40();
  FUN_00be6ae0();
  if ((iVar2 == 1) || (*(char *)(param_1 + 0x2191) != '\0')) {
    *(undefined1 *)(param_1 + 0x2193) = 0;
    FUN_00c2dec0(param_1 + 0x2170);
    uVar5 = param_1 + 0x1488;
    *(undefined4 *)(param_1 + 0x2184) = 0;
    uVar3 = param_1 + 0x1af8;
    while ((uVar4 = uVar5, FUN_00be56b0(), (uVar4 & 1) == 0 ||
           (uVar4 = uVar3, FUN_00be56b0(), (uVar4 & 1) == 0))) {
      FUN_00be5690(uVar5,0);
      FUN_00be5690(uVar3,0);
      uVar4 = uVar5;
      FUN_00be56b0();
      if (((uVar4 & 1) != 0) && (uVar4 = uVar3, FUN_00be56b0(), (uVar4 & 1) != 0)) {
        uVar4 = uVar5;
        FUN_00be5810(uVar5);
        FUN_00c2df30(0x3f800000,param_1 + 0x2170,uVar4);
      }
    }
    return 1;
  }
  if ((iVar2 == 0) && (*(char *)(param_1 + 0x2192) == '\0')) {
    *(char *)(param_1 + 0x2193) = *(char *)(param_1 + 0x2190);
    if (*(char *)(param_1 + 0x2190) != '\0') {
      uVar6 = 1;
      *(undefined4 *)(param_1 + 0x2184) = 0;
      goto LAB_00c27eb4;
    }
  }
  else {
    *(undefined1 *)(param_1 + 0x2193) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x2184);
  if (0 < (int)uVar1) {
    uVar1 = uVar1 - 2;
    *(uint *)(param_1 + 0x2184) = uVar1 & ((int)uVar1 >> 0x1f ^ 0xffffffffU);
    return 0;
  }
  uVar6 = 0;
LAB_00c27eb4:
  uVar5 = param_1 + 0x1488;
  uVar3 = uVar5;
  FUN_00be56b0();
  if ((uVar3 & 1) != 0) {
    uVar3 = param_1 + 0x1af8;
    FUN_00be56b0();
    if ((uVar3 & 1) != 0) {
      param_1 = param_1 + 0x2170;
      FUN_00c2dee0(param_1,uVar6);
      return param_1;
    }
  }
  FUN_00be5690(uVar5,uVar6);
  uVar3 = param_1 + 0x1af8;
  FUN_00be5690(uVar3,uVar6);
  uVar4 = uVar5;
  FUN_00be56b0();
  if (((uVar4 & 1) != 0) && (FUN_00be56b0(), (uVar3 & 1) != 0)) {
    FUN_00be5810(uVar5);
    FUN_00c2df30(0x3f800000,param_1 + 0x2170,uVar5);
  }
  return 0;
}

