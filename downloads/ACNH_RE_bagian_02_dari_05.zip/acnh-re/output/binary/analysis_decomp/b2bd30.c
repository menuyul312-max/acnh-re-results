
void FUN_00c2bd30(long param_1)

{
  *(undefined1 *)(param_1 + 0x38) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0xffffffff00000000;
  *(undefined8 *)(param_1 + 0x30) = 0xffffffffffffffff;
  *(undefined4 *)(*(long *)(param_1 + 8) + 8) = 0;
  *(undefined4 *)(*(long *)(param_1 + 0x10) + 0x2168) = 0;
  *(undefined4 *)(*(long *)(param_1 + 0x18) + 8) = 0;
  return;
}

