
long * FUN_001b23c0(undefined8 param_1)

{
  long lVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  long *plVar4;
  
  puVar2 = puRam00000000033d1a40;
  plVar4 = (long *)*puRam00000000033d1a40;
  if (plVar4 == (long *)0x0) {
    plVar4 = (long *)0x1990;
    FUN_01a67780(0x1990,param_1,8);
    FUN_01a83c30(plVar4 + 0x32e,param_1,3);
    puVar3 = puRam00000000033d4af0;
    lVar1 = lRam00000000033d4af8 + 0x10;
    plVar4[0x32e] = lRam00000000033d4ae8 + 0x10;
    *puVar3 = plVar4 + 0x32e;
    *plVar4 = lVar1;
    memset(plVar4 + 1,0,0x1920);
    FUN_01a68060(plVar4 + 1,400,plVar4 + 3);
    plVar4[0x194] = 0;
    plVar4[0x193] = 0;
    FUN_01a68060(plVar4 + 0x193,400,plVar4 + 0x195);
    *(undefined1 *)(plVar4 + 0x325) = 0;
    FUN_01aa2460(plVar4 + 0x326);
    *puVar2 = plVar4;
  }
  return plVar4;
}

