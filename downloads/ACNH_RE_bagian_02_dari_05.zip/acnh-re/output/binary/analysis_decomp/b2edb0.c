
uint FUN_00c2edb0(long param_1,undefined8 param_2)

{
  long lVar1;
  uint uVar2;
  long alStack_560 [28];
  undefined8 uStack_480;
  undefined8 uStack_478;
  undefined8 uStack_470;
  undefined8 uStack_468;
  undefined8 uStack_460;
  undefined8 uStack_458;
  undefined8 uStack_450;
  undefined8 uStack_448;
  undefined8 uStack_440;
  undefined8 uStack_438;
  undefined8 uStack_430;
  undefined8 uStack_428;
  undefined8 uStack_420;
  undefined8 uStack_418;
  undefined8 uStack_410;
  undefined8 uStack_408;
  undefined1 auStack_400 [976];
  undefined1 *puVar3;
  
  FUN_00c31070(auStack_400,param_2,uRam00000000033d1570);
  lVar1 = lRam00000000033d96b0 + 0x10;
  alStack_560[0] = lVar1;
  FUN_00123650(alStack_560,&uStack_480,0x40);
  uStack_410 = 0;
  uStack_408 = 0;
  uStack_420 = 0;
  uStack_418 = 0;
  uStack_430 = 0;
  uStack_428 = 0;
  uStack_440 = 0;
  uStack_438 = 0;
  uStack_450 = 0;
  uStack_448 = 0;
  uStack_460 = 0;
  uStack_458 = 0;
  uStack_470 = 0;
  uStack_468 = 0;
  uStack_480 = 0;
  uStack_478 = 0;
  alStack_560[0] = lVar1;
  memset(&uStack_480,0,0x80);
  FUN_00123cc0(alStack_560,param_1 + 8);
  puVar3 = auStack_400;
  FUN_00c31890(puVar3);
  uVar2 = (uint)puVar3;
  FUN_00c2e5a0();
  FUN_001237f0(alStack_560);
  FUN_00c314b0(auStack_400);
  return uVar2 & 1;
}

