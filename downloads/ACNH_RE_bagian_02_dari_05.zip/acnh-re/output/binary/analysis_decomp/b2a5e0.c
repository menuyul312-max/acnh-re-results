
void FUN_00c2a5e0(undefined8 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  uVar1 = *param_2;
  *(undefined4 *)param_1 = 1;
  *(undefined4 *)((long)param_1 + 4) = uVar1;
  return;
}

