
uint FUN_00c245b0(long param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x48);
  param_1 = param_1 + 0x2540;
  FUN_00c0e780(param_1);
  return (uint)(iVar1 == 0) & ((uint)param_1 ^ 1);
}

