
void FUN_00c2d550(undefined8 *param_1)

{
  *(undefined4 *)(param_1 + 1) = 1;
  FUN_01385c30(*param_1);
  return;
}

