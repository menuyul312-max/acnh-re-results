
void FUN_00c24c30(long param_1)

{
  FUN_00c27b90(*(undefined8 *)(param_1 + 0x28));
  return;
}

