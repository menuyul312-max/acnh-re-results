
void FUN_00c2a630(undefined4 *param_1)

{
  long lVar1;
  
  lVar1 = lRam00000000033f4d60;
  *param_1 = 2;
  param_1[2] = *(undefined4 *)(lVar1 + 0x84);
  return;
}

