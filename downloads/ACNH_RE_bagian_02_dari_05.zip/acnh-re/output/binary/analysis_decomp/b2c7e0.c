
void FUN_00c2c7e0(long *param_1)

{
  long *plVar1;
  ulong uVar2;
  long lVar3;
  undefined1 auStack_38 [8];
  undefined1 auStack_30 [8];
  undefined1 auStack_28 [8];
  
  plVar1 = (long *)*param_1;
  FUN_00c24b00();
  FUN_00ea3fb0(auStack_28);
  if (plVar1 != (long *)0x0) {
    (**(code **)(*plVar1 + 0x10))(auStack_30,plVar1);
    uVar2 = 0;
    FUN_00ea4020();
    auStack_28[0] = auStack_30[0];
    if ((uVar2 & 1) == 0) {
      auStack_28[0] = 0xff;
    }
  }
  uVar2 = 0;
  FUN_00ea4020();
  if ((uVar2 & 1) == 0) {
    FUN_00f712f0(auStack_38);
    uVar2 = 0;
    FUN_00ea4020();
    auStack_28[0] = auStack_38[0];
    if ((uVar2 & 1) == 0) {
      auStack_28[0] = 0xff;
    }
  }
  lVar3 = param_1[4];
  uVar2 = 0;
  FUN_00ea4020();
  if ((uVar2 & 1) == 0) {
    auStack_28[0] = 0xff;
  }
  *(undefined1 *)(lVar3 + 0x1f8) = auStack_28[0];
  return;
}

