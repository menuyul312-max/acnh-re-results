
void FUN_00c24830(long param_1)

{
  FUN_00c2cff0(*(undefined8 *)(param_1 + 0x20));
  FUN_00bea560();
  *(undefined1 *)(param_1 + 0xac) = 1;
  return;
}

