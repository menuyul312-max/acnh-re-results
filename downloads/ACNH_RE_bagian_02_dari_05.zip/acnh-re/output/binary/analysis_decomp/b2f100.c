
void FUN_00c2f100(undefined8 param_1)

{
  long lVar1;
  long lVar2;
  long lStack_90;
  undefined *puStack_88;
  ushort uStack_80;
  undefined1 uStack_7e;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  long lStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  long lStack_50;
  undefined2 uStack_48;
  undefined1 uStack_46;
  long lStack_40;
  undefined2 uStack_38;
  undefined4 uStack_34;
  
  uStack_7e = 0;
  uStack_80 = 1;
  uStack_7c = 8;
  lVar1 = 8;
  uStack_68 = uRam00000000033d0660;
  uStack_60 = 0;
  lVar2 = lRam00000000033d0668 + 0x10;
  uStack_78 = 0;
  uStack_58 = 0;
  lStack_50 = 0;
  uStack_48 = 1;
  uStack_46 = 0;
  lStack_70 = lVar2;
  FUN_01a8a3b0();
  lStack_40 = lVar1 << 1;
  uStack_38 = 0x100;
  uStack_34 = 0;
  FUN_00bf4150();
  puStack_88 = &UNK_02a56a74;
  lStack_90 = lVar2;
  FUN_01a904f0(&lStack_70,&lStack_90);
  lVar2 = 8;
  uStack_78 = 0;
  lStack_50 = lVar1;
  FUN_01a8a3b0();
  lStack_40 = lVar2 << 1;
  uStack_80 = uStack_80 & 0xff00;
  FUN_022eab30(param_1,&uStack_80);
  return;
}

