
uint FUN_00c2e470(long param_1,long param_2)

{
  uint uVar1;
  long lVar2;
  long lVar3;
  undefined1 *puVar4;
  uint uVar6;
  short asStack_448 [2];
  short asStack_444 [2];
  undefined1 auStack_440 [520];
  undefined1 auStack_238 [520];
  undefined1 *puVar5;
  
  if (param_1 == param_2) {
LAB_00c2e564:
    uVar6 = 1;
  }
  else {
    lVar2 = param_1;
    FUN_001233a0();
    lVar3 = param_2;
    FUN_001233a0();
    if (lVar2 == lVar3) {
      lVar2 = param_1;
      FUN_001234a0();
      lVar3 = param_2;
      FUN_001234a0();
      if (lVar2 == lVar3) goto LAB_00c2e564;
    }
    FUN_00bedcd0(auStack_238,0);
    FUN_001204c0(auStack_238,param_1);
    FUN_00bedcd0(auStack_440,0);
    FUN_001204c0(auStack_440,param_2);
    puVar4 = auStack_238;
    asStack_444[0] = 0;
    asStack_448[0] = 0;
    FUN_00120570(puVar4,asStack_444);
    uVar6 = (uint)puVar4;
    puVar5 = auStack_440;
    FUN_00120570(puVar5,asStack_448);
    uVar1 = (uint)puVar5;
    while ((((ulong)puVar4 & 1) != 0 && (((ulong)puVar5 & 1) != 0))) {
      if (asStack_444[0] != asStack_448[0]) {
        uVar6 = 0;
        goto LAB_00c2e570;
      }
      puVar4 = auStack_238;
      FUN_00120570(puVar4,asStack_444);
      uVar6 = (uint)puVar4;
      puVar5 = auStack_440;
      FUN_00120570(puVar5,asStack_448);
      uVar1 = (uint)puVar5;
    }
    uVar6 = (uVar6 | uVar1) ^ 1;
LAB_00c2e570:
    FUN_001219a0(auStack_440);
    FUN_001219a0(auStack_238);
  }
  return uVar6 & 1;
}

