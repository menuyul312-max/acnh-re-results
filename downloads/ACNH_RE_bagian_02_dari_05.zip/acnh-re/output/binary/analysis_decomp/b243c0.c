
void FUN_00c243c0(long *param_1)

{
  long lVar1;
  
  lVar1 = param_1[7];
  if (lVar1 != 0) {
    FUN_00c2a5c0(lVar1);
    _ZdlPv(lVar1);
  }
  if ((long *)param_1[6] != (long *)0x0) {
    (**(code **)(*(long *)param_1[6] + 8))();
  }
  if ((long *)param_1[5] != (long *)0x0) {
    (**(code **)(*(long *)param_1[5] + 8))();
  }
  lVar1 = param_1[4];
  if (lVar1 != 0) {
    FUN_00c2bc60(lVar1);
    _ZdlPv(lVar1);
  }
  lVar1 = param_1[3];
  if (lVar1 != 0) {
    FUN_00bf2fa0(lVar1);
    _ZdlPv(lVar1);
  }
  if ((long *)param_1[2] != (long *)0x0) {
    (**(code **)(*(long *)param_1[2] + 0x10))();
  }
  if ((long *)param_1[1] != (long *)0x0) {
    (**(code **)(*(long *)param_1[1] + 8))();
  }
  lVar1 = *param_1;
  if (lVar1 != 0) {
    FUN_00c2aef0(lVar1);
    _ZdlPv(lVar1);
  }
  FUN_00c0dad0(param_1 + 0x4c1);
  FUN_00c0dad0(param_1 + 0x4a8);
  FUN_00c0dad0(param_1 + 0x49a);
  FUN_001220d0(param_1 + 0x484);
  FUN_001237f0(param_1 + 0x264);
  FUN_001237f0(param_1 + 0x48);
  FUN_00c2aa80(param_1 + 0x2e);
  FUN_00be60d0((long)param_1 + 0x8c);
  return;
}

