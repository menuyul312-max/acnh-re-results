
/* WARNING: Type propagation algorithm not settling */

undefined8 FUN_00c38550(long param_1,undefined4 *param_2,ulong param_3,uint param_4)

{
  int *piVar1;
  ushort uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint *puVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *puVar9;
  undefined2 uVar10;
  uint uVar11;
  ulong uVar12;
  int *piVar13;
  uint uVar14;
  undefined4 *puVar15;
  char *pcVar16;
  uint auStack_70 [3];
  uint uStack_64;
  
  puVar5 = puRam00000000033f5338;
  puVar4 = puRam00000000033f5320;
  uVar14 = 0;
  piVar1 = (int *)(param_1 + 8);
  piVar6 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
  pcVar16 = pcRam00000000033f5318;
  uStack_64 = param_4;
  if (0 < (int)*(uint *)(param_1 + 0x1c8)) goto LAB_00c385f8;
LAB_00c385b8:
  piVar6 = piVar1;
  FUN_01766670();
  if (piVar6 == (int *)0x0) goto LAB_00c385f8;
  FUN_01765e30();
  if ((uint)piVar6 <= uVar14) {
    return 0;
  }
  do {
    piVar6 = piVar1;
    FUN_00c38330(piVar1,uVar14);
    if (piVar6 != (int *)0x0) {
      piVar7 = piVar6;
      FUN_01765ea0();
      if ((*puVar5 <= (uint)piVar7) ||
         (uVar2 = *(ushort *)(*(long *)(puVar5 + 2) + (long)(int)(uint)piVar7 * 2),
         auStack_70[0] = (uint)uVar2, 0xc < uVar2)) {
        auStack_70[0] = 0;
      }
      if (auStack_70[0] == uStack_64) {
        if (*piVar6 != 0) {
          do {
            piVar7 = piVar6;
            if (*pcVar16 == '\0') {
              *pcVar16 = '\x01';
              *puVar4 = 0xffffffffffffffff;
              puVar4[1] = 0xffffffffffffffff;
              *(undefined4 *)(puVar4 + 2) = 0xffffffff;
              FUN_01765e80();
            }
            else {
              iVar3 = *(int *)(puVar4 + 1);
              if (-1 < iVar3) {
                if ((undefined2 *)((long)iVar3 + (long)piVar6) != (undefined2 *)0x0) {
                  uVar10 = *(undefined2 *)((long)iVar3 + (long)piVar6);
                  goto LAB_00c3871c;
                }
                break;
              }
              if (iVar3 != -1) break;
              FUN_01765e80();
            }
            pcVar16 = pcRam00000000033f5318;
            if ((piVar7 == (int *)0x0) ||
               (piVar8 = piVar7, FUN_01765e60(), pcVar16 = pcRam00000000033f5318,
               piVar8 == (int *)0x0)) break;
            FUN_01765e50();
            *(undefined4 *)(puVar4 + 1) = 0xfffffffe;
            pcVar16 = pcRam00000000033f5318;
            if ((uint)piVar7 == 0) break;
            uVar11 = 0;
            piVar13 = piVar8 + 1;
            while (piVar8[(ulong)uVar11 * 2] != -0x489482c9) {
              uVar11 = uVar11 + 1;
              piVar13 = piVar13 + 2;
              if ((uint)piVar7 <= uVar11) goto LAB_00c38718;
            }
            iVar3 = 0;
            if (*piVar13 != -1) {
              iVar3 = *piVar13;
            }
            *(int *)(puVar4 + 1) = iVar3;
            if (*piVar6 == 0) break;
          } while( true );
        }
LAB_00c38718:
        uVar10 = 0xfffe;
LAB_00c3871c:
        FUN_010588a0(auStack_70,uVar10);
        uVar12 = param_3;
        FUN_01058af0(param_3,auStack_70);
        if ((uVar12 & 1) != 0) {
          if (*piVar6 != 0) {
            while (piVar7 = piVar6, *pcVar16 == '\0') {
              *pcVar16 = '\x01';
              *puVar4 = 0xffffffffffffffff;
              puVar4[1] = 0xffffffffffffffff;
              *(undefined4 *)(puVar4 + 2) = 0xffffffff;
              FUN_01765e80();
              if (piVar7 == (int *)0x0) goto LAB_00c387f8;
LAB_00c38760:
              piVar8 = piVar7;
              FUN_01765e60();
              pcVar16 = pcRam00000000033f5318;
              if (piVar8 == (int *)0x0) {
                puVar9 = (undefined4 *)0x0;
                FUN_00981a00();
                goto joined_r0x00c385e4;
              }
              FUN_01765e50();
              *(undefined4 *)((long)puVar4 + 0xc) = 0xfffffffe;
              pcVar16 = pcRam00000000033f5318;
              if ((uint)piVar7 == 0) goto LAB_00c387f8;
              uVar12 = 0;
              piVar13 = piVar8 + 1;
              while (piVar8[uVar12 * 2] != -0x2112f64) {
                uVar11 = (int)uVar12 + 1;
                uVar12 = (ulong)uVar11;
                piVar13 = piVar13 + 2;
                if ((uint)piVar7 <= uVar11) goto LAB_00c38840;
              }
              iVar3 = 0;
              if (*piVar13 != -1) {
                iVar3 = *piVar13;
              }
              *(int *)((long)puVar4 + 0xc) = iVar3;
              if (*piVar6 == 0) goto LAB_00c38840;
            }
            iVar3 = *(int *)((long)puVar4 + 0xc);
            if (iVar3 < 0) {
              if (iVar3 == -1) {
                FUN_01765e80();
                if (piVar7 != (int *)0x0) goto LAB_00c38760;
LAB_00c387f8:
                pcVar16 = pcRam00000000033f5318;
                puVar15 = (undefined4 *)0x0;
                puVar9 = (undefined4 *)0x0;
                FUN_00981a00();
                goto joined_r0x00c3880c;
              }
            }
            else if ((ushort *)((long)iVar3 + (long)piVar6) != (ushort *)0x0) {
              puVar15 = (undefined4 *)(ulong)*(ushort *)((long)iVar3 + (long)piVar6);
              puVar9 = puVar15;
              FUN_00981a00();
              goto joined_r0x00c3880c;
            }
          }
LAB_00c38840:
          puVar9 = (undefined4 *)0x0;
          FUN_00981a00();
joined_r0x00c385e4:
          puVar15 = (undefined4 *)0x0;
joined_r0x00c3880c:
          if (((ulong)puVar9 & 1) != 0) {
            FUN_00981a80();
            *param_2 = *puVar15;
            param_2[1] = puVar15[1];
            param_2[2] = puVar15[2];
            FUN_00c393a0(piVar6);
            FUN_01a90820(param_2 + 4,&UNK_02a3e896,piVar6);
            return 1;
          }
        }
      }
    }
    uVar14 = uVar14 + 1;
    piVar6 = (int *)(ulong)*(uint *)(param_1 + 0x1c8);
    if ((int)*(uint *)(param_1 + 0x1c8) < 1) goto LAB_00c385b8;
LAB_00c385f8:
    if ((uint)piVar6 <= uVar14) {
      return 0;
    }
  } while( true );
}

