
undefined1 FUN_00c27b90(long param_1)

{
  return *(undefined1 *)(param_1 + 0x2193);
}

