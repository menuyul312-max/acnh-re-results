
void _INIT_2659(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655850 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3655888);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003655854 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655858 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000365586c = 0xffff;
  uRam0000000003655868 = 0xffffffff;
  uRam0000000003655874 = 0;
  uRam0000000003655870 = 0;
  uRam000000000365585c = (undefined4)uVar2;
  uRam0000000003655860 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655878 = uVar2;
  uRam0000000003655880 = 0;
  return;
}

