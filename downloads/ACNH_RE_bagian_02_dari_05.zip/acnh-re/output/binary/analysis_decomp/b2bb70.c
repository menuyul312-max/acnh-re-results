
void FUN_00c2bb70(undefined8 *param_1,undefined8 param_2,long param_3)

{
  long lVar1;
  undefined8 *puVar2;
  long *plVar3;
  
  *param_1 = param_2;
  puVar2 = (undefined8 *)0x10;
  _Znwm();
  *puVar2 = 0;
  *(undefined4 *)(puVar2 + 1) = 0;
  param_1[1] = puVar2;
  plVar3 = (long *)0x37c0;
  _Znwm();
  FUN_00bea0a0();
  lVar1 = lRam00000000033f51d0;
  plVar3[0x42b] = param_3;
  plVar3[0x42c] = 0;
  *(undefined4 *)(plVar3 + 0x42d) = 0;
  *plVar3 = lVar1 + 0x10;
  memset(plVar3 + 0x42e,0,0x1650);
  FUN_00c1b860(plVar3 + 0x42e);
  FUN_00c1b860(plVar3 + 0x4a5);
  FUN_00c1b860(plVar3 + 0x51c);
  FUN_00c1b860(plVar3 + 0x593);
  FUN_00c1b860(plVar3 + 0x60a);
  FUN_00c1b860(plVar3 + 0x681);
  puVar2 = (undefined8 *)0x10;
  param_1[2] = plVar3;
  _Znwm();
  *puVar2 = 0;
  *(undefined4 *)(puVar2 + 1) = 0;
  param_1[3] = puVar2;
  param_1[4] = 0;
  *(undefined1 *)(param_1 + 7) = 0;
  param_1[5] = 0xffffffff00000000;
  param_1[6] = 0xffffffffffffffff;
  return;
}

