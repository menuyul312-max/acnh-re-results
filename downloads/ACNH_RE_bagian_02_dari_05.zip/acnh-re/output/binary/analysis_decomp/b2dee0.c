
undefined8 FUN_00c2dee0(int *param_1,uint param_2)

{
  long lVar1;
  int iVar2;
  float fVar3;
  
  iVar2 = *param_1;
  if ((float)param_1[1] - (float)iVar2 < 0.0) {
    lVar1 = 0x10;
    if ((param_2 & 1) == 0) {
      lVar1 = 0xc;
    }
    fVar3 = *(float *)((long)param_1 + lVar1);
    *param_1 = 0;
    param_1[1] = (int)(((float)param_1[1] - (float)iVar2) + fVar3 * (float)param_1[2]);
    return 0;
  }
  return 1;
}

