
void FUN_00c28bc0(long *param_1)

{
  long lVar1;
  long lVar2;
  long lVar3;
  
  FUN_00c19120();
  *param_1 = lRam00000000033f50d0 + 0x10;
  FUN_00ea3fb0((long)param_1 + 0xc);
  lVar3 = lRam00000000033e1648;
  lVar2 = lRam00000000033d1478;
  lVar1 = lRam00000000033f50d8 + 0x10;
  param_1[4] = 0;
  param_1[5] = lVar1;
  param_1[0xd] = lVar3 + 0x10;
  lVar1 = lRam00000000033f50e0;
  lVar2 = lVar2 + 0x10;
  param_1[9] = lVar2;
  param_1[0x11] = lVar2;
  param_1[0x15] = lVar2;
  lVar2 = lRam00000000033f50e8;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[0x19] = lVar1 + 0x10;
  lVar1 = lRam00000000033f50f0;
  param_1[0x1d] = lVar2 + 0x10;
  param_1[0x21] = lVar1 + 0x10;
  param_1[0x25] = lRam00000000033f50f8 + 0x10;
  param_1[0x29] = lRam00000000033f5100 + 0x10;
  FUN_0174fcd0(param_1 + 0x2d);
  *(undefined2 *)(param_1 + 0x34) = 0;
  return;
}

