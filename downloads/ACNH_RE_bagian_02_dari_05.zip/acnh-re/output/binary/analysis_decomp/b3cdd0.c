
void FUN_00c3cdd0(long *param_1)

{
  long lVar1;
  long lVar2;
  int iVar3;
  undefined1 uVar4;
  long lVar5;
  long lVar6;
  long lVar7;
  undefined8 *puVar8;
  undefined1 *puVar9;
  undefined *puVar10;
  
  *param_1 = lRam00000000033f5468 + 0x10;
  FUN_01765fe0(param_1 + 1);
  lVar7 = lRam00000000033f5480;
  lVar6 = lRam00000000033f5478;
  lVar1 = lRam00000000033f5470;
  *(undefined4 *)(param_1 + 0x1a) = 0;
  lVar5 = lRam00000000033d4850;
  lVar2 = lRam00000000033d0670;
  param_1[1] = lVar1 + 0x10;
  param_1[0x1b] = 0;
  param_1[0x1c] = lVar6 + 0x10;
  param_1[0x20] = lVar7 + 0x10;
  param_1[0x24] = lVar5 + 0x10;
  param_1[0x28] = lVar2 + 0x10;
  param_1[0x29] = (long)param_1 + 0x154;
  *(undefined4 *)(param_1 + 0x2a) = 0x40;
  FUN_01a90780(param_1 + 0x28);
  puVar10 = (undefined *)param_1[0x29];
  lVar1 = lRam00000000033d17a0 + 0x10;
  param_1[0x28] = lVar1;
  if (puVar10 != &UNK_02ad4e28) {
    uVar4 = *puRam00000000033d0660;
    iVar3 = 0;
    if ((int)param_1[0x2a] < 1) {
      iVar3 = (int)param_1[0x2a] + -1;
    }
    memset(puVar10,0,(long)iVar3);
    puVar10[iVar3] = uVar4;
  }
  lVar6 = lRam00000000033d1298;
  *(undefined4 *)(param_1 + 0x37) = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x34] = 0;
  param_1[0x38] = 0;
  *(undefined4 *)(param_1 + 0x33) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x39) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x3a) = 0;
  param_1[0x3b] = 0;
  param_1[0x28] = lVar6 + 0x10;
  *puRam00000000033f5488 = 1;
  puVar8 = puRam00000000033f5498;
  *(undefined4 *)(puRam00000000033f5498 + 3) = 0xffffffff;
  puVar8[2] = 0xffffffffffffffff;
  lVar7 = lRam00000000033f5490;
  *puVar8 = 0xffffffffffffffff;
  puVar8[1] = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  param_1[1] = lVar7 + 0x10;
  lVar7 = lRam00000000033f54a0;
  param_1[0x3d] = 0;
  param_1[0x3e] = lVar7;
  *(undefined8 *)((long)param_1 + 0x1fd) = 0;
  param_1[0x3f] = 0;
  FUN_01765fe0(param_1 + 0x41);
  lVar7 = lRam00000000033f54a8;
  *(undefined4 *)(param_1 + 0x5a) = 0;
  param_1[0x5b] = 0;
  param_1[100] = lVar5 + 0x10;
  lVar5 = lRam00000000033f54b0;
  param_1[0x41] = lVar7 + 0x10;
  lVar7 = lRam00000000033f54b8;
  param_1[0x68] = lVar2 + 0x10;
  *(undefined4 *)(param_1 + 0x6a) = 0x40;
  param_1[0x60] = lVar7 + 0x10;
  param_1[0x5c] = lVar5 + 0x10;
  param_1[0x69] = (long)param_1 + 0x354;
  FUN_01a90780(param_1 + 0x68);
  puVar10 = (undefined *)param_1[0x69];
  param_1[0x68] = lVar1;
  if (puVar10 != &UNK_02ad4e28) {
    uVar4 = *puRam00000000033d0660;
    iVar3 = 0;
    if ((int)param_1[0x6a] < 1) {
      iVar3 = (int)param_1[0x6a] + -1;
    }
    memset(puVar10,0,(long)iVar3);
    puVar10[iVar3] = uVar4;
  }
  param_1[0x68] = lVar6 + 0x10;
  *(undefined4 *)(param_1 + 0x73) = 0xffffffff;
  param_1[0x78] = 0;
  *(undefined4 *)(param_1 + 0x77) = 0;
  param_1[0x76] = 0;
  param_1[0x75] = 0;
  param_1[0x74] = 0;
  *(undefined4 *)(param_1 + 0x79) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x7a) = 0;
  puVar9 = puRam00000000033f54c0;
  param_1[0x7b] = 0;
  puVar8 = puRam00000000033f54c8;
  *puVar9 = 1;
  puVar8[2] = 0xffffffffffffffff;
  puVar8[5] = 0xffffffffffffffff;
  puVar8[6] = 0xffffffffffffffff;
  puVar8[3] = 0xffffffffffffffff;
  puVar8[4] = 0xffffffffffffffff;
  lVar1 = lRam00000000033f54d0 + 0x10;
  *puVar8 = 0xffffffffffffffff;
  puVar8[1] = 0xffffffffffffffff;
  param_1[0x41] = lVar1;
  *(undefined4 *)(param_1 + 0x7c) = 0;
  lVar1 = lRam00000000033f54d8;
  param_1[0x7d] = 0;
  param_1[0x7e] = lVar1;
  *(undefined8 *)((long)param_1 + 0x3fd) = 0;
  param_1[0x7f] = 0;
  FUN_01765fe0(param_1 + 0x81);
  lVar1 = lRam00000000033f54e0;
  *(undefined4 *)(param_1 + 0x9a) = 0;
  param_1[0xa9] = (long)param_1 + 0x554;
  lVar2 = lRam00000000033f54e8;
  param_1[0x81] = lVar1 + 0x10;
  lVar6 = lRam00000000033f54f0;
  param_1[0x9b] = 0;
  param_1[0x9c] = lVar2 + 0x10;
  lVar1 = lRam00000000033d4850 + 0x10;
  param_1[0xa4] = lVar1;
  lVar5 = lRam00000000033d0670;
  param_1[0xa0] = lVar6 + 0x10;
  *(undefined4 *)(param_1 + 0xaa) = 0x40;
  param_1[0xa8] = lVar5 + 0x10;
  FUN_01a90780(param_1 + 0xa8);
  puVar10 = (undefined *)param_1[0xa9];
  lVar2 = lRam00000000033d17a0 + 0x10;
  param_1[0xa8] = lVar2;
  if (puVar10 != &UNK_02ad4e28) {
    uVar4 = *puRam00000000033d0660;
    iVar3 = 0;
    if ((int)param_1[0xaa] < 1) {
      iVar3 = (int)param_1[0xaa] + -1;
    }
    memset(puVar10,0,(long)iVar3);
    puVar10[iVar3] = uVar4;
  }
  lVar6 = lRam00000000033d1298;
  *(undefined4 *)(param_1 + 0xb3) = 0xffffffff;
  param_1[0xb8] = 0;
  *(undefined4 *)(param_1 + 0xb7) = 0;
  param_1[0xa8] = lVar6 + 0x10;
  param_1[0xb6] = 0;
  param_1[0xb5] = 0;
  param_1[0xb4] = 0;
  *(undefined4 *)(param_1 + 0xb9) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xba) = 0;
  puVar9 = puRam00000000033f54f8;
  param_1[0xbb] = 0;
  *puVar9 = 1;
  puVar8 = puRam00000000033f5508;
  *(undefined4 *)(puRam00000000033f5508 + 2) = 0xffffffff;
  lVar7 = lRam00000000033f5500;
  *puVar8 = 0xffffffffffffffff;
  puVar8[1] = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 0xbc) = 0;
  param_1[0x81] = lVar7 + 0x10;
  lVar7 = lRam00000000033f5510;
  param_1[0xbd] = 0;
  param_1[0xbe] = lVar7;
  *(undefined8 *)((long)param_1 + 0x5fd) = 0;
  param_1[0xbf] = 0;
  FUN_01765fe0(param_1 + 0xc1);
  lVar7 = lRam00000000033f5518;
  *(undefined4 *)(param_1 + 0xda) = 0;
  param_1[0xdb] = 0;
  param_1[0xe4] = lVar1;
  lVar1 = lRam00000000033f5520;
  param_1[0xc1] = lVar7 + 0x10;
  lVar7 = lRam00000000033f5528;
  param_1[0xe8] = lVar5 + 0x10;
  *(undefined4 *)(param_1 + 0xea) = 0x40;
  param_1[0xe0] = lVar7 + 0x10;
  param_1[0xdc] = lVar1 + 0x10;
  param_1[0xe9] = (long)param_1 + 0x754;
  FUN_01a90780(param_1 + 0xe8);
  puVar10 = (undefined *)param_1[0xe9];
  param_1[0xe8] = lVar2;
  if (puVar10 != &UNK_02ad4e28) {
    uVar4 = *puRam00000000033d0660;
    iVar3 = 0;
    if ((int)param_1[0xea] < 1) {
      iVar3 = (int)param_1[0xea] + -1;
    }
    memset(puVar10,0,(long)iVar3);
    puVar10[iVar3] = uVar4;
  }
  param_1[0xe8] = lVar6 + 0x10;
  *(undefined4 *)(param_1 + 0xf3) = 0xffffffff;
  param_1[0xf8] = 0;
  *(undefined4 *)(param_1 + 0xf7) = 0;
  param_1[0xf6] = 0;
  param_1[0xf5] = 0;
  param_1[0xf4] = 0;
  *(undefined4 *)(param_1 + 0xf9) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xfa) = 0;
  param_1[0xfb] = 0;
  *puRam00000000033f5530 = 1;
  puVar8 = puRam00000000033f5538;
  *puRam00000000033f5538 = 0xffffffffffffffff;
  puVar8[1] = 0xffffffffffffffff;
  puVar8[2] = 0xffffffffffffffff;
  param_1[0xc1] = lRam00000000033f5540 + 0x10;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  param_1[0xfd] = 0;
  param_1[0xfe] = lRam00000000033f5548;
  *(undefined8 *)((long)param_1 + 0x7fd) = 0;
  param_1[0xff] = 0;
  return;
}

