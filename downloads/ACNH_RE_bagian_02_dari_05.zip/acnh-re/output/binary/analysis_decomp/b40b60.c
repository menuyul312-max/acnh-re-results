
void FUN_00c40b60(long *param_1)

{
  long lVar1;
  int iVar2;
  char cVar3;
  char cVar4;
  ulong uVar5;
  undefined *puVar6;
  long *plVar7;
  
  lVar1 = lRam00000000033d0670 + 0x10;
  *param_1 = lVar1;
  param_1[1] = (long)param_1 + 0x14;
  *(undefined4 *)(param_1 + 2) = 0x20;
  FUN_01a90780();
  puVar6 = (undefined *)param_1[1];
  *param_1 = lRam00000000033d0678 + 0x10;
  if (puVar6 != &UNK_02a3f278) {
    cVar3 = *pcRam00000000033d0660;
    uVar5 = 0;
    cVar4 = UNK_02a3f278;
    while (cVar4 != cVar3) {
      if (uVar5 >> 0x13 != 0) {
        uVar5 = 0;
        break;
      }
      if ((&UNK_02a3f279)[uVar5] == cVar3) {
        uVar5 = uVar5 + 1;
        break;
      }
      cVar4 = (&UNK_02a3f27a)[uVar5];
      uVar5 = uVar5 + 2;
    }
    iVar2 = (int)uVar5;
    if ((int)param_1[2] <= (int)uVar5) {
      iVar2 = (int)param_1[2] + -1;
    }
    memcpy(puVar6,&UNK_02a3f278,(long)iVar2);
    puVar6[iVar2] = cVar3;
  }
  *param_1 = lRam00000000033d0680 + 0x10;
  plVar7 = param_1 + 7;
  *plVar7 = lVar1;
  param_1[8] = (long)param_1 + 0x4c;
  *(undefined4 *)(param_1 + 9) = 8;
  FUN_01a90780(plVar7);
  *plVar7 = lRam00000000033d9510 + 0x10;
  puVar6 = (undefined *)param_1[8];
  if (puVar6 != &UNK_02a3f278) {
    cVar3 = *pcRam00000000033d0660;
    uVar5 = 0;
    cVar4 = UNK_02a3f278;
    while (cVar4 != cVar3) {
      if (uVar5 >> 0x13 != 0) {
        uVar5 = 0;
        break;
      }
      if ((&UNK_02a3f279)[uVar5] == cVar3) {
        uVar5 = uVar5 + 1;
        break;
      }
      cVar4 = (&UNK_02a3f27a)[uVar5];
      uVar5 = uVar5 + 2;
    }
    iVar2 = (int)uVar5;
    if ((int)param_1[9] <= (int)uVar5) {
      iVar2 = (int)param_1[9] + -1;
    }
    memcpy(puVar6,&UNK_02a3f278,(long)iVar2);
    puVar6[iVar2] = cVar3;
  }
  *plVar7 = lRam00000000033d25e8 + 0x10;
  return;
}

