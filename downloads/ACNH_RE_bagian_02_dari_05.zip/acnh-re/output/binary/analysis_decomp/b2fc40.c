
void FUN_00c2fc40(undefined4 *param_1)

{
  undefined1 uVar1;
  undefined1 *puVar2;
  
  FUN_022ed1d0(param_1 + 2);
  *param_1 = 0;
  FUN_022ed6c0(param_1 + 2);
  *(undefined8 *)(param_1 + 0x10) = 0;
  puVar2 = puRam00000000033d0660;
  param_1[0x12] = 0;
  uVar1 = *puVar2;
  **(undefined1 **)(param_1 + 0x16) = uVar1;
  **(undefined1 **)(param_1 + 0x2c) = uVar1;
  return;
}

