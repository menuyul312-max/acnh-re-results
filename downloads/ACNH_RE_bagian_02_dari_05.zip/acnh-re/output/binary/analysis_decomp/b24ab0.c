
void FUN_00c24ab0(long param_1,long param_2)

{
  if ((*(long *)(param_1 + 0xb8) != 0) && ((param_2 == 0 || (*(long *)(param_1 + 0xb8) == param_2)))
     ) {
    *(undefined8 *)(param_1 + 0xb8) = 0;
  }
  if ((*(long *)(param_1 + 0xc0) != 0) && ((param_2 == 0 || (*(long *)(param_1 + 0xc0) == param_2)))
     ) {
    *(undefined8 *)(param_1 + 0xc0) = 0;
    return;
  }
  return;
}

