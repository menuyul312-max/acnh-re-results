
undefined8 FUN_00c24b20(long param_1)

{
  return *(undefined8 *)(param_1 + 0xc0);
}

