
void FUN_00c3a0c0(long *param_1)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = lRam00000000033f52f8 + 0x10;
  puVar2 = puRam00000000033f5338;
  if (*(long *)(puRam00000000033f5338 + 2) != 0) {
    _ZdaPv();
    *(undefined8 *)(puVar2 + 2) = 0;
    *puVar2 = 0;
  }
  *puRam00000000033f5318 = 1;
  puVar1 = puRam00000000033f5320;
  *puRam00000000033f5320 = 0xffffffffffffffff;
  puVar1[1] = 0xffffffffffffffff;
  *(undefined4 *)(puVar1 + 2) = 0xffffffff;
  param_1[0x16] = 0;
  if (param_1[0x1a] != 0) {
    _ZdaPv();
    param_1[0x1a] = 0;
    *(undefined4 *)(param_1 + 0x19) = 0;
  }
  if (param_1[0x37] != 0) {
    _ZdaPv();
    param_1[0x37] = 0;
    *(undefined4 *)(param_1 + 0x36) = 0;
  }
  *(undefined4 *)(param_1 + 0x38) = 0xffffffff;
  if (param_1[0x3a] != 0) {
    _ZdaPv();
    param_1[0x3a] = 0;
    *(undefined4 *)(param_1 + 0x39) = 0;
  }
  FUN_017660f0(param_1);
  return;
}

