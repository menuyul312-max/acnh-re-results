
void FUN_00c2a9e0(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c2a9e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x38))();
  return;
}

