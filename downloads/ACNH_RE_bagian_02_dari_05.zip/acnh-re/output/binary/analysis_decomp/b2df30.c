
void FUN_00c2df30(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = param_1;
  return;
}

