
void FUN_001b2560(long param_1)

{
  *(undefined1 *)(param_1 + 0x1928) = 0;
  return;
}

