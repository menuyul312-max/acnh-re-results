
void FUN_00c1e5a0(undefined4 *param_1,undefined2 param_2)

{
  *param_1 = 0x28000e;
  *(undefined2 *)((long)param_1 + 6) = 4;
  *(undefined2 *)(param_1 + 1) = param_2;
  param_1[2] = 0xcd00;
  param_1[3] = 0;
  return;
}

