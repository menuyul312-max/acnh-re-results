
void FUN_00c2c890(ulong *param_1)

{
  ulong uVar1;
  long *plVar2;
  
  uVar1 = *param_1;
  FUN_00c24b40(uVar1);
  FUN_00be6720();
  if ((param_1[4] != 0) && (plVar2 = *(long **)(param_1[4] + 0x210), plVar2 != (long *)0x0)) {
                    /* WARNING: Could not recover jumptable at 0x00c2c8d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 0x200))(plVar2,uVar1 & 0xffffffff);
    return;
  }
  return;
}

