
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_00c3f5e0(long param_1,undefined4 *param_2,uint param_3,uint param_4)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  ushort uVar7;
  uint uVar8;
  float *pfVar9;
  char *pcVar10;
  char *pcVar11;
  uint *puVar12;
  uint *puVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  
  uVar8 = (param_4 & 0xffff) - (uint)*(ushort *)(param_1 + 0x400);
  if ((uVar8 < *(uint *)(param_1 + 0x3e0)) &&
     (puVar13 = *(uint **)(*(long *)(param_1 + 1000) + (long)(int)uVar8 * 8), puVar13 != (uint *)0x0
     )) {
    puVar3 = puVar13;
    FUN_01765ea0();
    if ((*puRam00000000033f5558 <= (uint)puVar3) ||
       (uVar7 = *(ushort *)(*(long *)(puRam00000000033f5558 + 2) + (long)(int)(uint)puVar3 * 2),
       uVar8 = (uint)uVar7, 0xc < uVar7)) {
      uVar8 = 0;
    }
    if (param_3 == uVar8) {
      puVar4 = puVar13;
      FUN_01765ea0();
      puVar3 = puRam00000000033f5550;
      if ((*puRam00000000033f5550 <= (uint)puVar4) ||
         (uVar7 = *(ushort *)(*(long *)(puRam00000000033f5550 + 2) + (long)(int)(uint)puVar4 * 2),
         2 < uVar7)) {
        uVar7 = 0;
      }
      if (param_3 - 3 < 3) {
        iVar2 = (int)*puRam00000000033d3ed0;
        FUN_00abb8f0();
        if (uVar7 != 0) {
          if (uVar7 == 1) {
            if (iVar2 != 0) {
              return 0;
            }
          }
          else {
            if (uVar7 != 2) {
              return 0;
            }
            if (iVar2 != 1) {
              return 0;
            }
          }
        }
      }
      puVar4 = puRam00000000033f54c8;
      pcVar10 = pcRam00000000033f54c0;
      if (*puVar13 == 0) {
        *param_2 = 0;
        param_2[1] = 0;
        param_2[2] = 0;
        uVar8 = *puVar13;
        pcVar10 = pcRam00000000033f54c0;
        puVar4 = puRam00000000033f54c8;
      }
      else {
        uVar14 = 0;
        do {
          puVar3 = puVar13;
          uVar15 = uVar14;
          if (*pcVar10 != '\0') {
            uVar8 = puVar4[2];
            if ((int)uVar8 < 0) {
              if ((uVar8 == 0xffffffff) && (FUN_01765e80(), puVar3 != (uint *)0x0))
              goto LAB_00c3f740;
              goto LAB_00c3f7cc;
            }
            if ((undefined4 *)((long)(int)uVar8 + (long)puVar13) == (undefined4 *)0x0) {
LAB_00c3f7e0:
              uVar1 = *puVar13;
            }
            else {
              uVar1 = *puVar13;
              uVar15 = *(undefined4 *)((long)(int)uVar8 + (long)puVar13);
            }
joined_r0x00c3f7d4:
            if (uVar1 != 0) {
              uVar14 = 0;
              goto LAB_00c3f7fc;
            }
            break;
          }
          *pcVar10 = '\x01';
          puVar4[10] = 0xffffffff;
          puVar4[0xb] = 0xffffffff;
          puVar4[0xc] = 0xffffffff;
          puVar4[0xd] = 0xffffffff;
          puVar4[0] = 0xffffffff;
          puVar4[1] = 0xffffffff;
          puVar4[6] = 0xffffffff;
          puVar4[7] = 0xffffffff;
          puVar4[8] = 0xffffffff;
          puVar4[9] = 0xffffffff;
          puVar4[2] = 0xffffffff;
          puVar4[3] = 0xffffffff;
          puVar4[4] = 0xffffffff;
          puVar4[5] = 0xffffffff;
          FUN_01765e80();
          if (puVar3 == (uint *)0x0) {
LAB_00c3f7cc:
            uVar1 = *puVar13;
            goto joined_r0x00c3f7d4;
          }
LAB_00c3f740:
          puVar5 = puVar3;
          FUN_01765e60();
          if (puVar5 == (uint *)0x0) goto LAB_00c3f7cc;
          FUN_01765e50();
          puVar4[2] = 0xfffffffe;
          if ((uint)puVar3 == 0) goto LAB_00c3f7cc;
          uVar8 = 0;
          puVar6 = puVar5 + 1;
          while (puVar5[(ulong)uVar8 * 2] != 0x2633f2c1) {
            uVar8 = uVar8 + 1;
            puVar6 = puVar6 + 2;
            if ((uint)puVar3 <= uVar8) goto LAB_00c3f7e0;
          }
          uVar8 = 0;
          if (*puVar6 != 0xffffffff) {
            uVar8 = *puVar6;
          }
          puVar4[2] = uVar8;
        } while (*puVar13 != 0);
LAB_00c3fa28:
        puVar3 = puRam00000000033f5550;
        *param_2 = uVar15;
        param_2[1] = uVar14;
        param_2[2] = 0;
        uVar8 = *puVar13;
        pcVar10 = pcRam00000000033f54c0;
        puVar4 = puRam00000000033f54c8;
      }
      goto joined_r0x00c400b8;
    }
  }
  return 0;
LAB_00c3f7fc:
  do {
    if (*pcVar10 != '\0') {
      uVar8 = puVar4[3];
      if ((int)uVar8 < 0) {
        if (uVar8 == 0xffffffff) goto LAB_00c3f82c;
LAB_00c3f9d4:
        uVar8 = *puVar13;
        puVar3 = puRam00000000033f5550;
      }
      else if ((undefined4 *)((long)(int)uVar8 + (long)puVar13) == (undefined4 *)0x0) {
LAB_00c3f8e4:
        uVar8 = *puVar13;
        puVar3 = puRam00000000033f5550;
      }
      else {
        uVar14 = *(undefined4 *)((long)(int)uVar8 + (long)puVar13);
        uVar8 = *puVar13;
        puVar3 = puRam00000000033f5550;
      }
      goto joined_r0x00c3f8e8;
    }
    *pcVar10 = '\x01';
    puVar4[10] = 0xffffffff;
    puVar4[0xb] = 0xffffffff;
    puVar4[0xc] = 0xffffffff;
    puVar4[0xd] = 0xffffffff;
    puVar4[0] = 0xffffffff;
    puVar4[1] = 0xffffffff;
    puVar4[6] = 0xffffffff;
    puVar4[7] = 0xffffffff;
    puVar4[8] = 0xffffffff;
    puVar4[9] = 0xffffffff;
    puVar4[2] = 0xffffffff;
    puVar4[3] = 0xffffffff;
    puVar4[4] = 0xffffffff;
    puVar4[5] = 0xffffffff;
LAB_00c3f82c:
    puVar3 = puVar13;
    FUN_01765e80();
    if ((puVar3 == (uint *)0x0) || (puVar5 = puVar3, FUN_01765e60(), puVar5 == (uint *)0x0))
    goto LAB_00c3f9d4;
    FUN_01765e50();
    puVar4[3] = 0xfffffffe;
    if ((uint)puVar3 == 0) goto LAB_00c3f9d4;
    uVar8 = 0;
    puVar6 = puVar5 + 1;
    while (puVar5[(ulong)uVar8 * 2] != 0x1b53db71) {
      uVar8 = uVar8 + 1;
      puVar6 = puVar6 + 2;
      if ((uint)puVar3 <= uVar8) goto LAB_00c3f8e4;
    }
    uVar8 = 0;
    if (*puVar6 != 0xffffffff) {
      uVar8 = *puVar6;
    }
    puVar4[3] = uVar8;
    puVar3 = puRam00000000033f5550;
  } while (*puVar13 != 0);
  *param_2 = uVar15;
  param_2[1] = 0;
  param_2[2] = 0;
  uVar8 = *puVar13;
  pcVar10 = pcRam00000000033f54c0;
  puVar4 = puRam00000000033f54c8;
joined_r0x00c400b8:
  do {
    pfVar9 = (float *)(ulong)uVar8;
    if (uVar8 == 0) goto LAB_00c3fb10;
    puVar5 = puVar13;
    if (*pcVar10 != '\0') {
      uVar8 = puVar4[5];
      if ((int)uVar8 < 0) {
        if (uVar8 == 0xffffffff) {
          FUN_01765e80();
          goto joined_r0x00c3fa78;
        }
LAB_00c3fb0c:
        pfVar9 = (float *)0x0;
      }
      else {
        pfVar9 = (float *)((long)(int)uVar8 + (long)puVar13);
        if (pfVar9 != (float *)0x0) {
          pfVar9 = (float *)(long)(*pfVar9 * _UNK_02ad6388);
        }
      }
      goto LAB_00c3fb10;
    }
    *pcVar10 = '\x01';
    puVar4[0] = 0xffffffff;
    puVar4[1] = 0xffffffff;
    puVar4[10] = 0xffffffff;
    puVar4[0xb] = 0xffffffff;
    puVar4[0xc] = 0xffffffff;
    puVar4[0xd] = 0xffffffff;
    puVar4[6] = 0xffffffff;
    puVar4[7] = 0xffffffff;
    puVar4[8] = 0xffffffff;
    puVar4[9] = 0xffffffff;
    puVar4[2] = 0xffffffff;
    puVar4[3] = 0xffffffff;
    puVar4[4] = 0xffffffff;
    puVar4[5] = 0xffffffff;
    FUN_01765e80();
joined_r0x00c3fa78:
    if ((puVar5 == (uint *)0x0) || (puVar6 = puVar5, FUN_01765e60(), puVar6 == (uint *)0x0))
    goto LAB_00c3fb0c;
    FUN_01765e50();
    puVar4[5] = 0xfffffffe;
    if ((uint)puVar5 == 0) goto LAB_00c3fb0c;
    uVar8 = 0;
    puVar12 = puVar6 + 1;
    while (puVar6[(ulong)uVar8 * 2] != 0xd200ffd3) {
      uVar8 = uVar8 + 1;
      puVar12 = puVar12 + 2;
      if ((uint)puVar5 <= uVar8) goto LAB_00c3fb0c;
    }
    uVar8 = 0;
    if (*puVar12 != 0xffffffff) {
      uVar8 = *puVar12;
    }
    puVar4[5] = uVar8;
    uVar8 = *puVar13;
  } while( true );
joined_r0x00c3f8e8:
  puRam00000000033f5550 = puVar3;
  if (uVar8 == 0) goto LAB_00c3f9e0;
  if (*pcVar10 == '\0') {
    *pcVar10 = '\x01';
    puVar4[10] = 0xffffffff;
    puVar4[0xb] = 0xffffffff;
    puVar4[0xc] = 0xffffffff;
    puVar4[0xd] = 0xffffffff;
    puVar4[0] = 0xffffffff;
    puVar4[1] = 0xffffffff;
    puVar4[6] = 0xffffffff;
    puVar4[7] = 0xffffffff;
    puVar4[8] = 0xffffffff;
    puVar4[9] = 0xffffffff;
    puVar4[2] = 0xffffffff;
    puVar4[3] = 0xffffffff;
    puVar4[4] = 0xffffffff;
    puVar4[5] = 0xffffffff;
  }
  else {
    uVar8 = puVar4[4];
    if (-1 < (int)uVar8) {
      if ((undefined4 *)((long)(int)uVar8 + (long)puVar13) == (undefined4 *)0x0) goto LAB_00c3fa28;
      uVar17 = *(undefined4 *)((long)(int)uVar8 + (long)puVar13);
      *param_2 = uVar15;
      param_2[1] = uVar14;
      param_2[2] = uVar17;
      uVar8 = *puVar13;
      pcVar10 = pcRam00000000033f54c0;
      puVar4 = puRam00000000033f54c8;
      goto joined_r0x00c400b8;
    }
    if (uVar8 != 0xffffffff) goto LAB_00c3f9e0;
  }
  puVar3 = puVar13;
  FUN_01765e80();
  if ((puVar3 == (uint *)0x0) || (puVar5 = puVar3, FUN_01765e60(), puVar5 == (uint *)0x0))
  goto LAB_00c3f9e0;
  FUN_01765e50();
  puVar4[4] = 0xfffffffe;
  if ((uint)puVar3 == 0) goto LAB_00c3f9e0;
  uVar8 = 0;
  puVar6 = puVar5 + 1;
  while (puVar5[(ulong)uVar8 * 2] != 0x5cf3a1a1) {
    uVar8 = uVar8 + 1;
    puVar6 = puVar6 + 2;
    if ((uint)puVar3 <= uVar8) goto LAB_00c3f9e0;
  }
  uVar8 = 0;
  if (*puVar6 != 0xffffffff) {
    uVar8 = *puVar6;
  }
  puVar4[4] = uVar8;
  uVar8 = *puVar13;
  puVar3 = puRam00000000033f5550;
  goto joined_r0x00c3f8e8;
LAB_00c3f9e0:
  puVar3 = puRam00000000033f5550;
  *param_2 = uVar15;
  param_2[1] = uVar14;
  param_2[2] = 0;
  uVar8 = *puVar13;
  pcVar10 = pcRam00000000033f54c0;
  puVar4 = puRam00000000033f54c8;
  goto joined_r0x00c400b8;
LAB_00c3fb10:
  param_2[3] = (int)pfVar9;
  puVar4 = puVar13;
  FUN_01765ea0();
  if ((*puVar3 <= (uint)puVar4) ||
     (uVar7 = *(ushort *)(*(long *)(puVar3 + 2) + (long)(int)(uint)puVar4 * 2), uVar8 = (uint)uVar7,
     2 < uVar7)) {
    uVar8 = 0;
  }
  param_2[0x32] = uVar8;
  puVar3 = puRam00000000033f54c8;
  pcVar11 = pcRam00000000033f54c0;
  pcVar10 = (char *)(ulong)*puVar13;
  if (*puVar13 != 0) {
    do {
      puVar4 = puVar13;
      if (*pcVar11 == '\0') {
        *pcVar11 = '\x01';
        puVar3[10] = 0xffffffff;
        puVar3[0xb] = 0xffffffff;
        puVar3[0xc] = 0xffffffff;
        puVar3[0xd] = 0xffffffff;
        puVar3[0] = 0xffffffff;
        puVar3[1] = 0xffffffff;
        puVar3[6] = 0xffffffff;
        puVar3[7] = 0xffffffff;
        puVar3[8] = 0xffffffff;
        puVar3[9] = 0xffffffff;
        puVar3[2] = 0xffffffff;
        puVar3[3] = 0xffffffff;
        puVar3[4] = 0xffffffff;
        puVar3[5] = 0xffffffff;
        FUN_01765e80();
      }
      else {
        uVar8 = puVar3[0xc];
        if (-1 < (int)uVar8) {
          pcVar10 = (char *)((long)(int)uVar8 + (long)puVar13);
          if (pcVar10 != (char *)0x0) {
            *(bool *)(param_2 + 0x33) = *pcVar10 != '\0';
            uVar8 = *puVar13;
            goto joined_r0x00c40018;
          }
          break;
        }
        if (uVar8 != 0xffffffff) goto LAB_00c3fc1c;
        FUN_01765e80();
      }
      if ((puVar4 == (uint *)0x0) || (puVar5 = puVar4, FUN_01765e60(), puVar5 == (uint *)0x0)) {
LAB_00c3fc1c:
        *(undefined1 *)(param_2 + 0x33) = 0;
        uVar8 = *puVar13;
        pcVar10 = pcRam00000000033f54c0;
        puVar3 = puRam00000000033f54c8;
        goto joined_r0x00c3fc28;
      }
      FUN_01765e50();
      pcVar10 = (char *)0x0;
      puVar3[0xc] = 0xfffffffe;
      if ((uint)puVar4 == 0) break;
      puVar6 = puVar5 + 1;
      while (puVar5[(long)pcVar10 * 2] != 0x91eaeedd) {
        uVar8 = (int)pcVar10 + 1;
        pcVar10 = (char *)(ulong)uVar8;
        puVar6 = puVar6 + 2;
        if ((uint)puVar4 <= uVar8) {
          pcVar10 = (char *)0x0;
          goto LAB_00c3fc34;
        }
      }
      uVar8 = 0;
      if (*puVar6 != 0xffffffff) {
        uVar8 = *puVar6;
      }
      puVar3[0xc] = uVar8;
      pcVar10 = (char *)(ulong)*puVar13;
      if (*puVar13 == 0) break;
    } while( true );
  }
LAB_00c3fc34:
  *(char *)(param_2 + 0x33) = (char)pcVar10;
  uVar8 = *puVar13;
joined_r0x00c40018:
  pcVar11 = (char *)(ulong)uVar8;
  puVar3 = puRam00000000033f54c8;
  pcVar10 = pcRam00000000033f54c0;
  if (uVar8 != 0) {
    while (puVar4 = puVar13, *pcVar10 == '\0') {
      *pcVar10 = '\x01';
      puVar3[10] = 0xffffffff;
      puVar3[0xb] = 0xffffffff;
      puVar3[0xc] = 0xffffffff;
      puVar3[0xd] = 0xffffffff;
      puVar3[0] = 0xffffffff;
      puVar3[1] = 0xffffffff;
      puVar3[6] = 0xffffffff;
      puVar3[7] = 0xffffffff;
      puVar3[8] = 0xffffffff;
      puVar3[9] = 0xffffffff;
      puVar3[2] = 0xffffffff;
      puVar3[3] = 0xffffffff;
      puVar3[4] = 0xffffffff;
      puVar3[5] = 0xffffffff;
      FUN_01765e80();
      if (puVar4 == (uint *)0x0) goto LAB_00c3fd14;
LAB_00c3fc88:
      puVar5 = puVar4;
      FUN_01765e60();
      if (puVar5 == (uint *)0x0) goto LAB_00c3fd14;
      FUN_01765e50();
      pcVar11 = (char *)0x0;
      puVar3[0xd] = 0xfffffffe;
      if ((uint)puVar4 == 0) goto LAB_00c3fd34;
      puVar6 = puVar5 + 1;
      while (puVar5[(long)pcVar11 * 2] != 0xf58109f5) {
        uVar8 = (int)pcVar11 + 1;
        pcVar11 = (char *)(ulong)uVar8;
        puVar6 = puVar6 + 2;
        if ((uint)puVar4 <= uVar8) {
          pcVar11 = (char *)0x0;
          goto LAB_00c3fd34;
        }
      }
      uVar8 = 0;
      if (*puVar6 != 0xffffffff) {
        uVar8 = *puVar6;
      }
      puVar3[0xd] = uVar8;
      uVar8 = *puVar13;
joined_r0x00c3fc28:
      pcVar11 = (char *)(ulong)uVar8;
      if (uVar8 == 0) goto LAB_00c3fd34;
    }
    uVar8 = puVar3[0xd];
    if ((int)uVar8 < 0) {
      if ((uVar8 == 0xffffffff) && (FUN_01765e80(), puVar4 != (uint *)0x0)) goto LAB_00c3fc88;
LAB_00c3fd14:
      *(undefined1 *)((long)param_2 + 0xcd) = 0;
      uVar8 = *puVar13;
      pcVar10 = pcRam00000000033f54c0;
      puVar3 = puRam00000000033f54c8;
      goto joined_r0x00c4003c;
    }
    pcVar11 = (char *)((long)(int)uVar8 + (long)puVar13);
    if (pcVar11 != (char *)0x0) {
      *(bool *)((long)param_2 + 0xcd) = *pcVar11 != '\0';
      uVar8 = *puVar13;
      pcVar10 = pcRam00000000033f54c0;
      puVar3 = puRam00000000033f54c8;
      goto joined_r0x00c4003c;
    }
  }
LAB_00c3fd34:
  *(char *)((long)param_2 + 0xcd) = (char)pcVar11;
  uVar8 = *puVar13;
  pcVar10 = pcRam00000000033f54c0;
  puVar3 = puRam00000000033f54c8;
joined_r0x00c4003c:
  pcRam00000000033f54c0 = pcVar10;
  puRam00000000033f54c8 = puVar3;
  if (uVar8 != 0) {
    do {
      puVar4 = puVar13;
      if (*pcVar10 != '\0') {
        uVar8 = puVar3[8];
        if ((int)uVar8 < 0) {
          if ((uVar8 == 0xffffffff) && (FUN_01765e80(), puVar4 != (uint *)0x0)) goto LAB_00c3fd8c;
          goto LAB_00c3fe18;
        }
        if ((undefined4 *)((long)(int)uVar8 + (long)puVar13) == (undefined4 *)0x0) {
LAB_00c3fe30:
          uVar1 = *puVar13;
          uVar14 = 0;
        }
        else {
          uVar1 = *puVar13;
          uVar14 = *(undefined4 *)((long)(int)uVar8 + (long)puVar13);
        }
        uVar15 = uVar14;
        if (uVar1 == 0) goto LAB_00c3fe24;
LAB_00c3fe38:
        uVar14 = uVar15;
        uVar15 = 0;
        uVar17 = 0;
        goto LAB_00c3fe4c;
      }
      *pcVar10 = '\x01';
      puVar3[10] = 0xffffffff;
      puVar3[0xb] = 0xffffffff;
      puVar3[0xc] = 0xffffffff;
      puVar3[0xd] = 0xffffffff;
      puVar3[0] = 0xffffffff;
      puVar3[1] = 0xffffffff;
      puVar3[6] = 0xffffffff;
      puVar3[7] = 0xffffffff;
      puVar3[8] = 0xffffffff;
      puVar3[9] = 0xffffffff;
      puVar3[2] = 0xffffffff;
      puVar3[3] = 0xffffffff;
      puVar3[4] = 0xffffffff;
      puVar3[5] = 0xffffffff;
      FUN_01765e80();
      if (puVar4 == (uint *)0x0) {
LAB_00c3fe18:
        uVar14 = 0;
        uVar15 = 0;
        if (*puVar13 != 0) goto LAB_00c3fe38;
        goto LAB_00c3fe24;
      }
LAB_00c3fd8c:
      puVar5 = puVar4;
      FUN_01765e60();
      if (puVar5 == (uint *)0x0) goto LAB_00c3fe18;
      FUN_01765e50();
      puVar3[8] = 0xfffffffe;
      if ((uint)puVar4 == 0) goto LAB_00c3fe18;
      uVar8 = 0;
      puVar6 = puVar5 + 1;
      while (puVar5[(ulong)uVar8 * 2] != 0x1f3893e5) {
        uVar8 = uVar8 + 1;
        puVar6 = puVar6 + 2;
        if ((uint)puVar4 <= uVar8) goto LAB_00c3fe30;
      }
      uVar8 = 0;
      if (*puVar6 != 0xffffffff) {
        uVar8 = *puVar6;
      }
      puVar3[8] = uVar8;
    } while (*puVar13 != 0);
  }
  uVar14 = 0;
LAB_00c3fe24:
  uVar15 = 0;
  uVar16 = 0;
  goto LAB_00c3ffc8;
joined_r0x00c3ff00:
  uVar16 = 0;
  if (uVar8 == 0) goto LAB_00c3ffc8;
  if (*pcVar10 == '\0') {
    *pcVar10 = '\x01';
    puVar3[10] = 0xffffffff;
    puVar3[0xb] = 0xffffffff;
    puVar3[0xc] = 0xffffffff;
    puVar3[0xd] = 0xffffffff;
    puVar3[0] = 0xffffffff;
    puVar3[1] = 0xffffffff;
    puVar3[6] = 0xffffffff;
    puVar3[7] = 0xffffffff;
    puVar3[8] = 0xffffffff;
    puVar3[9] = 0xffffffff;
    puVar3[2] = 0xffffffff;
    puVar3[3] = 0xffffffff;
    puVar3[4] = 0xffffffff;
    puVar3[5] = 0xffffffff;
  }
  else {
    uVar8 = *puVar3;
    if (-1 < (int)uVar8) {
      uVar16 = uVar17;
      if ((undefined4 *)((long)(int)uVar8 + (long)puVar13) != (undefined4 *)0x0) {
        uVar16 = *(undefined4 *)((long)(int)uVar8 + (long)puVar13);
      }
      goto LAB_00c3ffc8;
    }
    uVar16 = uVar17;
    if (uVar8 != 0xffffffff) goto LAB_00c3ffc8;
  }
  puVar4 = puVar13;
  FUN_01765e80();
  uVar16 = uVar17;
  if ((puVar4 == (uint *)0x0) || (puVar5 = puVar4, FUN_01765e60(), puVar5 == (uint *)0x0))
  goto LAB_00c3ffc8;
  FUN_01765e50();
  *puVar3 = 0xfffffffe;
  if ((uint)puVar4 == 0) goto LAB_00c3ffc8;
  uVar8 = 0;
  puVar6 = puVar5 + 1;
  while (puVar5[(ulong)uVar8 * 2] != 0x65f8c085) {
    uVar8 = uVar8 + 1;
    puVar6 = puVar6 + 2;
    if ((uint)puVar4 <= uVar8) goto LAB_00c3ffc8;
  }
  uVar8 = 0;
  if (*puVar6 != 0xffffffff) {
    uVar8 = *puVar6;
  }
  *puVar3 = uVar8;
  uVar8 = *puVar13;
  goto joined_r0x00c3ff00;
LAB_00c3fe4c:
  do {
    if (*pcVar10 != '\0') {
      uVar8 = puVar3[1];
      if ((int)uVar8 < 0) {
        if (uVar8 == 0xffffffff) goto LAB_00c3fe7c;
LAB_00c3ffbc:
        uVar8 = *puVar13;
      }
      else if ((undefined4 *)((long)(int)uVar8 + (long)puVar13) == (undefined4 *)0x0) {
LAB_00c3fefc:
        uVar8 = *puVar13;
      }
      else {
        uVar15 = *(undefined4 *)((long)(int)uVar8 + (long)puVar13);
        uVar8 = *puVar13;
      }
      goto joined_r0x00c3ff00;
    }
    *pcVar10 = '\x01';
    puVar3[10] = 0xffffffff;
    puVar3[0xb] = 0xffffffff;
    puVar3[0xc] = 0xffffffff;
    puVar3[0xd] = 0xffffffff;
    puVar3[0] = 0xffffffff;
    puVar3[1] = 0xffffffff;
    puVar3[6] = 0xffffffff;
    puVar3[7] = 0xffffffff;
    puVar3[8] = 0xffffffff;
    puVar3[9] = 0xffffffff;
    puVar3[2] = 0xffffffff;
    puVar3[3] = 0xffffffff;
    puVar3[4] = 0xffffffff;
    puVar3[5] = 0xffffffff;
LAB_00c3fe7c:
    puVar4 = puVar13;
    FUN_01765e80();
    if ((puVar4 == (uint *)0x0) || (puVar5 = puVar4, FUN_01765e60(), puVar5 == (uint *)0x0))
    goto LAB_00c3ffbc;
    FUN_01765e50();
    puVar3[1] = 0xfffffffe;
    if ((uint)puVar4 == 0) goto LAB_00c3ffbc;
    uVar8 = 0;
    puVar6 = puVar5 + 1;
    while (puVar5[(ulong)uVar8 * 2] != 0x2258ba55) {
      uVar8 = uVar8 + 1;
      puVar6 = puVar6 + 2;
      if ((uint)puVar4 <= uVar8) goto LAB_00c3fefc;
    }
    uVar8 = 0;
    if (*puVar6 != 0xffffffff) {
      uVar8 = *puVar6;
    }
    puVar3[1] = uVar8;
  } while (*puVar13 != 0);
  uVar15 = 0;
  uVar16 = uVar17;
LAB_00c3ffc8:
  param_2[0x37] = uVar14;
  param_2[0x38] = uVar15;
  param_2[0x39] = uVar16;
  return 1;
}

