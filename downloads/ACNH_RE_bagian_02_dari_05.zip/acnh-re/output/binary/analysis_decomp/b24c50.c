
void FUN_00c24c50(long param_1,undefined4 param_2,byte param_3)

{
  *(undefined4 *)(param_1 + 0x2464) = param_2;
  *(byte *)(param_1 + 0x2462) = param_3 & 1;
  return;
}

