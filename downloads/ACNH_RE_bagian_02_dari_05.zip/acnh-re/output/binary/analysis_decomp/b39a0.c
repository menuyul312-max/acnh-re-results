
void _INIT_268(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003450110 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3450148);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003450114 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003450118 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000345012c = 0xffff;
  uRam0000000003450128 = 0xffffffff;
  uRam0000000003450134 = 0;
  uRam0000000003450130 = 0;
  uRam000000000345011c = (undefined4)uVar2;
  uRam0000000003450120 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003450140 = 0;
  uRam0000000003450138 = uVar2;
  FUN_022ee770(0x3f800000,0x3450158,0);
  lRam0000000003450158 = lRam00000000033d4038 + 0x10;
  FUN_01a9a580(0x34501d8);
  FUN_001001c0(uRam00000000033d4b60,0x3450158,&DAT_0311c000);
  return;
}

