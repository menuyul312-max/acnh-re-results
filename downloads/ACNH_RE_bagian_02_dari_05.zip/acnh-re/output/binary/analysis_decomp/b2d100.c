
undefined4 FUN_00c2d100(long param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2c);
  if (iVar1 == 2) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x30);
  }
  if (iVar1 == 1) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x2c);
  }
  if (iVar1 != 0) {
    return 0;
  }
  iVar1 = *(int *)(param_1 + 0x34);
  if (iVar1 != 2) {
    if (iVar1 == 1) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x24);
    }
    if (iVar1 == 0) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x20);
    }
    return 0;
  }
  return *(undefined4 *)(lRam00000000033f4d60 + 0x28);
}

