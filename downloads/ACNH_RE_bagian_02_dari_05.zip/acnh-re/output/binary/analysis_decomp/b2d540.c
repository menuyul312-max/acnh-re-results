
bool FUN_00c2d540(long param_1)

{
  return *(int *)(param_1 + 8) == 0;
}

