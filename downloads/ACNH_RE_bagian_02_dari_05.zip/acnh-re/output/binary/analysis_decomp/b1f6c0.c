
undefined1 FUN_00c1f6c0(long param_1)

{
  *(undefined1 *)(param_1 + 0x30f0) = 0;
  FUN_00c1f6f0();
  return *(undefined1 *)(param_1 + 0x30f0);
}

