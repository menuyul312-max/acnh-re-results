
void FUN_00c34110(long param_1,int param_2)

{
  ulong uVar1;
  int iStack_24;
  
  uVar1 = *puRam00000000033d2050;
  FUN_001c6030(uVar1);
  if (param_2 < 0x18) {
    iStack_24 = param_2;
    if (param_2 < 0) {
      iStack_24 = 0;
    }
  }
  else {
    iStack_24 = 0x17;
  }
  FUN_00c170f0(param_1,uVar1 & 0xffffffff,&iStack_24);
  *(int *)(param_1 + 0x108) = iStack_24;
  return;
}

