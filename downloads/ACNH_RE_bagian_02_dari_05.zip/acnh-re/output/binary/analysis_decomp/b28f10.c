
void FUN_00c28f10(long param_1,byte param_2)

{
  *(byte *)(param_1 + 0x1a1) = param_2 & 1;
  return;
}

