
undefined8 FUN_00c2cfd0(long param_1)

{
  return *(undefined8 *)(param_1 + 8);
}

