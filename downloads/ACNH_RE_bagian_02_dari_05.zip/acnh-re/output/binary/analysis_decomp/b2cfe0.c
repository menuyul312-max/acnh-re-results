
undefined8 FUN_00c2cfe0(long param_1)

{
  return *(undefined8 *)(param_1 + 8);
}

