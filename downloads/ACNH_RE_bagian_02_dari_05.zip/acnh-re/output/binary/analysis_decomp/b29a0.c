
undefined8 FUN_001b29a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,long param_4)

{
  int iVar1;
  uint *puVar2;
  long *plVar3;
  long lVar4;
  long lVar5;
  
  puVar2 = *(uint **)(param_4 + 0x18);
  (**(code **)(*(long *)puVar2 + 0x20))();
  (*(code *)**(undefined8 **)puVar2)();
  iVar1 = (int)puVar2;
  FUN_001b2ed0();
  if (0 < (int)*puVar2) {
    lVar4 = 0;
    do {
      if (*(int *)(*(long *)(puVar2 + 2) + lVar4 * 4) == iVar1) {
        if ((int)lVar4 != -1) goto LAB_001b2a20;
        break;
      }
      lVar4 = lVar4 + 1;
    } while (lVar4 < (int)*puVar2);
  }
  lVar4 = 0;
LAB_001b2a20:
  FUN_001b2ed0();
  lVar5 = (long)(int)(uint)lVar4;
  if (*puVar2 <= (uint)lVar4) {
    lVar5 = 0;
  }
  iVar1 = *(int *)(*(long *)(puVar2 + 2) + lVar5 * 4);
  if (iVar1 == 9) {
    plVar3 = *(long **)(param_4 + 0x18);
    (**(code **)(*plVar3 + 0x20))();
    FUN_01ff9f90(param_3,plVar3,param_2);
    return param_3;
  }
  if (iVar1 != 5) {
    return 0;
  }
  plVar3 = *(long **)(param_4 + 0x18);
  (**(code **)(*plVar3 + 0x20))();
  FUN_01ff9e60(param_3,plVar3,param_2);
  return param_3;
}

