
bool FUN_00c27880(long param_1)

{
  bool bVar1;
  long lVar2;
  
  bVar1 = (*(uint *)(param_1 + 0x2188) | 4) != 5;
  if (!bVar1) {
    *(undefined1 *)(param_1 + 0x1480) = 0;
    FUN_0011e660(param_1);
  }
  lVar2 = param_1 + 0x1030;
  FUN_00be4ae0(lVar2,param_1 + 0x218,param_1 + 0x6f8);
  return bVar1 && (int)lVar2 == 0;
}

