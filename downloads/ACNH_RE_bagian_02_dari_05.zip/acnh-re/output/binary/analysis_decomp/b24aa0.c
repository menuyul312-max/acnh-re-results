
void FUN_00c24aa0(long param_1,undefined8 param_2)

{
  *(undefined8 *)(param_1 + 0xb8) = param_2;
  *(undefined8 *)(param_1 + 0xc0) = param_2;
  return;
}

