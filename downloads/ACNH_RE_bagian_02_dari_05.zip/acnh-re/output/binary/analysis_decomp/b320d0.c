
void FUN_00c320d0(undefined8 param_1)

{
  ulong uVar1;
  undefined1 *puVar2;
  long lVar3;
  long lStack_60;
  long lStack_58;
  undefined1 auStack_48 [24];
  undefined4 auStack_30 [2];
  long lStack_28;
  undefined1 auStack_18 [8];
  
  FUN_001b60c0(auStack_18);
  FUN_001b3ee0(auStack_48,auStack_18);
  FUN_001b6250(auStack_18);
  uVar1 = 0;
  thunk_FUN_001b62b0();
  if ((uVar1 & 1) == 0) {
    puVar2 = auStack_48;
    FUN_001b5530();
    if (puVar2 == (undefined1 *)0x0) goto LAB_00c321ac;
    FUN_00fe9350(&lStack_60,puVar2,1);
    lStack_60 = lRam00000000033d4ba0 + 0x10;
    lVar3 = *(long *)(lStack_58 + 0x10) + *(long *)(lStack_58 + 8);
    FUN_010798b0();
  }
  else {
    puVar2 = auStack_48;
    FUN_001b5540();
    if (puVar2 == (undefined1 *)0x0) goto LAB_00c321ac;
    FUN_00fe9350(&lStack_60,puVar2,1);
    lStack_60 = lRam00000000033d4b98 + 0x10;
    lVar3 = *(long *)(lStack_58 + 0x10) + *(long *)(lStack_58 + 8);
    FUN_0107a0a0();
  }
  FUN_01078ba0();
  auStack_30[0] = 0x14;
  lStack_28 = lVar3;
  FUN_010e4670(param_1,auStack_30);
  FUN_00fe93d0(&lStack_60);
LAB_00c321ac:
  FUN_001b6250(auStack_48);
  return;
}

