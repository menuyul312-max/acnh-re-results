
void FUN_00c27b00(long param_1,byte param_2)

{
  *(byte *)(param_1 + 0x2190) = param_2 & 1;
  return;
}

