
void FUN_00c2c5a0(long param_1)

{
  *(undefined1 *)(param_1 + 0x38) = 1;
  return;
}

