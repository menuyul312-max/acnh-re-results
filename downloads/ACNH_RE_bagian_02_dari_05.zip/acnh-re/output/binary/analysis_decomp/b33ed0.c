
void FUN_00c33ed0(long param_1,undefined4 param_2,undefined4 param_3)

{
  ulong uVar1;
  
  uVar1 = *puRam00000000033d2050;
  FUN_001c6030(uVar1);
  FUN_00c16f90(param_1,uVar1 & 0xffffffff,param_2,param_3);
  *(undefined4 *)(param_1 + 0x108) = param_2;
  return;
}

