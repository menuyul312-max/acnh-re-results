
void _INIT_2641(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003654dd8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3654e20);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003654ddc = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003654de0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003654e04 = 0xffff;
  uRam0000000003654e00 = 0xffffffff;
  uRam0000000003654e0c = 0;
  uRam0000000003654e08 = 0;
  uRam0000000003654de4 = (undefined4)uVar2;
  uRam0000000003654de8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003654e10 = uVar2;
  uRam0000000003654e18 = 0;
  lRam0000000003654e30 = lRam00000000033d0668 + 0x10;
  puRam0000000003654e38 = &UNK_02a4fd5c;
  uRam0000000003654dec = 0x200000003;
  iRam0000000003654df4 = -*piRam00000000033d0630;
  iRam0000000003654df8 = *piRam00000000033d0630;
  return;
}

