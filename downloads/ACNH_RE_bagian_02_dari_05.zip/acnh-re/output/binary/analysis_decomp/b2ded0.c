
void FUN_00c2ded0(int *param_1)

{
  *param_1 = *param_1 + 1;
  return;
}

