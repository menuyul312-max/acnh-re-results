
ulong FUN_00c38330(ulong param_1,uint param_2)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  int iVar5;
  long lVar6;
  
  if (0 < (int)*(uint *)(param_1 + 0x1c0)) {
    if (param_2 < *(uint *)(param_1 + 0x1c0)) {
      lVar6 = (long)(int)param_2;
      if (*(uint *)(param_1 + 0x1b0) <= param_2) {
        lVar6 = 0;
      }
      return *(ulong *)(*(long *)(param_1 + 0x1b8) + lVar6 * 8);
    }
    return 0;
  }
  uVar1 = param_1;
  FUN_01766670();
  if (uVar1 != 0) {
    if ((param_2 < *(uint *)(param_1 + 200)) &&
       (*(char *)(*(long *)(param_1 + 0xd0) + (long)(int)param_2) == '\0')) {
      return 0;
    }
    uVar2 = uVar1;
    FUN_01765e30();
    if ((uint)uVar2 <= param_2) {
      return 0;
    }
    uVar2 = uVar1;
    FUN_01765e40();
    if ((int)uVar2 == 0) {
      return 0;
    }
    uVar3 = uVar1;
    FUN_01765e50();
    if ((int)uVar3 == 0) {
      return 0;
    }
    uVar4 = uVar1;
    FUN_01765df0();
    iVar5 = 0x1c;
    if ((uVar4 & 1) == 0) {
      iVar5 = 0xc;
    }
    uVar1 = ((int)uVar2 * param_2 + (int)uVar3 * 8 + iVar5) + uVar1;
  }
  return uVar1;
}

