
void FUN_00c290f0(long param_1,undefined8 param_2)

{
  long *plVar1;
  long *plVar2;
  
  plVar2 = (long *)(param_1 + 200);
  plVar1 = plVar2;
  (**(code **)(*plVar2 + 0x10))();
  if (((ulong)plVar1 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c29130. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*plVar2)(plVar2,param_2);
    return;
  }
  return;
}

