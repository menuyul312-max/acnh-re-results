
void FUN_00c33fc0(long param_1,undefined4 param_2,short *param_3)

{
  int iVar1;
  
  iVar1 = (int)*param_3;
  if (*param_3 < 0x3e9) {
    iVar1 = 1000;
  }
  if (0x270e < iVar1) {
    iVar1 = 9999;
  }
  FUN_00c16fb0(param_1,param_2,iVar1);
  *(int *)(param_1 + 0x108) = iVar1;
  return;
}

