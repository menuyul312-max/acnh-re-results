
undefined8 FUN_00c2cd70(long param_1)

{
  undefined8 uVar1;
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    return 1;
  }
  uVar1 = *(undefined8 *)(*(long *)(param_1 + 0x20) + 0x218);
  FUN_0138b790(uVar1);
  return uVar1;
}

