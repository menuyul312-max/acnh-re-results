
undefined4 FUN_00c24d60(long param_1)

{
  return *(undefined4 *)(param_1 + 0x2468);
}

