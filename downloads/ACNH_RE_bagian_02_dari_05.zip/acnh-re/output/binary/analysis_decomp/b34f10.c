
void FUN_00c34f10(long *param_1)

{
  *param_1 = lRam00000000033f5268 + 0x10;
  FUN_001237f0(param_1 + 1);
  return;
}

