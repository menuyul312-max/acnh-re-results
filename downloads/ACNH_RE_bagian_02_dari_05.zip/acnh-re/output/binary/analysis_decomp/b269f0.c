
uint FUN_00c269f0(long param_1,ulong param_2)

{
  int iVar1;
  ulong uVar2;
  ulong uVar3;
  undefined1 *puVar4;
  undefined8 uVar5;
  undefined1 *puVar6;
  undefined1 auStack_288 [584];
  undefined1 auStack_40 [16];
  
  uVar2 = param_2;
  FUN_00be9e10(param_2);
  uVar3 = param_1 + 0x8c;
  FUN_00be6480();
  uVar3 = uVar3 & 0xffffffff;
  FUN_00be6d40();
  if ((uVar3 & 1) != 0) {
    iVar1 = (int)*puRam00000000033d0f28;
    FUN_00c127c0();
    FUN_00c17ae0();
    if (iVar1 == 0) {
      FUN_00be9e60();
      if ((param_2 & 1) == 0) {
        uVar5 = 0x25;
      }
      else {
        uVar5 = 0x27;
      }
      FUN_00c1e5a0(auStack_40,uVar5);
      puVar6 = auStack_40;
      goto LAB_00c26a50;
    }
  }
  puVar6 = (undefined1 *)0x0;
LAB_00c26a50:
  FUN_00c1d910(auStack_288,param_1);
  puVar4 = auStack_288;
  FUN_00c1d9e0(puVar4,uVar2,puVar6);
  FUN_00c1d960(auStack_288);
  return (uint)puVar4 & 1;
}

