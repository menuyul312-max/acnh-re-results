
void FUN_00c2f730(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if ((0x2e < iVar1 - 0xdaU || (1L << ((ulong)(iVar1 - 0xdaU) & 0x3f) & 0x40000000001fU) == 0) &&
     (1 < iVar1 - 0xa6U && iVar1 != 0)) {
    *param_1 = 0x9f;
    return;
  }
  return;
}

