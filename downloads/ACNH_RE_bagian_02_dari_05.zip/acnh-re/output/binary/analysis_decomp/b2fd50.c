
void _INIT_2649(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655068 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36550a0);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000365506c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655070 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655084 = 0xffff;
  uRam0000000003655080 = 0xffffffff;
  uRam000000000365508c = 0;
  uRam0000000003655088 = 0;
  uRam0000000003655074 = (undefined4)uVar2;
  uRam0000000003655078 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003655090 = uVar2;
  uRam0000000003655098 = 0;
  return;
}

