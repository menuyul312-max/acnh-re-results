
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c1dd00(long param_1,ulong param_2)

{
  short sVar1;
  short sVar2;
  uint uVar3;
  ulong uVar4;
  undefined *puVar5;
  long lVar6;
  ulong uVar7;
  undefined *puVar8;
  undefined1 auStack_34 [4];
  
  uVar7 = param_2;
  FUN_00122290();
  uVar4 = param_2;
  FUN_001222a0();
  *(undefined2 *)(param_1 + 9) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  sVar1 = *psRam00000000033d14d0;
  **(short **)(param_1 + 0x18) = sVar1;
  **(short **)(param_1 + 0xb0) = sVar1;
  uVar3 = (uint)uVar4;
  if ((int)uVar7 == 0x28) {
    if (uVar3 == 1) {
      *(undefined1 *)(param_1 + 10) = 1;
    }
    else {
      lVar6 = lRam00000000033f4db8;
      if (uVar3 < 0x3e) goto LAB_00c1dda0;
    }
  }
  else if (((int)uVar7 == 0x2d) && (lVar6 = lRam00000000033f4db0, uVar3 < 7)) {
LAB_00c1dda0:
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(lVar6 + (uVar4 & 0xffffffff) * 4);
  }
  FUN_001226f0(param_2,auStack_34,param_1 + 0x10);
  switch(auStack_34[0]) {
  case 0:
    if (*(char *)(param_1 + 8) == '\0') {
      if (*(int *)(*plRam00000000033d3e18 + 0xcc8) != -1) {
        FUN_01a908c0(param_1 + 0x10,&UNK_02af0640);
        return;
      }
      puVar8 = *(undefined **)(param_1 + 0x18);
      if (puVar8 == &UNK_02af15b8) {
        return;
      }
      uVar7 = 0;
      sVar2 = _UNK_02af15b8;
      while (sVar2 != sVar1) {
        if (uVar7 >> 0x13 != 0) goto LAB_00c1dff8;
        if (*(short *)(&UNK_02af15ba + uVar7 * 2) == sVar1) goto LAB_00c1e000;
        uVar7 = uVar7 + 2;
        sVar2 = *(short *)(&UNK_02af15b8 + uVar7 * 2);
      }
    }
    else {
      puVar8 = *(undefined **)(param_1 + 0x18);
      if (puVar8 == &UNK_02af15b8) {
        return;
      }
      uVar7 = 0;
      sVar2 = _UNK_02af15b8;
      while (sVar2 != sVar1) {
        if (uVar7 >> 0x13 != 0) goto LAB_00c1dff8;
        if (*(short *)(&UNK_02af15ba + uVar7 * 2) == sVar1) goto LAB_00c1e000;
        uVar7 = uVar7 + 2;
        sVar2 = *(short *)(&UNK_02af15b8 + uVar7 * 2);
      }
    }
    goto LAB_00c1e004;
  case 1:
    puVar8 = *(undefined **)(param_1 + 0x18);
    if (puVar8 == &UNK_02af15b8) {
      return;
    }
    uVar7 = 0;
    sVar2 = _UNK_02af15b8;
    while (sVar2 != sVar1) {
      if (uVar7 >> 0x13 != 0) goto LAB_00c1dff8;
      if (*(short *)(&UNK_02af15ba + uVar7 * 2) == sVar1) goto LAB_00c1e000;
      uVar7 = uVar7 + 2;
      sVar2 = *(short *)(&UNK_02af15b8 + uVar7 * 2);
    }
    goto LAB_00c1e004;
  case 2:
    puVar8 = *(undefined **)(param_1 + 0x18);
    if (puVar8 == &UNK_02af1298) {
      return;
    }
    uVar7 = 0;
    sVar2 = _UNK_02af1298;
    while (sVar2 != sVar1) {
      if (uVar7 >> 0x13 != 0) {
        uVar7 = 0;
        break;
      }
      if (*(short *)(&UNK_02af129a + uVar7 * 2) == sVar1) {
        uVar7 = uVar7 + 1;
        break;
      }
      uVar7 = uVar7 + 2;
      sVar2 = *(short *)(&UNK_02af1298 + uVar7 * 2);
    }
    uVar3 = (uint)uVar7;
    if (*(int *)(param_1 + 0x20) <= (int)(uint)uVar7) {
      uVar3 = *(int *)(param_1 + 0x20) - 1;
    }
    uVar7 = -(ulong)(uVar3 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar3 << 1;
    puVar5 = &UNK_02af1298;
    break;
  case 3:
    puVar8 = *(undefined **)(param_1 + 0x18);
    if (puVar8 == &UNK_02af0a62) {
      return;
    }
    uVar7 = 0;
    sVar2 = _UNK_02af0a62;
    while (sVar2 != sVar1) {
      if (uVar7 >> 0x13 != 0) {
        uVar7 = 0;
        break;
      }
      if (*(short *)(&UNK_02af0a64 + uVar7 * 2) == sVar1) {
        uVar7 = uVar7 + 1;
        break;
      }
      uVar7 = uVar7 + 2;
      sVar2 = *(short *)(&UNK_02af0a62 + uVar7 * 2);
    }
    uVar3 = (uint)uVar7;
    if (*(int *)(param_1 + 0x20) <= (int)(uint)uVar7) {
      uVar3 = *(int *)(param_1 + 0x20) - 1;
    }
    uVar7 = -(ulong)(uVar3 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar3 << 1;
    puVar5 = &UNK_02af0a62;
    break;
  default:
    goto switchD_00c1ddd8_default;
  }
  goto LAB_00c1e020;
LAB_00c1dff8:
  uVar7 = 0;
  goto LAB_00c1e004;
LAB_00c1e000:
  uVar7 = uVar7 + 1;
LAB_00c1e004:
  uVar3 = (uint)uVar7;
  if (*(int *)(param_1 + 0x20) <= (int)(uint)uVar7) {
    uVar3 = *(int *)(param_1 + 0x20) - 1;
  }
  uVar7 = -(ulong)(uVar3 >> 0x1f) & 0xfffffffe00000000 | (ulong)uVar3 << 1;
  puVar5 = &UNK_02af15b8;
LAB_00c1e020:
  memcpy(puVar8,puVar5,uVar7);
  *(short *)(puVar8 + uVar7) = sVar1;
switchD_00c1ddd8_default:
  return;
}

