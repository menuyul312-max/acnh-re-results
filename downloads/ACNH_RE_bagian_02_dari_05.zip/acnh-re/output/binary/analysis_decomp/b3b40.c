
long * FUN_001b3b40(undefined8 param_1)

{
  undefined8 *puVar1;
  long *plVar2;
  long lVar3;
  long *plVar4;
  
  puVar1 = puRam00000000033d3ca8;
  plVar4 = (long *)*puRam00000000033d3ca8;
  if (plVar4 == (long *)0x0) {
    plVar4 = (long *)0xe80;
    FUN_01a67780(0xe80,param_1,8);
    FUN_01a83c30(plVar4 + 0x1cc,param_1,3);
    lVar3 = lRam00000000033d4b78;
    plVar2 = plRam00000000033d4b70;
    plVar4[0x1cc] = lRam00000000033d4b68 + 0x10;
    *plVar2 = (long)(plVar4 + 0x1cc);
    *plVar4 = lVar3 + 0x10;
    memset(plVar4 + 1,0,0xe48);
    plVar4[1] = (long)plVar4 + 0x1c;
    plVar4[0xe6] = (long)plVar4 + 0x744;
    *(undefined4 *)(plVar4 + 2) = 0x708;
    *(undefined4 *)(plVar4 + 0xe7) = 0x708;
    *(undefined8 *)((long)plVar4 + 0x14) = 0;
    plVar4[0xe5] = 0x100000000;
    *(undefined8 *)((long)plVar4 + 0x73c) = 0;
    plVar4[0x1ca] = 0x100000000;
    *(undefined1 *)(plVar4 + 0x1cb) = 0;
    *puVar1 = plVar4;
  }
  return plVar4;
}

