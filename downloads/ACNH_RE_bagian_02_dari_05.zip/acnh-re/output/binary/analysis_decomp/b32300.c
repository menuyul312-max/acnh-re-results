
void _INIT_2655(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003655278 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36552b0);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000365527c = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655280 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam0000000003655294 = 0xffff;
  uRam0000000003655290 = 0xffffffff;
  uRam000000000365529c = 0;
  uRam0000000003655298 = 0;
  uRam0000000003655284 = (undefined4)uVar2;
  uRam0000000003655288 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036552a0 = uVar2;
  uRam00000000036552a8 = 0;
  return;
}

