
void FUN_00c1d910(long *param_1,long param_2)

{
  long lVar1;
  
  FUN_0011e3d0();
  lVar1 = lRam00000000033f4da0;
  param_1[0x41] = param_2;
  *param_1 = lVar1 + 0x10;
  FUN_001220b0(param_1 + 0x42);
  param_1[0x47] = 0;
  *(undefined1 *)(param_1 + 0x48) = 0;
  return;
}

