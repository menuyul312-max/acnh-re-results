
void FUN_00c26c40(long *param_1,long param_2)

{
  long lVar1;
  
  FUN_0011e3d0();
  lVar1 = lRam00000000033f4fd0;
  param_1[0x41] = param_2;
  *param_1 = lVar1 + 0x10;
  return;
}

