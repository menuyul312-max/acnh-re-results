
void FUN_00c24540(long param_1)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    return;
  }
  FUN_020067b0(param_1 + 0x40,8);
  return;
}

