
long FUN_00c3b580(void)

{
  long lVar1;
  int iVar2;
  char cVar3;
  char cVar4;
  long *plVar5;
  long lVar6;
  byte *pbVar7;
  ulong uVar8;
  long *plVar9;
  undefined *puVar10;
  
  plVar9 = plRam00000000033f53b8;
  lVar6 = *plRam00000000033f53b8;
  if (lVar6 == 0) {
    FUN_01a8b870();
    FUN_01aa25a0();
    if (*plVar9 == 0) {
      if (((*pbRam00000000033f53c0 & 1) == 0) &&
         (pbVar7 = pbRam00000000033f53c0, __cxa_guard_acquire(), plVar5 = plRam00000000033f53c8,
         (int)pbVar7 != 0)) {
        lVar1 = (long)plRam00000000033f53c8 + 0x14;
        *plRam00000000033f53c8 = lRam00000000033d0670 + 0x10;
        plVar5[1] = lVar1;
        *(undefined4 *)(plVar5 + 2) = 0xda;
        FUN_01a90780(plVar5);
        puVar10 = (undefined *)plVar5[1];
        *plVar5 = lRam00000000033f53d8 + 0x10;
        if (puVar10 != &UNK_02a20a78) {
          cVar3 = *pcRam00000000033d0660;
          uVar8 = 0;
          cVar4 = UNK_02a20a78;
          while (cVar4 != cVar3) {
            if (uVar8 >> 0x13 != 0) {
              uVar8 = 0;
              break;
            }
            if ((&UNK_02a20a79)[uVar8] == cVar3) {
              uVar8 = uVar8 + 1;
              break;
            }
            cVar4 = (&UNK_02a20a7a)[uVar8];
            uVar8 = uVar8 + 2;
          }
          iVar2 = (int)uVar8;
          if ((int)plVar5[2] <= (int)uVar8) {
            iVar2 = (int)plVar5[2] + -1;
          }
          memcpy(puVar10,&UNK_02a20a78,(long)iVar2);
          puVar10[iVar2] = cVar3;
        }
        *plVar5 = lRam00000000033f53e0 + 0x10;
        __cxa_guard_release(pbRam00000000033f53c0);
        plVar9 = plRam00000000033f53b8;
      }
      plVar5 = plRam00000000033f53c8;
      (**(code **)(*plRam00000000033f53c8 + 0x18))(plRam00000000033f53c8);
      lVar1 = lRam00000000033f53d0;
      FUN_01a8b970(lRam00000000033f53d0,plVar5[1],0xd);
      *plVar9 = lVar1;
    }
    FUN_01aa25c0(lVar6);
    lVar6 = *plVar9;
  }
  return lVar6;
}

