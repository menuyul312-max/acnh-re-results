
void FUN_00c2aa80(long *param_1)

{
  *param_1 = lRam00000000033f5198 + 0x10;
  FUN_00c0dad0(param_1 + 0xc);
  FUN_00c2e1f0(param_1);
  return;
}

