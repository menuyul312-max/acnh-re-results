
void FUN_00c2bd60(long param_1)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  ulong uVar4;
  
  if (*(int *)(param_1 + 0x28) == 3) {
    plVar2 = *(long **)(param_1 + 0x20);
    (**(code **)(*plVar2 + 0xe8))();
    if (((ulong)plVar2 & 1) != 0) {
      *(undefined4 *)(param_1 + 0x28) = 0;
    }
  }
  else if (*(int *)(param_1 + 0x28) == 1) {
    plVar2 = *(long **)(param_1 + 0x20);
    (**(code **)(*plVar2 + 0xe0))();
    if (((ulong)plVar2 & 1) != 0) {
      *(undefined4 *)(param_1 + 0x28) = 2;
      lVar3 = *(long *)(param_1 + 8);
      iVar1 = *(int *)(lVar3 + 8);
      goto joined_r0x00c2bdd8;
    }
  }
  lVar3 = *(long *)(param_1 + 8);
  iVar1 = *(int *)(lVar3 + 8);
joined_r0x00c2bdd8:
  if (iVar1 == 1) {
    (*pcRam00000000031cee38)(lVar3 + (lRam00000000031cee40 >> 1));
  }
  FUN_00beaca0(*(undefined8 *)(param_1 + 0x10));
  uVar4 = (ulong)*(uint *)(*(long *)(param_1 + 0x18) + 8);
  if ((uVar4 | 2) == 3) {
    lVar3 = uVar4 * 0x10;
                    /* WARNING: Could not recover jumptable at 0x00c2be2c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(lVar3 + 0x31cee88))
              (*(long *)(param_1 + 0x18) + (*(long *)(lVar3 + 0x31cee90) >> 1));
    return;
  }
  return;
}

