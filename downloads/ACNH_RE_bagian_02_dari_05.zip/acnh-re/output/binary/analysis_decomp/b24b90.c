
long FUN_00c24b90(long param_1)

{
  return param_1 + 200;
}

