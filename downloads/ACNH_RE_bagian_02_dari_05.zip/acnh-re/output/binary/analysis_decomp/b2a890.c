
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00c2a890(void)

{
  int iVar1;
  
  iVar1 = (int)*puRam00000000033d2050;
  FUN_001c5ff0();
  if (iVar1 == 0 || iVar1 == 9) {
    return _UNK_02ad5c2c;
  }
  return *(undefined4 *)(&UNK_02ad50b8 + (ulong)(iVar1 == 10) * 4);
}

