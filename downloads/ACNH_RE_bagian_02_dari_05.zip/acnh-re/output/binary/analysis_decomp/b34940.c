
void FUN_00c34940(long *param_1,long param_2)

{
  long lVar1;
  ulong uVar2;
  undefined4 auStack_40 [2];
  long lStack_38;
  
  lVar1 = lRam00000000033d5200 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0xb);
  uVar2 = (long)param_1 + 0xf6U;
  if ((long)param_1 + 0xf6U <= (long)param_1 + 0xe2U) {
    uVar2 = (long)param_1 + 0xe2U;
  }
  *param_1 = lVar1;
  *(undefined8 *)((long)param_1 + 0xee) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  memset(param_1 + 0x1c,0,(uVar2 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  lStack_38 = param_2 + 0x20;
  auStack_40[0] = 10;
  FUN_010e4670(param_1,auStack_40);
  FUN_001234f0(param_1);
  FUN_00121d40();
  return;
}

