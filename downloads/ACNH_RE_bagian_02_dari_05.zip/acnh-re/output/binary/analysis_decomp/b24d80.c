
void FUN_00c24d80(long param_1)

{
  FUN_00c1c540(*(undefined8 *)(param_1 + 0x10));
  return;
}

