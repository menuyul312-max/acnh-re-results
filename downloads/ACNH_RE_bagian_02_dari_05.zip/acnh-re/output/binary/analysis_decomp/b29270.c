
undefined8 * FUN_00c29270(long param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)(param_1 + 0x148);
  puVar1 = puVar2;
  (**(code **)(*(long *)(param_1 + 0x148) + 0x10))();
  if (((ulong)puVar1 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00c292b0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*puVar2)(puVar2,param_2);
    return puVar2;
  }
  return (undefined8 *)0x1;
}

