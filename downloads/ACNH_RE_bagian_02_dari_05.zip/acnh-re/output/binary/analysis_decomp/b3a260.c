
void FUN_00c3a260(ulong param_1,long *param_2,long param_3)

{
  undefined8 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  uint uVar4;
  undefined8 uVar5;
  long *plVar6;
  undefined8 *puVar7;
  long lVar8;
  long lVar9;
  ulong uVar10;
  ulong uVar11;
  uint *puVar12;
  code *pcVar13;
  uint *puVar14;
  ulong uVar15;
  uint uVar16;
  long lVar17;
  ulong uVar18;
  uint uVar19;
  long lVar20;
  long *plVar21;
  uint *puVar22;
  long lVar23;
  int iVar24;
  int iVar25;
  undefined8 uStack_70;
  long *plStack_68;
  
  lVar17 = *(long *)(param_1 + 0x10);
  (**(code **)(*param_2 + 0x18))(param_2);
  lVar20 = param_2[1];
  if (lVar17 != lVar20) {
    (**(code **)(*param_2 + 0x18))(param_2);
    cVar3 = *pcRam00000000033d0660;
    lVar9 = 0;
    do {
      if (*(char *)(param_2[1] + lVar9) == cVar3) goto LAB_00c3a320;
      lVar23 = param_2[1] + lVar9;
      if (*(char *)(lVar23 + 1) == cVar3) {
        lVar9 = lVar9 + 1;
        goto LAB_00c3a320;
      }
      if (*(char *)(lVar23 + 2) == cVar3) {
        lVar9 = lVar9 + 2;
        goto LAB_00c3a320;
      }
      uVar18 = lVar9 + 2;
      lVar9 = lVar9 + 3;
    } while (uVar18 >> 0x13 == 0);
    lVar9 = 0;
LAB_00c3a320:
    iVar24 = (int)lVar9;
    if (*(int *)(param_1 + 0x18) <= (int)lVar9) {
      iVar24 = *(int *)(param_1 + 0x18) + -1;
    }
    memcpy(lVar17,lVar20,(long)iVar24);
    *(char *)(lVar17 + iVar24) = cVar3;
  }
  (**(code **)(*(long *)(param_1 + 8) + 0x18))(param_1 + 8);
  uVar5 = *(undefined8 *)(param_1 + 0x10);
  FUN_00101bf0(uVar5,0);
  *(int *)(param_1 + 0xa0) = (int)uVar5;
  lVar17 = param_3;
  if (param_3 == 0) {
    lVar17 = *plRam00000000033d08a8;
    FUN_01a89270();
    if (lVar17 != 0) goto LAB_00c3a388;
    lVar20 = 1;
  }
  else {
LAB_00c3a388:
    lVar20 = *plRam00000000033d08a8;
    FUN_01a892c0(lVar20,lVar17);
  }
  *(undefined4 *)(param_1 + 0x1c0) = 0xffffffff;
  uVar18 = param_1;
  FUN_01766670();
  if (uVar18 == 0) {
    uVar18 = 0;
    lVar9 = *(long *)(puRam00000000033f5338 + 2);
    puVar12 = puRam00000000033f5338;
  }
  else {
    FUN_01765e30();
    uVar18 = uVar18 & 0xffffffff;
    lVar9 = *(long *)(puRam00000000033f5338 + 2);
    puVar12 = puRam00000000033f5338;
  }
  puRam00000000033f5338 = puVar12;
  if (lVar9 != 0) {
    _ZdaPv();
    puVar12[2] = 0;
    puVar12[3] = 0;
    *puVar12 = 0;
  }
  uVar16 = (uint)uVar18;
  uVar19 = uVar16;
  if (uVar16 == 0) {
    FUN_00c3ac50(param_1);
    if (-1 < (int)*(uint *)(param_1 + 400)) {
      uVar19 = *(uint *)(param_1 + 400);
    }
  }
  else {
    if ((int)uVar16 < 1) {
LAB_00c3a418:
      uVar10 = (ulong)*puVar12;
      if (0 < (int)*puVar12) goto LAB_00c3a424;
    }
    else {
      uVar10 = (ulong)(int)uVar16;
      lVar9 = uVar10 * 2;
      if (CARRY8(uVar10,uVar10)) {
        lVar9 = -1;
      }
      FUN_01a67940(lVar9,lVar17,8,uRam00000000033d1060);
      if (lVar9 == 0) goto LAB_00c3a418;
      *puVar12 = uVar16;
      *(long *)(puVar12 + 2) = lVar9;
      uVar10 = uVar18;
LAB_00c3a424:
      uVar11 = uVar10 & 3;
      if (uVar10 - 1 < 3) {
        lVar9 = 0;
      }
      else {
        lVar9 = 0;
        do {
          lVar23 = lVar9 * 2;
          lVar9 = lVar9 + 4;
          *(undefined2 *)(*(long *)(puVar12 + 2) + lVar23) = 0;
          *(undefined2 *)(*(long *)(puVar12 + 2) + lVar23 + 2) = 0;
          *(undefined2 *)(*(long *)(puVar12 + 2) + lVar23 + 4) = 0;
          *(undefined2 *)(*(long *)(puVar12 + 2) + lVar23 + 6) = 0;
        } while (uVar10 - uVar11 != lVar9);
      }
      if (uVar11 != 0) {
        lVar9 = lVar9 << 1;
        lVar23 = -uVar11;
        do {
          *(undefined2 *)(*(long *)(puVar12 + 2) + lVar9) = 0;
          lVar9 = lVar9 + 2;
          lVar23 = lVar23 + 1;
        } while (lVar23 != 0);
      }
    }
    FUN_00c3ac50(param_1);
    if (0 < (int)uVar16) {
      lVar9 = (long)(int)uVar16;
      FUN_01a67940(lVar9,lVar17,8,uRam00000000033d1060);
      if (lVar9 != 0) {
        *(uint *)(param_1 + 200) = uVar16;
        *(long *)(param_1 + 0xd0) = lVar9;
      }
    }
    uVar4 = *(uint *)(param_1 + 200);
    uVar10 = (ulong)uVar4;
    if (0 < (int)uVar4) {
      if (uVar10 - 1 < 3) {
        lVar9 = 0;
      }
      else {
        lVar9 = 0;
        do {
          *(undefined1 *)(*(long *)(param_1 + 0xd0) + lVar9) = 1;
          *(undefined1 *)(*(long *)(param_1 + 0xd0) + lVar9 + 1) = 1;
          *(undefined1 *)(*(long *)(param_1 + 0xd0) + lVar9 + 2) = 1;
          lVar23 = *(long *)(param_1 + 0xd0) + lVar9;
          lVar9 = lVar9 + 4;
          *(undefined1 *)(lVar23 + 3) = 1;
        } while (uVar10 - (uVar10 & 3) != lVar9);
      }
      if ((uVar4 & 3) != 0) {
        lVar23 = -(uVar10 & 3);
        do {
          *(undefined1 *)(*(long *)(param_1 + 0xd0) + lVar9) = 1;
          lVar9 = lVar9 + 1;
          lVar23 = lVar23 + 1;
        } while (lVar23 != 0);
      }
    }
    plVar21 = (long *)(param_1 + 0xf8);
    plVar6 = plVar21;
    (**(code **)(*plVar21 + 0x10))();
    if (((ulong)plVar6 & 1) != 0) {
      uVar4 = 0;
      do {
        uVar10 = param_1;
        FUN_00c38330(param_1,uVar4);
        if ((uVar10 == 0) ||
           (plVar6 = plVar21, (**(code **)*plVar21)(plVar21,uVar10), ((ulong)plVar6 & 1) == 0)) {
          puVar2 = *(undefined1 **)(param_1 + 0xd0) + (int)uVar4;
          if (*(uint *)(param_1 + 200) <= uVar4) {
            puVar2 = *(undefined1 **)(param_1 + 0xd0);
          }
          *puVar2 = 0;
        }
        uVar4 = uVar4 + 1;
      } while (uVar16 != uVar4);
    }
    if ((int)uVar16 <= (int)*(uint *)(param_1 + 400)) {
      uVar19 = *(uint *)(param_1 + 400);
    }
  }
  if (uVar19 != 0) {
    if (0 < (int)uVar19) {
      uVar10 = -(ulong)(uVar19 >> 0x1f) & 0xfffffff800000000 | (ulong)uVar19 << 3;
      if ((ulong)(long)(int)uVar19 >> 0x3d != 0) {
        uVar10 = 0xffffffffffffffff;
      }
      FUN_01a67940(uVar10,lVar17,8,uRam00000000033d1060);
      if (uVar10 != 0) {
        *(uint *)(param_1 + 0x1b0) = uVar19;
        *(ulong *)(param_1 + 0x1b8) = uVar10;
      }
    }
    uVar4 = *(uint *)(param_1 + 0x1b0);
    uVar10 = (ulong)uVar4;
    if (0 < (int)uVar4) {
      if (uVar10 - 1 < 3) {
        lVar9 = 0;
      }
      else {
        lVar9 = 0;
        do {
          lVar23 = lVar9 * 8;
          lVar9 = lVar9 + 4;
          *(undefined8 *)(*(long *)(param_1 + 0x1b8) + lVar23) = 0;
          *(undefined8 *)(*(long *)(param_1 + 0x1b8) + lVar23 + 8) = 0;
          *(undefined8 *)(*(long *)(param_1 + 0x1b8) + lVar23 + 0x10) = 0;
          *(undefined8 *)(*(long *)(param_1 + 0x1b8) + lVar23 + 0x18) = 0;
        } while (uVar10 - (uVar10 & 3) != lVar9);
      }
      if ((uVar4 & 3) != 0) {
        lVar9 = lVar9 << 3;
        lVar23 = -(uVar10 & 3);
        do {
          *(undefined8 *)(*(long *)(param_1 + 0x1b8) + lVar9) = 0;
          lVar9 = lVar9 + 8;
          lVar23 = lVar23 + 1;
        } while (lVar23 != 0);
      }
    }
    *(undefined4 *)(param_1 + 0x1c0) = 0xffffffff;
    if (0 < (int)uVar19) {
      uVar10 = (ulong)(int)uVar19;
      lVar9 = uVar10 * 2;
      if (CARRY8(uVar10,uVar10)) {
        lVar9 = -1;
      }
      FUN_01a67940(lVar9,lVar17,8,uRam00000000033d1060);
      if (lVar9 != 0) {
        *(uint *)(param_1 + 0x1c8) = uVar19;
        *(long *)(param_1 + 0x1d0) = lVar9;
      }
    }
    uVar19 = *(uint *)(param_1 + 0x1c8);
    uVar10 = (ulong)uVar19;
    if (0 < (int)uVar19) {
      if (uVar10 - 1 < 3) {
        lVar17 = 0;
      }
      else {
        lVar17 = 0;
        do {
          lVar9 = lVar17 * 2;
          lVar17 = lVar17 + 4;
          *(undefined2 *)(*(long *)(param_1 + 0x1d0) + lVar9) = 0xffff;
          *(undefined2 *)(*(long *)(param_1 + 0x1d0) + lVar9 + 2) = 0xffff;
          *(undefined2 *)(*(long *)(param_1 + 0x1d0) + lVar9 + 4) = 0xffff;
          *(undefined2 *)(*(long *)(param_1 + 0x1d0) + lVar9 + 6) = 0xffff;
        } while (uVar10 - (uVar10 & 3) != lVar17);
      }
      if ((uVar19 & 3) != 0) {
        lVar17 = lVar17 << 1;
        lVar9 = -(uVar10 & 3);
        do {
          *(undefined2 *)(*(long *)(param_1 + 0x1d0) + lVar17) = 0xffff;
          lVar17 = lVar17 + 2;
          lVar9 = lVar9 + 1;
        } while (lVar9 != 0);
      }
    }
  }
  if ((uVar16 == 0) || (*(long *)(param_1 + 0x1a8) == 0)) {
    puVar1 = (undefined8 *)(param_1 + 0x118);
    puVar7 = puVar1;
    (**(code **)(*(long *)(param_1 + 0x118) + 0x10))();
    if ((((ulong)puVar7 & 1) == 0) ||
       ((uVar16 == 0 || ((*(ulong *)(param_1 + 0x1a0) & 1) == 0 && *(long *)(param_1 + 0x198) == 0))
       )) {
      if (uVar16 != 0) {
        uVar4 = 0;
        uVar19 = 0;
        do {
          uVar18 = param_1;
          FUN_00c38330(param_1,uVar4);
          if (uVar18 != 0) {
            lVar17 = (long)(int)uVar19;
            if (*(uint *)(param_1 + 0x1b0) <= uVar19) {
              lVar17 = 0;
            }
            lVar9 = (long)(int)uVar4;
            *(ulong *)(*(long *)(param_1 + 0x1b8) + lVar17 * 8) = uVar18;
            if (*(uint *)(param_1 + 0x1c8) <= uVar4) {
              lVar9 = 0;
            }
            *(short *)(*(long *)(param_1 + 0x1d0) + lVar9 * 2) = (short)uVar19;
            uVar19 = uVar19 + 1;
          }
          uVar4 = uVar4 + 1;
        } while (uVar16 != uVar4);
        *(uint *)(param_1 + 0x1c0) = uVar19;
        (**(code **)(*(long *)(param_1 + 0xf8) + 0x10))((long *)(param_1 + 0xf8));
      }
    }
    else {
      uVar19 = 0;
      lVar17 = lRam00000000033d0668 + 0x10;
      do {
        uVar18 = param_1;
        FUN_00c38330(param_1,uVar19);
        if (uVar18 != 0) {
          pcVar13 = *(code **)(param_1 + 0x198);
          plVar6 = (long *)(uVar18 + ((long)*(ulong *)(param_1 + 0x1a0) >> 1));
          if ((*(ulong *)(param_1 + 0x1a0) & 1) != 0) {
            pcVar13 = *(code **)(pcVar13 + *plVar6);
          }
          (*pcVar13)();
          if (plVar6 != (long *)0x0) {
            puVar7 = puVar1;
            uStack_70 = lVar17;
            plStack_68 = plVar6;
            (**(code **)*puVar1)(puVar1,&uStack_70);
            uVar4 = (uint)puVar7;
            if (-1 < (int)uVar4) {
              lVar9 = (long)(int)uVar4;
              if (*(uint *)(param_1 + 0x1b0) <= uVar4) {
                lVar9 = 0;
              }
              lVar23 = (long)(int)uVar19;
              *(ulong *)(*(long *)(param_1 + 0x1b8) + lVar9 * 8) = uVar18;
              if (*(uint *)(param_1 + 0x1c8) <= uVar19) {
                lVar23 = 0;
              }
              *(short *)(*(long *)(param_1 + 0x1d0) + lVar23 * 2) = (short)puVar7;
            }
          }
        }
        uVar19 = uVar19 + 1;
      } while (uVar16 != uVar19);
      *(undefined4 *)(param_1 + 0x1c0) = *(undefined4 *)(param_1 + 400);
    }
    goto joined_r0x00c3a8f8;
  }
  uStack_70 = 0;
  plStack_68 = (long *)0x0;
  if ((int)uVar16 < 1) {
    puVar12 = (uint *)0x0;
LAB_00c3a980:
    puVar22 = (uint *)0x0;
    uVar11 = 0;
  }
  else {
    uVar10 = (ulong)(int)uVar16;
    puVar12 = (uint *)(-(uVar18 >> 0x1f) & 0xfffffff000000000 | uVar18 << 4);
    if (uVar10 >> 0x3c != 0) {
      puVar12 = (uint *)0xffffffffffffffff;
    }
    FUN_01a67940(puVar12,param_3,8,uRam00000000033d1060);
    if (puVar12 == (uint *)0x0) goto LAB_00c3a980;
    uVar15 = uVar10 * 0x10 - 0x10;
    uVar19 = ((uint)(uVar15 >> 4) & 0xfffffff) + 1;
    puVar14 = puVar12;
    if ((uVar19 & 3) != 0) {
      lVar17 = -((ulong)uVar19 & 3);
      do {
        *puVar14 = 0;
        puVar14[2] = 0;
        puVar14[3] = 0;
        puVar14 = puVar14 + 4;
        lVar17 = lVar17 + 1;
      } while (lVar17 != 0);
    }
    puVar22 = puVar12;
    uVar11 = uVar18;
    if (0x2f < uVar15) {
      do {
        *puVar14 = 0;
        puVar14[2] = 0;
        puVar14[3] = 0;
        puVar14[4] = 0;
        puVar14[6] = 0;
        puVar14[7] = 0;
        puVar14[8] = 0;
        puVar14[10] = 0;
        puVar14[0xb] = 0;
        puVar14[0xc] = 0;
        puVar14[0xe] = 0;
        puVar14[0xf] = 0;
        puVar14 = puVar14 + 0x10;
      } while (puVar14 != puVar12 + uVar10 * 4);
    }
  }
  FUN_01a68080(&uStack_70,uVar18,param_3,8);
  uVar19 = 0;
  do {
    uVar18 = param_1;
    FUN_00c38330(param_1,uVar19);
    plVar6 = plStack_68;
    if (uVar18 != 0) {
      puVar14 = puVar22 + (long)(int)uVar19 * 4;
      if ((uint)uVar11 <= uVar19) {
        puVar14 = puVar22;
      }
      *puVar14 = uVar19;
      *(ulong *)(puVar14 + 2) = uVar18;
      if ((int)(uint)uStack_70 < uStack_70._4_4_) {
        plStack_68[(int)(uint)uStack_70] = (long)puVar14;
        uStack_70 = CONCAT44(uStack_70._4_4_,(uint)uStack_70 + 1);
      }
    }
    uVar19 = uVar19 + 1;
  } while (uVar16 != uVar19);
  if (1 < (int)(uint)uStack_70) {
    iVar25 = 0;
    iVar24 = (uint)uStack_70 + -1;
    do {
      if (iVar24 <= iVar25) break;
      lVar23 = (long)iVar25;
      lVar9 = (long)iVar24;
      plVar21 = plVar6 + (long)iVar25 + 1;
      lVar17 = 0;
      iVar24 = iVar25;
      do {
        lVar8 = plVar21[-1];
        (**(code **)(param_1 + 0x1a8))(lVar8,*plVar21);
        if (0 < (int)lVar8) {
          lVar8 = plVar21[-1];
          iVar24 = iVar25 + (int)lVar17;
          plVar21[-1] = *plVar21;
          *plVar21 = lVar8;
        }
        lVar17 = lVar17 + 1;
        plVar21 = plVar21 + 1;
      } while (lVar9 - lVar23 != lVar17);
      if (iVar24 <= iVar25) break;
      plVar21 = plVar6 + iVar24;
      lVar17 = 0;
      iVar25 = iVar24;
      do {
        lVar9 = *plVar21;
        (**(code **)(param_1 + 0x1a8))(lVar9,plVar21[-1]);
        if ((int)lVar9 < 0) {
          lVar9 = plVar21[-1];
          iVar25 = iVar24 + (int)lVar17;
          plVar21[-1] = *plVar21;
          *plVar21 = lVar9;
        }
        lVar17 = lVar17 + -1;
        plVar21 = plVar21 + -1;
      } while (lVar23 < iVar24 + lVar17);
    } while (iVar25 != iVar24);
  }
  if ((uint)uStack_70 == 0) {
    *(undefined4 *)(param_1 + 0x1c0) = 0;
    FUN_01a68150(&uStack_70);
  }
  else {
    uVar18 = 0;
    do {
      uVar10 = -(uVar18 >> 0x1f) & 0xfffffff800000000 | uVar18 << 3;
      puVar1 = (undefined8 *)((long)*(undefined8 **)(param_1 + 0x1b8) + uVar10);
      if (*(uint *)(param_1 + 0x1b0) <= (uint)uVar18) {
        puVar1 = *(undefined8 **)(param_1 + 0x1b8);
      }
      *puVar1 = *(undefined8 *)(*(long *)((long)plStack_68 + uVar10) + 8);
      lVar17 = (long)(int)**(uint **)((long)plStack_68 + uVar10);
      if (*(uint *)(param_1 + 0x1c8) <= **(uint **)((long)plStack_68 + uVar10)) {
        lVar17 = 0;
      }
      *(short *)(*(long *)(param_1 + 0x1d0) + lVar17 * 2) = (short)uVar18;
      uVar19 = (uint)uVar18 + 1;
      uVar18 = (ulong)uVar19;
    } while (uVar19 < (uint)uStack_70);
    *(uint *)(param_1 + 0x1c0) = (uint)uStack_70;
    FUN_01a68150(&uStack_70);
  }
  if (puVar22 != (uint *)0x0) {
    _ZdaPv(puVar12);
  }
joined_r0x00c3a8f8:
  if (lVar20 != 1) {
    FUN_01a892c0(*plRam00000000033d08a8,lVar20);
  }
  return;
}

