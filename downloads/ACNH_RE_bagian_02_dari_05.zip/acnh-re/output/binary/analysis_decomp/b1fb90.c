
void FUN_00c1fb90(long param_1)

{
  FUN_00c18d90(param_1 + 0x1880);
  FUN_00c18d90(param_1 + 0x38);
  return;
}

