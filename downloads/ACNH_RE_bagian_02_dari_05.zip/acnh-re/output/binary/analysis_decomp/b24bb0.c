
void FUN_00c24bb0(undefined8 *param_1)

{
  if (param_1[0x17] != 0) {
    FUN_00c28f90();
  }
  FUN_00c23db0(param_1 + 0x19);
  if (param_1[0x17] == 0) {
    if (param_1[0x18] != 0) {
      param_1[0x18] = 0;
    }
  }
  else {
    FUN_00c28d00();
  }
  FUN_00c2e250(param_1 + 0x2e);
  FUN_00c2b070(*param_1);
  FUN_00c2be90(param_1[4]);
  FUN_00c27a00(param_1[5]);
  FUN_0011e470(param_1[6]);
  FUN_00bf3100(param_1[3]);
  FUN_00c24660(param_1);
  return;
}

