
void FUN_00c345f0(long *param_1)

{
  long lVar1;
  ulong uVar2;
  
  lVar1 = lRam00000000033d5200 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0xb);
  *param_1 = lVar1;
  *(undefined8 *)((long)param_1 + 0xee) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uVar2 = (long)param_1 + 0xf6U;
  if ((long)param_1 + 0xf6U <= (long)param_1 + 0xe2U) {
    uVar2 = (long)param_1 + 0xe2U;
  }
  memset(param_1 + 0x1c,0,(uVar2 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  return;
}

