
void FUN_00c352c0(long *param_1)

{
  *param_1 = lRam00000000033f5280 + 0x10;
  FUN_001237f0(param_1 + 1);
  return;
}

