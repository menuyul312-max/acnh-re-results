
void _INIT_2638(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam00000000036543a0 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36543d8);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam00000000036543a4 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam00000000036543a8 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036543bc = 0xffff;
  uRam00000000036543b8 = 0xffffffff;
  uRam00000000036543c4 = 0;
  uRam00000000036543c0 = 0;
  uRam00000000036543ac = (undefined4)uVar2;
  uRam00000000036543b0 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036543c8 = uVar2;
  uRam00000000036543d0 = 0;
  return;
}

