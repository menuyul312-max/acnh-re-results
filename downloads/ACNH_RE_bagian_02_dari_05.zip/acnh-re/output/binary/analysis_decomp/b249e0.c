
uint FUN_00c249e0(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  undefined1 *puVar1;
  undefined1 auStack_7198 [12536];
  undefined1 auStack_40a0 [112];
  undefined1 auStack_4030 [16384];
  
  memset(auStack_4030,0,0x4000);
  FUN_00c0da50(auStack_40a0);
  FUN_00c0dc70(auStack_40a0,param_3);
  FUN_00c1f510(auStack_7198,param_1,param_2,auStack_40a0,auStack_4030);
  puVar1 = auStack_7198;
  FUN_00c1f6c0(puVar1);
  FUN_00c1f6b0(auStack_7198);
  FUN_00c0dad0(auStack_40a0);
  return (uint)puVar1 & 1;
}

