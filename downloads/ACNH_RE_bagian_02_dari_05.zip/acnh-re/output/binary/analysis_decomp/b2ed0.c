
undefined4 * FUN_001b2ed0(void)

{
  undefined4 *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  
  if ((*pbRam00000000033d4b10 & 1) == 0) {
    pbVar2 = pbRam00000000033d4b10;
    __cxa_guard_acquire();
    puVar1 = puRam00000000033d4b18;
    if ((int)pbVar2 != 0) {
      *puRam00000000033d4b18 = 0;
      *(undefined8 *)(puVar1 + 2) = 0;
      FUN_01a8b8f0();
      FUN_01aa25a0();
      if (*(long *)(puVar1 + 2) == 0) {
        if ((*pbRam00000000033d4b20 & 1) == 0) {
          pbVar3 = pbRam00000000033d4b20;
          __cxa_guard_acquire();
          if ((int)pbVar3 != 0) {
            *puRam00000000033d4b28 = 0x900000005;
            __cxa_guard_release(pbRam00000000033d4b20);
          }
        }
        *puVar1 = 2;
        *(undefined8 **)(puVar1 + 2) = puRam00000000033d4b28;
      }
      FUN_01aa25c0(pbVar2);
      __cxa_guard_release(pbRam00000000033d4b10);
    }
  }
  return puRam00000000033d4b18;
}

