
long FUN_00c35050(long param_1)

{
  return param_1 + 8;
}

