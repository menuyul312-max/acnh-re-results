
void FUN_001b22b0(long *param_1)

{
  undefined8 *puVar1;
  long *plVar2;
  
  puVar1 = puRam00000000033d4af0;
  *param_1 = lRam00000000033d4ae8 + 0x10;
  if ((long *)*puVar1 != param_1) {
    FUN_01a83cd0(param_1);
    return;
  }
  *puVar1 = 0;
  puVar1 = puRam00000000033d1a40;
  plVar2 = (long *)*puRam00000000033d1a40;
  *plVar2 = lRam00000000033d4af8 + 0x10;
  FUN_01aa2520(plVar2 + 0x326);
  *puVar1 = 0;
  FUN_01a83cd0(param_1);
  return;
}

