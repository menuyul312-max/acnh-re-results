
void FUN_00c277b0(long param_1,undefined8 param_2)

{
  FUN_00bee380(param_1 + 0xbe0,param_1 + 0x6f8,param_2);
  return;
}

