
void FUN_00c2a580(undefined8 *param_1)

{
  undefined8 uVar1;
  
  *param_1 = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  uVar1 = 0x10;
  _Znwm();
  FUN_0175b320();
  param_1[2] = uVar1;
  return;
}

