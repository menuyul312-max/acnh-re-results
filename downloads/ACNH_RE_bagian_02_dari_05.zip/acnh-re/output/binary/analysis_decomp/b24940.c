
void FUN_00c24940(long param_1)

{
  *(undefined4 *)(param_1 + 0x246f) = 0;
  *(bool *)(param_1 + 0x2472) = *(int *)(param_1 + 0x48) == 7;
  return;
}

