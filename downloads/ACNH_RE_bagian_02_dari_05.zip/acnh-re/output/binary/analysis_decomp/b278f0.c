
long FUN_00c278f0(long param_1)

{
  return param_1 + 0x218;
}

