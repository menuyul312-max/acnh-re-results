
void FUN_00c321d0(long *param_1,undefined8 param_2)

{
  long lVar1;
  ulong uVar2;
  
  lVar1 = lRam00000000033f5248 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0x15);
  uVar2 = (long)param_1 + 0x10aU;
  if ((long)param_1 + 0x10aU <= (long)param_1 + 0xe2U) {
    uVar2 = (long)param_1 + 0xe2U;
  }
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  *param_1 = lVar1;
  *(undefined2 *)(param_1 + 0x21) = 0;
  param_1[0x1c] = 0;
  memset(param_1 + 0x1c,0,(uVar2 - (long)param_1) - 0xdf & 0xfffffffffffffffe);
  FUN_00123cc0(param_1,param_2);
  return;
}

