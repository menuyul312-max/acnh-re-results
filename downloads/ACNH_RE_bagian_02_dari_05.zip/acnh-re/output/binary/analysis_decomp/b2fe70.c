
void FUN_00c2fe70(long param_1,undefined8 param_2,int param_3,undefined8 param_4,int param_5)

{
  ulong uVar1;
  uint uVar2;
  short sVar3;
  ulong uVar4;
  
  if (*(long *)(param_1 + 0x18) != 0) {
    uVar4 = *(ulong *)(param_1 + 0x20);
    uVar2 = param_5 + 6U + param_3;
    uVar1 = *(long *)(param_1 + 0x18) + (ulong)uVar2 * 2;
    FUN_001233a0(param_2);
    FUN_001233a0(param_4);
    if (uVar4 < uVar1) {
      *(undefined1 *)(param_1 + 0x28) = 0;
    }
    else {
      **(undefined2 **)(param_1 + 0x18) = 0xe;
      *(undefined2 *)(*(long *)(param_1 + 0x18) + 2) = 199;
      *(undefined2 *)(*(long *)(param_1 + 0x18) + 4) = 1;
      sVar3 = (short)(param_5 * 2);
      *(short *)(*(long *)(param_1 + 0x18) + 6) = sVar3 + 4;
      *(short *)(*(long *)(param_1 + 0x18) + 8) = (short)(param_3 << 1);
      *(short *)(*(long *)(param_1 + 0x18) + 10) = sVar3;
      memcpy(*(long *)(param_1 + 0x18) + 0xc,param_4,param_5 * 2);
      memcpy(*(long *)(param_1 + 0x18) + (ulong)(param_5 + 6U) * 2,param_2,param_3 << 1);
      *(ulong *)(param_1 + 0x18) = uVar1;
      *(uint *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + uVar2;
    }
  }
  return;
}

