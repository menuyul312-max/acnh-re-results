
void FUN_00c295d0(long param_1,long *param_2)

{
  bool bVar1;
  uint uVar2;
  char cVar3;
  ushort uVar4;
  char *pcVar5;
  long *plVar6;
  ulong *puVar7;
  long lVar8;
  uint uVar9;
  char *pcVar10;
  ulong uVar11;
  ulong uVar12;
  uint uVar13;
  long lVar14;
  ulong uStack_148;
  long *plStack_140;
  undefined8 uStack_138;
  char *pcStack_130;
  ulong uStack_128;
  char *pcStack_120;
  ulong uStack_118;
  char *pcStack_110;
  ulong uStack_108;
  char *pcStack_100;
  undefined8 uStack_f8;
  ulong uStack_f0;
  char *pcStack_e8;
  ulong uStack_e0;
  undefined *puStack_d8;
  long lStack_d0;
  ulong uStack_c8;
  char *pcStack_c0;
  ulong uStack_b8;
  char *pcStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  ulong uStack_98;
  undefined *puStack_90;
  ulong uStack_88;
  char *pcStack_80;
  undefined8 uStack_78;
  int iStack_6c;
  
  plVar6 = param_2;
  FUN_00e340b0();
  lVar8 = lRam00000000033d0668;
  pcVar5 = pcRam00000000033d0660;
  iStack_6c = (int)plVar6;
  uVar11 = lRam00000000033d0668 + 0x10;
  pcStack_c0 = pcRam00000000033d0660;
  pcStack_b0 = pcRam00000000033d0660;
  uStack_a8 = 0;
  pcStack_80 = pcRam00000000033d0660;
  uStack_78 = 0;
  lStack_d0 = lRam00000000033f5108 + 0x10;
  uStack_a0 = 0;
  puStack_90 = &UNK_02a88a06;
  puStack_d8 = &UNK_02aab671;
  uStack_e0 = uVar11;
  uStack_c8 = uVar11;
  uStack_b8 = uVar11;
  uStack_98 = uVar11;
  uStack_88 = uVar11;
  if (iStack_6c == 1) {
    plStack_140 = (long *)((long)&uStack_138 + 4);
    uStack_148 = lRam00000000033d0670 + 0x10;
    uStack_138 = CONCAT44(uStack_138._4_4_,0x20);
    FUN_01a90780(&uStack_148);
    lVar8 = lRam00000000033d0680;
    cVar3 = *pcVar5;
    *(char *)plStack_140 = cVar3;
    uStack_148 = lVar8 + 0x10;
    puVar7 = &uStack_148;
    FUN_00e35270(puVar7,param_2);
    uVar9 = 0xffffffff;
    uVar13 = 0x23;
    do {
      uVar2 = uVar9 + 1;
      pcVar10 = "";
      if (uVar2 < 0x3d) {
        FUN_00c29f30();
        pcVar10 = (char *)puVar7[(int)uVar2];
      }
      uStack_f0 = uVar11;
      pcStack_e8 = pcVar10;
      (**(code **)(uStack_148 + 0x18))(&uStack_148);
      (**(code **)(uStack_148 + 0x18))(&uStack_148);
      plVar6 = plStack_140;
      puVar7 = &uStack_f0;
      (**(code **)(uStack_f0 + 0x18))();
      if (plVar6 == (long *)pcStack_e8) {
LAB_00c29998:
        uVar13 = 0x23;
        if (uVar9 != 0x16) {
          uVar13 = uVar9;
        }
        uStack_a0 = uStack_a0 & 0xffffffff;
        break;
      }
      uVar12 = 0;
      do {
        if (*(char *)((long)plStack_140 + uVar12) != pcStack_e8[uVar12]) break;
        if (*(char *)((long)plStack_140 + uVar12) == cVar3) goto LAB_00c29998;
        if (*(char *)((long)plStack_140 + uVar12 + 1) != pcStack_e8[uVar12 + 1]) break;
        if (*(char *)((long)plStack_140 + uVar12 + 1) == cVar3) goto LAB_00c29998;
        if (*(char *)((long)plStack_140 + uVar12 + 2) != pcStack_e8[uVar12 + 2]) break;
        if (*(char *)((long)plStack_140 + uVar12 + 2) == cVar3) goto LAB_00c29998;
        uVar12 = uVar12 + 3;
      } while (uVar12 < 0x80001);
      bVar1 = (int)uVar9 < 0x3c;
      uVar9 = 0x3c;
      if (bVar1) {
        uVar9 = uVar2;
      }
    } while (uVar9 != 0x3c);
    uStack_a0 = CONCAT44(uVar13,(undefined4)uStack_a0);
    FUN_01170f10(&uStack_148,0xffffffff,uVar13);
    FUN_01a904f0(&uStack_e0,&uStack_148);
    lVar8 = lRam00000000033d0668;
    goto LAB_00c29a28;
  }
  if (iStack_6c != 0) goto LAB_00c29a28;
  plStack_140 = (long *)((long)&uStack_138 + 4);
  uStack_148 = lRam00000000033d0670 + 0x10;
  uStack_138 = CONCAT44(uStack_138._4_4_,6);
  FUN_01a90780(&uStack_148);
  lVar14 = lRam00000000033d9a38;
  cVar3 = *pcVar5;
  *(char *)plStack_140 = cVar3;
  uStack_148 = lVar14 + 0x10;
  puVar7 = &uStack_148;
  FUN_00e35830(puVar7,param_2);
  uVar9 = 0xffffffff;
  do {
    uVar13 = uVar9 + 1;
    pcVar10 = "";
    if (uVar13 < 0x3d) {
      FUN_00c29f30();
      pcVar10 = (char *)puVar7[(int)uVar13];
    }
    uStack_f0 = lVar8 + 0x10;
    pcStack_e8 = pcVar10;
    (**(code **)(uStack_148 + 0x18))(&uStack_148);
    (**(code **)(uStack_148 + 0x18))(&uStack_148);
    plVar6 = plStack_140;
    puVar7 = &uStack_f0;
    (**(code **)(uStack_f0 + 0x18))();
    if (plVar6 == (long *)pcStack_e8) {
LAB_00c298e8:
      uStack_a0 = CONCAT44(uVar9,(undefined4)uStack_a0);
      break;
    }
    uVar11 = 0;
    do {
      if (*(char *)((long)plStack_140 + uVar11) != pcStack_e8[uVar11]) break;
      if (*(char *)((long)plStack_140 + uVar11) == cVar3) goto LAB_00c298e8;
      if (*(char *)((long)plStack_140 + uVar11 + 1) != pcStack_e8[uVar11 + 1]) break;
      if (*(char *)((long)plStack_140 + uVar11 + 1) == cVar3) goto LAB_00c298e8;
      if (*(char *)((long)plStack_140 + uVar11 + 2) != pcStack_e8[uVar11 + 2]) break;
      if (*(char *)((long)plStack_140 + uVar11 + 2) == cVar3) goto LAB_00c298e8;
      uVar11 = uVar11 + 3;
    } while (uVar11 < 0x80001);
    bVar1 = (int)uVar9 < 0x3c;
    uVar9 = 0x3c;
    if (bVar1) {
      uVar9 = uVar13;
    }
  } while (uVar9 != 0x3c);
  lVar14 = *plRam00000000033d3788;
  (**(code **)(*param_2 + 0x18))(param_2);
  lVar8 = param_2[1];
  FUN_00101bf0(lVar8,0);
  uStack_148 = CONCAT44(uStack_148._4_4_,(int)lVar8);
  FUN_00189ce0(lVar14,&uStack_148);
  lVar8 = lRam00000000033d0668;
  if (lVar14 == 0) goto LAB_00c29a28;
  FUN_01765ea0();
  if ((*puRam00000000033d9910 <= (uint)lVar14) ||
     (uVar4 = *(ushort *)(*(long *)(puRam00000000033d9910 + 2) + (long)(int)(uint)lVar14 * 2),
     uVar9 = (uint)uVar4, 7 < uVar4)) {
    uVar9 = 0;
  }
  uStack_f0 = CONCAT44(uStack_f0._4_4_,uVar9);
  uStack_148 = CONCAT44(uStack_148._4_4_,uVar9);
  switch(uVar9) {
  case 0:
    uVar11 = 0;
    uStack_a0 = (ulong)uStack_a0._4_4_ << 0x20;
    goto LAB_00c29a10;
  case 1:
    uVar11 = 1;
    break;
  case 2:
    uVar11 = 2;
    break;
  case 3:
    uVar11 = 3;
    break;
  case 4:
    uVar11 = 4;
    break;
  case 5:
    uVar11 = 5;
    break;
  case 6:
    uVar11 = 6;
    break;
  case 7:
    uVar11 = 7;
    break;
  default:
    uVar11 = uStack_a0 & 0xffffffff;
    goto LAB_00c29a10;
  }
  uStack_a0 = CONCAT44(uStack_a0._4_4_,(int)uVar11);
LAB_00c29a10:
  FUN_01170f10(&uStack_148,uVar11,uStack_a0._4_4_);
  FUN_01a904f0(&uStack_e0,&uStack_148);
LAB_00c29a28:
  uStack_138 = lVar8 + 0x10;
  plStack_140 = &lStack_d0;
  uStack_148 = uStack_148 & 0xffffffffffff0000;
  pcStack_130 = pcVar5;
  pcStack_120 = pcVar5;
  pcStack_110 = pcVar5;
  pcStack_100 = pcVar5;
  uStack_f8 = 0;
  pcStack_e8 = "DoubutsugoObject";
  uStack_128 = uStack_138;
  uStack_118 = uStack_138;
  uStack_108 = uStack_138;
  uStack_f0 = uStack_138;
  FUN_01a904f0(&uStack_108,&uStack_f0);
  FUN_01a904f0(&uStack_138,&uStack_e0);
  uStack_f8 = 0;
  FUN_01750020(param_1 + 0x168,&uStack_148);
  *(undefined1 *)(param_1 + 0x1a0) = 1;
  return;
}

