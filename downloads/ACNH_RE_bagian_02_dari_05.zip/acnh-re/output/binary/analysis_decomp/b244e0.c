
void FUN_00c244e0(long param_1,undefined8 param_2,byte param_3)

{
  FUN_00c2a9e0(param_1 + 0x170);
  if (*(long *)(param_1 + 0xc0) != 0) {
    FUN_00c28fe0(*(long *)(param_1 + 0xc0),param_1 + 0x170);
  }
  *(byte *)(param_1 + 0x246c) = param_3 & 1;
  FUN_020067b0(param_1 + 0x40,1);
  return;
}

