
bool FUN_001b36f0(long *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  
  pbVar2 = pbRam00000000033d4b50;
  if (((*pbRam00000000033d4b38 & 1) == 0) &&
     (pbVar1 = pbRam00000000033d4b38, __cxa_guard_acquire(), pbVar2 = pbRam00000000033d4b50,
     (int)pbVar1 != 0)) {
    *plRam00000000033d4b40 = lRam00000000033d4b48 + 0x10;
    __cxa_guard_release(pbRam00000000033d4b38);
    pbVar2 = pbRam00000000033d4b50;
  }
  if (param_1 == plRam00000000033d4b40) {
    pbRam00000000033d4b50 = pbVar2;
    return true;
  }
  pbVar1 = pbRam00000000033d0e20;
  pbRam00000000033d4b50 = pbVar2;
  if (((*pbVar2 & 1) == 0) &&
     (__cxa_guard_acquire(), pbVar1 = pbRam00000000033d0e20, (int)pbVar2 != 0)) {
    *plRam00000000033d4b58 = lRam00000000033d0ee8 + 0x10;
    __cxa_guard_release(pbRam00000000033d4b50);
    pbVar1 = pbRam00000000033d0e20;
  }
  if (param_1 == plRam00000000033d4b58) {
    pbRam00000000033d0e20 = pbVar1;
    return true;
  }
  pbRam00000000033d0e20 = pbVar1;
  pbVar2 = pbRam00000000033d0ec8;
  if (((*pbVar1 & 1) == 0) &&
     (__cxa_guard_acquire(), pbVar2 = pbRam00000000033d0ec8, (int)pbVar1 != 0)) {
    *plRam00000000033d0e28 = lRam00000000033d0e60 + 0x10;
    __cxa_guard_release(pbRam00000000033d0e20);
    pbVar2 = pbRam00000000033d0ec8;
  }
  if (param_1 == plRam00000000033d0e28) {
    pbRam00000000033d0ec8 = pbVar2;
    return true;
  }
  pbRam00000000033d0ec8 = pbVar2;
  if (((*pbVar2 & 1) == 0) && (__cxa_guard_acquire(), (int)pbVar2 != 0)) {
    *plRam00000000033d0ed0 = lRam00000000033d0520 + 0x10;
    __cxa_guard_release(pbRam00000000033d0ec8);
  }
  return param_1 == plRam00000000033d0ed0;
}

