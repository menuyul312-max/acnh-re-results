
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00c2a8e0(void)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = (int)*puRam00000000033d2050;
  FUN_001c5ff0();
  if (iVar1 == 0 || iVar1 == 9) {
    return 0x40000000;
  }
  uVar2 = 0x40000000;
  if (iVar1 != 10) {
    uVar2 = _UNK_02ad63a4;
  }
  return uVar2;
}

