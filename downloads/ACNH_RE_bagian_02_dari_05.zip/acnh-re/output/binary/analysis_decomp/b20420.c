
void FUN_00c20420(long param_1,undefined8 param_2)

{
  uint uVar1;
  undefined8 uVar2;
  ulong uVar3;
  ushort *puVar4;
  ushort auStack_b8 [8];
  undefined1 auStack_a8 [116];
  uint uStack_34;
  
  FUN_00122290(param_2);
  uVar2 = param_2;
  FUN_001222a0();
  uVar1 = (uint)uVar2 + 2;
  if (6 < (uint)uVar2) {
    uVar1 = 2;
  }
  FUN_00122470(param_2,auStack_b8,uVar1);
  if (uVar1 != 0) {
    uVar3 = (ulong)uVar1;
    puVar4 = auStack_b8;
    do {
      uStack_34 = (uint)*puVar4;
      FUN_00c0da50(auStack_a8);
      FUN_00c0e090(auStack_a8,&uStack_34,&UNK_02af8de4);
      (*(code *)**(undefined8 **)(param_1 + 8))((undefined8 *)(param_1 + 8),auStack_a8);
      FUN_00c0dad0(auStack_a8);
      uVar3 = uVar3 - 1;
      puVar4 = puVar4 + 1;
    } while (uVar3 != 0);
  }
  return;
}

