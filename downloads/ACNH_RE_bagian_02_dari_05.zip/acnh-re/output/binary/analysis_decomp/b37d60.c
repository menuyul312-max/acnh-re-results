
long * FUN_00c37d60(undefined8 param_1)

{
  int iVar1;
  undefined1 uVar2;
  long lVar3;
  undefined8 *puVar4;
  long lVar5;
  long *plVar6;
  long lVar7;
  undefined8 *puVar8;
  long *plVar9;
  undefined *puVar10;
  
  puVar4 = puRam00000000033d3ef8;
  plVar9 = (long *)*puRam00000000033d3ef8;
  if (plVar9 == (long *)0x0) {
    plVar9 = (long *)0x228;
    FUN_01a67780(0x228,param_1,8);
    FUN_01a83c30(plVar9 + 0x41,param_1,3);
    lVar3 = lRam00000000033f52f0;
    plVar6 = plRam00000000033f52e8;
    plVar9[0x41] = lRam00000000033f52e0 + 0x10;
    *plVar6 = (long)(plVar9 + 0x41);
    *plVar9 = lVar3 + 0x10;
    FUN_01765fe0(plVar9 + 1);
    lVar7 = lRam00000000033f5308;
    lVar3 = lRam00000000033f5300;
    lVar5 = lRam00000000033d4850;
    plVar9[1] = lRam00000000033f52f8 + 0x10;
    plVar9[0x1b] = 0;
    plVar9[0x1c] = lVar3 + 0x10;
    lVar3 = lRam00000000033d0670;
    plVar9[0x20] = lVar7 + 0x10;
    plVar9[0x24] = lVar5 + 0x10;
    *(undefined4 *)(plVar9 + 0x1a) = 0;
    plVar9[0x28] = lVar3 + 0x10;
    plVar9[0x29] = (long)plVar9 + 0x154;
    *(undefined4 *)(plVar9 + 0x2a) = 0x40;
    FUN_01a90780(plVar9 + 0x28);
    puVar10 = (undefined *)plVar9[0x29];
    plVar9[0x28] = lRam00000000033d17a0 + 0x10;
    if (puVar10 != &UNK_02ad4e28) {
      uVar2 = *puRam00000000033d0660;
      iVar1 = 0;
      if ((int)plVar9[0x2a] < 1) {
        iVar1 = (int)plVar9[0x2a] + -1;
      }
      memset(puVar10,0,(long)iVar1);
      puVar10[iVar1] = uVar2;
    }
    plVar9[0x38] = 0;
    lVar3 = lRam00000000033d1298;
    plVar9[0x35] = 0;
    plVar9[0x36] = 0;
    plVar9[0x34] = 0;
    *(undefined4 *)(plVar9 + 0x37) = 0;
    *(undefined4 *)(plVar9 + 0x33) = 0xffffffff;
    *(undefined4 *)(plVar9 + 0x39) = 0xffffffff;
    *(undefined4 *)(plVar9 + 0x3a) = 0;
    plVar9[0x28] = lVar3 + 0x10;
    plVar9[0x3b] = 0;
    *puRam00000000033f5318 = 1;
    puVar8 = puRam00000000033f5320;
    *(undefined4 *)(puRam00000000033f5320 + 2) = 0xffffffff;
    lVar3 = lRam00000000033f5310;
    *puVar8 = 0xffffffffffffffff;
    puVar8[1] = 0xffffffffffffffff;
    *(undefined4 *)(plVar9 + 0x3c) = 0;
    plVar9[1] = lVar3 + 0x10;
    lVar3 = lRam00000000033f5328;
    plVar9[0x3d] = 0;
    plVar9[0x3e] = lVar3;
    *(undefined8 *)((long)plVar9 + 0x1fd) = 0;
    plVar9[0x3f] = 0;
    *puVar4 = plVar9;
  }
  return plVar9;
}

