
void FUN_001b3230(long *param_1)

{
  *param_1 = lRam00000000033d4b30 + 0x10;
  thunk_FUN_01a98760();
  return;
}

