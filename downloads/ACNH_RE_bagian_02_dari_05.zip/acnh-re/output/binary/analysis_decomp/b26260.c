
void FUN_00c26260(long param_1)

{
  FUN_00c2bd30(*(undefined8 *)(param_1 + 0x20));
  return;
}

