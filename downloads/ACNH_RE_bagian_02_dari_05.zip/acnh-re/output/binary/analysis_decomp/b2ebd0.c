
void FUN_00c2ebd0(long *param_1,long param_2)

{
  uint uVar1;
  long *plVar2;
  ulong uVar3;
  undefined8 **ppuVar4;
  long lVar5;
  uint uVar6;
  undefined8 *puStack_68;
  long lStack_60;
  undefined8 uStack_58;
  undefined1 auStack_48 [8];
  
  uStack_58 = *(undefined8 *)(param_2 + 8);
  uVar6 = 0;
  puStack_68 = (undefined8 *)0x31cefd0;
  lStack_60 = lRam00000000033f4dc0 + 0x10;
  do {
    (**(code **)(*param_1 + 0x10))(auStack_48,param_1,uVar6);
    plVar2 = param_1;
    (**(code **)(*param_1 + 0x20))();
    uVar1 = 1 << (ulong)(uVar6 & 0x1f);
    if ((*(uint *)((long)plVar2 + (ulong)(uVar6 >> 5) * 4) & uVar1) != 0) {
      uVar3 = 0;
      FUN_01058d00();
      if ((uVar3 & 1) != 0) {
        ppuVar4 = &puStack_68;
        (*(code *)*puStack_68)(ppuVar4,auStack_48);
        if (((ulong)ppuVar4 & 1) != 0) goto LAB_00c2ec98;
      }
      plVar2 = param_1;
      (**(code **)(*param_1 + 0x18))();
      lVar5 = (ulong)(uVar6 >> 5) * 4;
      *(uint *)((long)plVar2 + lVar5) = *(uint *)((long)plVar2 + lVar5) & (uVar1 ^ 0xffffffff);
    }
LAB_00c2ec98:
    uVar6 = uVar6 + 1;
    if (uVar6 == 15000) {
      return;
    }
  } while( true );
}

