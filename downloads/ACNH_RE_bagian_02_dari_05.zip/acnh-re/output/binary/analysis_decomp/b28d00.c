
void FUN_00c28d00(long param_1)

{
  FUN_00c127d0(*puRam00000000033d0f28);
  FUN_00c24ab0();
  *(undefined8 *)(param_1 + 0x10) = 0;
  if (*(undefined8 **)(param_1 + 0x18) != (undefined8 *)0x0) {
    **(undefined8 **)(param_1 + 0x18) = 0;
    *(undefined8 *)(param_1 + 0x18) = 0;
  }
  return;
}

