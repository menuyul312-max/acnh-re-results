
void FUN_00c33f60(long param_1,int param_2)

{
  ulong uVar1;
  
  uVar1 = *puRam00000000033d2050;
  FUN_001c6030(uVar1);
  if (param_2 < 0x3e9) {
    param_2 = 1000;
  }
  if (0x270e < param_2) {
    param_2 = 9999;
  }
  FUN_00c16fb0(param_1,uVar1 & 0xffffffff,param_2);
  *(int *)(param_1 + 0x108) = param_2;
  return;
}

