
void FUN_00c34370(long param_1,long param_2)

{
  uint uVar1;
  ulong uVar2;
  
  uVar1 = (int)*(char *)(param_2 + 6) & ((int)*(char *)(param_2 + 6) >> 0x1f ^ 0xffffffffU);
  if (0x3a < (int)uVar1) {
    uVar1 = 0x3b;
  }
  uVar2 = *puRam00000000033d2050;
  FUN_001c6030(uVar2);
  FUN_00c17240(param_1,uVar2 & 0xffffffff,uVar1);
  *(uint *)(param_1 + 0x108) = uVar1;
  return;
}

