
/* WARNING: Type propagation algorithm not settling */

byte * FUN_00c3aed0(byte *param_1,undefined *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  char cVar4;
  byte bVar5;
  int *piVar6;
  byte *pbVar7;
  byte *pbVar8;
  uint uVar9;
  long lVar10;
  ulong uVar11;
  long lVar12;
  int iVar13;
  undefined8 *puVar14;
  ulong uVar15;
  uint *puVar16;
  int iVar17;
  long lVar18;
  int iVar19;
  uint *puVar20;
  long lVar21;
  uint *puVar22;
  char *pcVar23;
  uint uVar24;
  uint *puVar25;
  undefined *puVar26;
  long lVar27;
  ulong uStack_198;
  byte *pbStack_190;
  long lStack_188;
  byte *pbStack_180;
  int iStack_178;
  byte abStack_174 [276];
  
  puVar25 = puRam00000000033f5380;
  pcVar23 = pcRam00000000033f5378;
  uVar9 = (uint)param_1;
  if (*pcRam00000000033f5378 != '\0' && *puRam00000000033f5380 == uVar9) {
    return (byte *)(ulong)*puRam00000000033f53a0;
  }
  if (((*pbRam00000000033f5388 & 1) == 0) &&
     (param_1 = pbRam00000000033f5388, __cxa_guard_acquire(), piVar6 = piRam00000000033f5398,
     (int)param_1 != 0)) {
    piVar1 = piRam00000000033f5398 + 4;
    piVar6[0] = 0;
    piVar6[1] = 0;
    piVar6[2] = 0;
    piVar6[3] = 0;
    FUN_01a68060(piVar6,0xd,piVar1);
    param_1 = pbRam00000000033f5388;
    __cxa_guard_release();
    cVar4 = *pcRam00000000033f5390;
  }
  else {
    cVar4 = *pcRam00000000033f5390;
  }
  if (cVar4 == '\0') {
    *pcRam00000000033f5390 = '\x01';
    if (((*pbRam00000000033f53a8 & 1) == 0) &&
       (param_1 = pbRam00000000033f53a8, __cxa_guard_acquire(), puVar14 = puRam00000000033f53b0,
       (int)param_1 != 0)) {
      *puRam00000000033f53b0 = 0xffffffff00000000;
      puVar14[1] = 0xffffffff00000000;
      puVar14[0xc] = 0xffffffff00000000;
      puVar14[2] = 0xffffffff00000000;
      puVar14[3] = 0xffffffff00000000;
      puVar14[4] = 0xffffffff00000000;
      puVar14[5] = 0xffffffff00000000;
      puVar14[6] = 0xffffffff00000000;
      puVar14[7] = 0xffffffff00000000;
      puVar14[8] = 0xffffffff00000000;
      puVar14[9] = 0xffffffff00000000;
      puVar14[10] = 0xffffffff00000000;
      puVar14[0xb] = 0xffffffff00000000;
      param_1 = pbRam00000000033f53a8;
      __cxa_guard_release();
    }
    piVar6 = piRam00000000033f5398;
    bVar5 = *pbRam00000000033d0660;
    uVar11 = lRam00000000033d0668 + 0x10;
    lVar12 = lRam00000000033d0670 + 0x10;
    lVar27 = 0;
    lVar21 = lRam00000000033d1848 + 0x10;
    lVar18 = lRam00000000033d07a0 + 0x10;
    do {
      FUN_00c3b580();
      pbStack_190 = *(byte **)(param_1 + lVar27 * 8);
      iStack_178 = 0x100;
      uStack_198 = uVar11;
      lStack_188 = lVar12;
      pbStack_180 = abStack_174;
      FUN_01a90780(&lStack_188);
      pbVar8 = pbStack_180;
      lStack_188 = lVar21;
      (**(code **)(uStack_198 + 0x18))(&uStack_198);
      pbVar7 = pbStack_190;
      if (pbVar8 != pbStack_190) {
        (**(code **)(uStack_198 + 0x18))(&uStack_198);
        lVar10 = 0;
        do {
          if (pbStack_190[lVar10] == bVar5) goto LAB_00c3b17c;
          if (pbStack_190[lVar10 + 1] == bVar5) {
            lVar10 = lVar10 + 1;
            goto LAB_00c3b17c;
          }
          if (pbStack_190[lVar10 + 2] == bVar5) {
            lVar10 = lVar10 + 2;
            goto LAB_00c3b17c;
          }
          uVar15 = lVar10 + 2;
          lVar10 = lVar10 + 3;
        } while (uVar15 >> 0x13 == 0);
        lVar10 = 0;
LAB_00c3b17c:
        iVar13 = (int)lVar10;
        if (iStack_178 <= (int)lVar10) {
          iVar13 = iStack_178 + -1;
        }
        memcpy(pbVar8,pbVar7,(long)iVar13);
        pbVar8[iVar13] = bVar5;
      }
      lStack_188 = lVar18;
      (**(code **)(uStack_198 + 0x18))(&uStack_198);
      param_1 = pbStack_190;
      FUN_01aab050();
      puVar14 = puRam00000000033f53b0 + lVar27;
      iVar13 = *piVar6;
      iVar17 = piVar6[1];
      *(int *)puVar14 = (int)param_1;
      *(int *)((long)puVar14 + 4) = (int)lVar27;
      if (iVar13 < iVar17) {
        *(undefined8 **)(*(long *)(piVar6 + 2) + (long)iVar13 * 8) = puVar14;
        iVar13 = *piVar6 + 1;
        *piVar6 = iVar13;
      }
      puVar25 = puRam00000000033f5380;
      pcVar23 = pcRam00000000033f5378;
      lVar27 = lVar27 + 1;
    } while (lVar27 != 0xd);
    if (iVar13 < 2) goto joined_r0x00c3af48;
    lVar12 = *(long *)(piVar6 + 2);
    iVar17 = 0;
    iVar13 = iVar13 + -1;
    do {
      if (iVar13 <= iVar17) break;
      puVar16 = *(uint **)(lVar12 + (long)iVar17 * 8);
      uVar15 = (ulong)iVar17;
      lVar21 = (long)iVar13;
      uVar11 = uVar15;
      if ((iVar13 - iVar17 & 1U) != 0) {
        uVar11 = uVar15 + 1;
        puVar20 = *(uint **)(lVar12 + uVar11 * 8);
        uVar24 = *puVar16;
        puVar16 = puVar20;
        if (*puVar20 < uVar24) {
          puVar16 = *(uint **)(lVar12 + uVar15 * 8);
          *(uint **)(lVar12 + uVar11 * 8) = puVar16;
          *(uint **)(lVar12 + uVar15 * 8) = puVar20;
        }
      }
      iVar13 = iVar17;
      if (~uVar15 + lVar21 != 0) {
        puVar14 = (undefined8 *)(lVar12 + 8 + uVar11 * 8);
        lVar21 = lVar21 - uVar11;
        do {
          puVar22 = (uint *)*puVar14;
          iVar19 = (int)uVar11;
          puVar20 = puVar22;
          if (*puVar22 < *puVar16) {
            puVar20 = (uint *)puVar14[-1];
            puVar14[-1] = puVar22;
            *puVar14 = puVar20;
            iVar13 = iVar19;
          }
          puVar22 = (uint *)puVar14[1];
          uVar11 = uVar11 + 2;
          param_1 = (byte *)(ulong)*puVar22;
          puVar16 = puVar22;
          if (*puVar22 < *puVar20) {
            puVar16 = (uint *)*puVar14;
            *puVar14 = puVar22;
            puVar14[1] = puVar16;
            iVar13 = iVar19 + 1;
          }
          lVar21 = lVar21 + -2;
          puVar14 = puVar14 + 2;
        } while (lVar21 != 0);
      }
      if (iVar13 <= iVar17) break;
      puVar16 = *(uint **)(lVar12 + (long)iVar13 * 8);
      lVar18 = (long)iVar13;
      lVar21 = lVar18;
      if ((iVar13 - iVar17 & 1U) != 0) {
        lVar21 = lVar18 + -1;
        puVar20 = *(uint **)(lVar12 + lVar21 * 8);
        uVar24 = *puVar16;
        puVar16 = puVar20;
        if (uVar24 < *puVar20) {
          puVar16 = *(uint **)(lVar12 + lVar18 * 8);
          *(uint **)(lVar12 + lVar21 * 8) = puVar16;
          *(uint **)(lVar12 + lVar18 * 8) = puVar20;
        }
      }
      iVar17 = iVar13;
      if (~uVar15 + lVar18 != 0) {
        lVar18 = lVar21 * 8 + -8;
        do {
          puVar22 = *(uint **)(lVar12 + lVar18);
          iVar19 = (int)lVar21;
          puVar20 = puVar22;
          if (*puVar16 < *puVar22) {
            puVar20 = *(uint **)(lVar12 + lVar21 * 8);
            *(uint **)(lVar12 + lVar18) = puVar20;
            *(uint **)(lVar12 + lVar21 * 8) = puVar22;
            iVar17 = iVar19;
          }
          puVar14 = (undefined8 *)(lVar12 + lVar18);
          puVar22 = (uint *)puVar14[-1];
          param_1 = (byte *)(ulong)*puVar22;
          lVar21 = lVar21 + -2;
          puVar16 = puVar22;
          if (*puVar20 < *puVar22) {
            puVar16 = (uint *)*puVar14;
            puVar14[-1] = puVar16;
            *puVar14 = puVar22;
            iVar17 = iVar19 + -1;
          }
          lVar18 = lVar18 + -0x10;
        } while ((long)uVar15 < lVar21);
      }
    } while (iVar17 != iVar13);
  }
  iVar13 = *piRam00000000033f5398;
joined_r0x00c3af48:
  if (iVar13 != 0) {
    iVar13 = iVar13 + -1;
    puVar14 = *(undefined8 **)(piRam00000000033f5398 + 2);
    if (iVar13 < 1) {
      uVar24 = 0;
      puVar16 = (uint *)*puVar14;
      uVar3 = *puVar16;
    }
    else {
      uVar24 = 0;
      do {
        iVar17 = iVar13 + uVar24;
        if (iVar17 < 0) {
          iVar17 = iVar17 + 1;
        }
        uVar2 = iVar17 >> 1;
        puVar16 = (uint *)puVar14[(int)uVar2];
        if (*puVar16 == uVar9) goto joined_r0x00c3b010;
        iVar17 = uVar2 - 1;
        if (*puVar16 < uVar9) {
          uVar24 = uVar2 + 1;
          iVar17 = iVar13;
        }
        iVar13 = iVar17;
      } while ((int)uVar24 < iVar13);
      puVar16 = (uint *)puVar14[(int)uVar24];
      uVar3 = *puVar16;
    }
    uVar2 = uVar24;
    if (uVar3 == uVar9) {
joined_r0x00c3b010:
      if (uVar2 < 0xd) {
        uVar24 = puVar16[1];
        param_1 = (byte *)(ulong)uVar24;
        if (uVar24 < 0xd) {
          *pcVar23 = '\x01';
          *puVar25 = uVar9;
          *puRam00000000033f53a0 = uVar24;
          return param_1;
        }
      }
    }
  }
  if (param_2 != (undefined *)0x0) {
    uStack_198 = uStack_198 & 0xffffffff00000000;
    lStack_188 = lRam00000000033d0668 + 0x10;
    bVar5 = *pbRam00000000033d0660;
    uVar9 = 0;
    pbStack_180 = param_2;
    do {
      puVar26 = &UNK_02ad4e28;
      if (uVar9 < 0xd) {
        FUN_00c3b580();
        puVar26 = *(undefined **)(param_1 + (long)(int)uVar9 * 8);
      }
      param_1 = (byte *)&lStack_188;
      (**(code **)(lStack_188 + 0x18))();
      if (puVar26 == pbStack_180) {
LAB_00c3b304:
        return (byte *)(ulong)uVar9;
      }
      uVar11 = 0;
      do {
        if (puVar26[uVar11] != pbStack_180[uVar11]) break;
        if (puVar26[uVar11] == bVar5) goto LAB_00c3b304;
        if (puVar26[uVar11 + 1] != pbStack_180[uVar11 + 1]) break;
        if (puVar26[uVar11 + 1] == bVar5) goto LAB_00c3b304;
        if (puVar26[uVar11 + 2] != pbStack_180[uVar11 + 2]) break;
        if (puVar26[uVar11 + 2] == bVar5) goto LAB_00c3b304;
        uVar11 = uVar11 + 3;
      } while (uVar11 < 0x80001);
      uVar24 = 0xd;
      if ((int)uVar9 < 0xd) {
        uVar24 = uVar9 + 1;
      }
      uVar9 = uVar24;
    } while (uVar24 != 0xd);
  }
  return (byte *)0xffffffff;
}

