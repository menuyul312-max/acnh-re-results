
void FUN_00c32c30(long *param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  long *plVar2;
  
  lVar1 = lRam00000000033d4cb8 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0x20);
  plVar2 = param_1 + 0x24;
  if (param_1 + 0x24 <= (long *)((long)param_1 + 0xe2)) {
    plVar2 = (long *)((long)param_1 + 0xe2);
  }
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  *param_1 = lVar1;
  memset(param_1 + 0x1c,0,(long)plVar2 + (-0xdf - (long)param_1) & 0xfffffffffffffffe);
  FUN_00c32ce0(param_1,param_2,param_3);
  return;
}

