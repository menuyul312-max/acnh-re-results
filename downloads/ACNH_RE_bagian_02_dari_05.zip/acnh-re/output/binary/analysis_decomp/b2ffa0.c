
void FUN_00c2ffa0(long *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c2ffa8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x20))();
  return;
}

