
void FUN_00c2c360(long param_1)

{
  int iVar1;
  long *plVar2;
  long lVar3;
  
  lVar3 = *(long *)(param_1 + 0x20);
  if (lVar3 != 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    if (iVar1 == 2) {
      plVar2 = *(long **)(lVar3 + 0x228);
    }
    else if (iVar1 == 1) {
      plVar2 = *(long **)(lVar3 + 0x220);
    }
    else {
      if (iVar1 != 0) {
        return;
      }
      plVar2 = *(long **)(lVar3 + 0x218);
    }
    if ((plVar2 != (long *)0x0) && ((**(code **)(*plVar2 + 0x220))(), plVar2 != (long *)0x0)) {
      FUN_01785ec0();
      return;
    }
  }
  return;
}

