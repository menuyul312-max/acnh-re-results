
bool FUN_00c24960(long param_1)

{
  if (*(char *)(param_1 + 0x2472) != '\0') {
    return false;
  }
  return *(int *)(param_1 + 0x48) - 7U < 2;
}

