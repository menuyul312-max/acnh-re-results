
void FUN_001b3c90(long param_1)

{
  int iVar1;
  ulong uVar2;
  bool bVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  long lVar7;
  
  lVar7 = *plRam00000000033d05f8;
  if (lVar7 == 0) {
    return;
  }
  if (*(int *)(lVar7 + 8) == 0) {
    uVar4 = 0;
LAB_001b3cf0:
    uVar2 = 0;
  }
  else {
    if (**(long **)(lVar7 + 0x10) == 0) {
      uVar4 = 0;
      lVar7 = **(long **)(lVar7 + 0x10);
    }
    else {
      uVar4 = (int)**(long **)(lVar7 + 0x10) + 0x20;
      FUN_022ead60();
      if (*(int *)(lVar7 + 8) == 0) goto LAB_001b3cf0;
      lVar7 = **(long **)(lVar7 + 0x10);
    }
    if (lVar7 == 0) goto LAB_001b3cf0;
    uVar2 = lVar7 + 0x20;
    FUN_022ead70();
  }
  iVar6 = *(int *)(param_1 + 0x18);
  iVar5 = *(int *)(param_1 + 0x10);
  uVar4 = uVar4 & 1;
  if (iVar6 < iVar5) {
LAB_001b3d3c:
    iVar1 = iVar5;
    if (0 < *(int *)(param_1 + 0x14)) {
      iVar1 = *(int *)(param_1 + 0x14);
    }
    *(int *)(param_1 + 0x14) = iVar1 + -1;
    *(int *)(param_1 + 0x18) = iVar6 + 1;
    if (iVar1 <= iVar5) {
      iVar5 = 0;
    }
    *(char *)(*(long *)(param_1 + 8) + (long)((iVar1 + -1) - iVar5)) = (char)uVar4;
  }
  else {
    if (0 < iVar6) {
      *(int *)(param_1 + 0x18) = iVar6 + -1;
      iVar6 = iVar6 + -1;
    }
    if (iVar6 < iVar5) goto LAB_001b3d3c;
  }
  if (uVar4 != 0) {
    uVar4 = *(int *)(param_1 + 0x728) + 1;
  }
  *(uint *)(param_1 + 0x728) = uVar4;
  iVar6 = *(int *)(param_1 + 0x740);
  iVar5 = *(int *)(param_1 + 0x738);
  if (iVar5 <= iVar6) {
    if (0 < iVar6) {
      *(int *)(param_1 + 0x740) = iVar6 + -1;
      iVar6 = iVar6 + -1;
    }
    if (iVar5 <= iVar6) goto LAB_001b3dd4;
  }
  *(int *)(param_1 + 0x740) = iVar6 + 1;
  iVar6 = iVar5;
  if (0 < *(int *)(param_1 + 0x73c)) {
    iVar6 = *(int *)(param_1 + 0x73c);
  }
  if (iVar6 <= iVar5) {
    iVar5 = 0;
  }
  *(int *)(param_1 + 0x73c) = iVar6 + -1;
  *(byte *)(*(long *)(param_1 + 0x730) + (long)((iVar6 + -1) - iVar5)) = (byte)uVar2 & 1;
LAB_001b3dd4:
  if ((uVar2 & 1) == 0) {
    iVar5 = 0;
  }
  else {
    iVar5 = *(int *)(param_1 + 0xe50) + 1;
  }
  *(int *)(param_1 + 0xe50) = iVar5;
  if (*(int *)(param_1 + 0x728) < *(int *)(param_1 + 0x72c)) {
    bVar3 = *(int *)(param_1 + 0xe54) <= iVar5;
  }
  else {
    bVar3 = true;
  }
  *(bool *)(param_1 + 0xe58) = bVar3;
  return;
}

