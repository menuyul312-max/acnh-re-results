
void FUN_00c2b2e0(long param_1,int param_2)

{
  if (((*(int *)(param_1 + 8) == 2) &&
      (FUN_00c2f6b0(param_2,*(undefined1 *)(param_1 + 0x18)),
      0x3a < param_2 - 0xa4U || (1L << ((ulong)(param_2 - 0xa4U) & 0x3f) & 0x7c000000000000dU) == 0)
      ) && (param_2 != 0x108)) {
    *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 1;
    return;
  }
  return;
}

