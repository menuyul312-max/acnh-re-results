
void FUN_00c2ffd0(long *param_1,undefined4 param_2)

{
                    /* WARNING: Could not recover jumptable at 0x00c2ffdc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x30))(param_1,param_2);
  return;
}

