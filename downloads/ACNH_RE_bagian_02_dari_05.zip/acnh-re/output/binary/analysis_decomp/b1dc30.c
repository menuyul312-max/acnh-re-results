
void FUN_00c1dc30(undefined8 *param_1,undefined8 param_2,byte param_3)

{
  long lVar1;
  undefined2 uVar2;
  long lVar3;
  long *plVar4;
  
  lVar3 = lRam00000000033d5c88;
  *(undefined2 *)((long)param_1 + 9) = 0;
  *(undefined4 *)((long)param_1 + 0xc) = 0;
  *param_1 = param_2;
  *(byte *)(param_1 + 1) = param_3 & 1;
  param_1[3] = (long)param_1 + 0x24;
  plVar4 = param_1 + 2;
  *plVar4 = lVar3 + 0x10;
  *(undefined4 *)(param_1 + 4) = 0x40;
  FUN_01a907a0(plVar4);
  uVar2 = *puRam00000000033d14d0;
  lVar1 = lRam00000000033f4da8 + 0x10;
  *(undefined2 *)param_1[3] = uVar2;
  *plVar4 = lVar1;
  plVar4 = param_1 + 0x15;
  *plVar4 = lVar3 + 0x10;
  param_1[0x16] = (long)param_1 + 0xbc;
  *(undefined4 *)(param_1 + 0x17) = 0x10;
  FUN_01a907a0(plVar4);
  lVar1 = lRam00000000033e7770;
  *(undefined2 *)param_1[0x16] = uVar2;
  *plVar4 = lVar1 + 0x10;
  return;
}

