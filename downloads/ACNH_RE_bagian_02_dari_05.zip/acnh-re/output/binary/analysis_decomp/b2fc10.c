
bool FUN_00c2fc10(int *param_1)

{
  return *param_1 - 3U < 2;
}

