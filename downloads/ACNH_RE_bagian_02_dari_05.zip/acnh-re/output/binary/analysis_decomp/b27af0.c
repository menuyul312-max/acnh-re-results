
bool FUN_00c27af0(long param_1)

{
  return *(int *)(param_1 + 0x2188) == 4;
}

