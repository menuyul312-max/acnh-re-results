
void FUN_00c2d4f0(long param_1)

{
  FUN_01385bf0(*(undefined8 *)(param_1 + 0x20));
  return;
}

