
uint FUN_00c34f30(long *param_1,ulong param_2)

{
  uint uVar1;
  ulong uVar2;
  long *plVar3;
  long *plVar4;
  long lStack_b8;
  long *plStack_b0;
  long lStack_a0;
  undefined1 *puStack_98;
  undefined4 uStack_90;
  undefined1 auStack_8c [68];
  long alStack_48 [3];
  undefined1 auStack_28 [8];
  
  FUN_01058a90(param_2);
  uVar2 = param_2;
  FUN_01058d00();
  if ((uVar2 & 1) == 0) {
    uVar1 = 0;
  }
  else {
    plVar3 = param_1;
    (**(code **)(*param_1 + 0x10))();
    FUN_00b9c290(alStack_48,param_2);
    puStack_98 = auStack_8c;
    lStack_a0 = lRam00000000033d0670 + 0x10;
    uStack_90 = 0x40;
    FUN_01a90780(&lStack_a0);
    lStack_a0 = lRam00000000033d1298;
    *puStack_98 = *puRam00000000033d0660;
    lStack_a0 = lStack_a0 + 0x10;
    plVar4 = alStack_48;
    FUN_00b9cb60(plVar4,0x4a);
    if (((ulong)plVar4 & 1) == 0) {
      plVar4 = alStack_48;
    }
    else {
      FUN_00bac440(auStack_28,alStack_48);
      FUN_00b9c290(&lStack_b8,auStack_28);
      plVar4 = &lStack_b8;
    }
    FUN_00bb6620(plVar4,&lStack_a0);
    param_1 = param_1 + 1;
    lStack_b8 = lRam00000000033d0668 + 0x10;
    plStack_b0 = plVar3;
    FUN_00123860(param_1,&lStack_b8,&lStack_a0,0);
    uVar1 = (uint)param_1;
  }
  return uVar1 & 1;
}

