
void FUN_00c24d70(long param_1,uint param_2)

{
  FUN_00c1c530(*(undefined8 *)(param_1 + 0x10),param_2 & 1);
  return;
}

