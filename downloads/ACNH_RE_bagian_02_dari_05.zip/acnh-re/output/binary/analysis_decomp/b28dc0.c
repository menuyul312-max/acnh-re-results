
void FUN_00c28dc0(long param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  undefined1 *puVar2;
  
  puVar2 = param_2;
  FUN_00ea4020();
  uVar1 = *param_2;
  if (((ulong)puVar2 & 1) == 0) {
    uVar1 = 0xff;
  }
  *(undefined1 *)(param_1 + 0xc) = uVar1;
  return;
}

