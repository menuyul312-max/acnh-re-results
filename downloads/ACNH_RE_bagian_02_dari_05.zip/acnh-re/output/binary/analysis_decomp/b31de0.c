
void FUN_00c31de0(long *param_1,undefined8 param_2)

{
  long lVar1;
  long *plVar2;
  long lStack_50;
  undefined *puStack_48;
  long lStack_40;
  undefined8 uStack_38;
  
  lVar1 = lRam00000000033d96e8 + 0x10;
  *param_1 = lVar1;
  FUN_00123650(param_1,param_1 + 0x1c,0x80);
  plVar2 = param_1 + 0x3c;
  if (param_1 + 0x3c <= (long *)((long)param_1 + 0xe2)) {
    plVar2 = (long *)((long)param_1 + 0xe2);
  }
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  *param_1 = lVar1;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  memset(param_1 + 0x1c,0,(long)plVar2 + (-0xdf - (long)param_1) & 0xfffffffffffffffe);
  FUN_00bd9900();
  lStack_50 = lRam00000000033d0668 + 0x10;
  puStack_48 = &UNK_02a8dc6a;
  lStack_40 = lStack_50;
  uStack_38 = param_2;
  FUN_00123860(param_1,&lStack_50,&lStack_40,0);
  return;
}

