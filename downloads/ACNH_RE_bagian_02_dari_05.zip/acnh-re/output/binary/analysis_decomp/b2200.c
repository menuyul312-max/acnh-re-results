
void _INIT_266(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam000000000344ffd8 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3450010);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000344ffdc = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam000000000344ffe0 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000344fff4 = 0xffff;
  uRam000000000344fff0 = 0xffffffff;
  uRam000000000344fffc = 0;
  uRam000000000344fff8 = 0;
  uRam000000000344ffe4 = (undefined4)uVar2;
  uRam000000000344ffe8 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003450000 = uVar2;
  uRam0000000003450008 = 0;
  return;
}

