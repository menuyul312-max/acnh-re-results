
undefined4 FUN_00c2d260(undefined8 *param_1)

{
  uint uVar1;
  undefined4 uStack_24;
  
  FUN_00c24b40(*param_1);
  FUN_00be6790();
  if (*(int *)((long)param_1 + 0x2c) != 0) {
    return 0;
  }
  if (5 < *(uint *)((long)param_1 + 0x34)) {
    return 0;
  }
  uVar1 = 1 << (ulong)(*(uint *)((long)param_1 + 0x34) & 0x1f);
  if ((uVar1 & 9) != 0) {
    if (uStack_24 == 2) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x58);
    }
    if (uStack_24 == 1) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x54);
    }
    return 0;
  }
  if ((uVar1 & 0x12) == 0) {
    if (uStack_24 == 1) {
      return *(undefined4 *)(lRam00000000033f4d60 + 0x68);
    }
    if (uStack_24 == 0) {
      return *(undefined4 *)(lRam00000000033f4d60 + 100);
    }
    return 0;
  }
  if (uStack_24 == 2) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x60);
  }
  if (uStack_24 == 0) {
    return *(undefined4 *)(lRam00000000033f4d60 + 0x5c);
  }
  return 0;
}

