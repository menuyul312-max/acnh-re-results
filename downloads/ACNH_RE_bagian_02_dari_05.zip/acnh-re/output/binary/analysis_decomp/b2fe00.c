
void FUN_00c2fe00(long *param_1)

{
  FUN_001249c0();
  *param_1 = lRam00000000033f5230 + 0x10;
  return;
}

