
void FUN_00c24d90(long param_1)

{
  long lVar1;
  long lVar2;
  long lVar3;
  long lVar4;
  long lVar5;
  long *plVar6;
  long lStack_40;
  undefined *puStack_38;
  
  lVar1 = param_1 + 0x40;
  FUN_020062f0(lVar1,10,0,0,0);
  lVar2 = lRam00000000033d0668 + 0x10;
  puStack_38 = &UNK_02a5b2cd;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,0,&lStack_40);
  plVar6 = *(long **)(param_1 + 0x70);
  plVar6[2] = lRam00000000033f4ed8;
  plVar6[3] = 0;
  lVar3 = lRam00000000033f4ee0;
  plVar6[4] = lRam00000000033f4ee8;
  plVar6[5] = 0;
  lVar4 = lRam00000000033f4ef0;
  lVar3 = lVar3 + 0x10;
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  plVar6[6] = lVar4;
  plVar6[7] = 0;
  puStack_38 = &UNK_02a4c136;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,1,&lStack_40);
  lVar4 = lRam00000000033f4ef8;
  plVar6 = *(long **)(param_1 + 0x70) + 8;
  if (*(uint *)(param_1 + 0x68) < 2) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f08;
  plVar6[4] = lRam00000000033f4f00;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02a20a61;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,2,&lStack_40);
  lVar4 = lRam00000000033f4f10;
  plVar6 = *(long **)(param_1 + 0x70) + 0x10;
  if (*(uint *)(param_1 + 0x68) < 3) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f20;
  plVar6[4] = lRam00000000033f4f18;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02aab665;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,3,&lStack_40);
  lVar4 = lRam00000000033f4f28;
  plVar6 = *(long **)(param_1 + 0x70) + 0x18;
  if (*(uint *)(param_1 + 0x68) < 4) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f38;
  plVar6[4] = lRam00000000033f4f30;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02a92b9a;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,4,&lStack_40);
  lVar4 = lRam00000000033f4f40;
  plVar6 = *(long **)(param_1 + 0x70) + 0x20;
  if (*(uint *)(param_1 + 0x68) < 5) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f50;
  plVar6[4] = lRam00000000033f4f48;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02a20a6b;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,5,&lStack_40);
  lVar4 = lRam00000000033f4f58;
  plVar6 = *(long **)(param_1 + 0x70) + 0x28;
  if (*(uint *)(param_1 + 0x68) < 6) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f68;
  plVar6[4] = lRam00000000033f4f60;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02ad12e9;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,6,&lStack_40);
  lVar4 = lRam00000000033f4f70;
  plVar6 = *(long **)(param_1 + 0x70) + 0x30;
  if (*(uint *)(param_1 + 0x68) < 7) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f80;
  plVar6[4] = lRam00000000033f4f78;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02a473aa;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,7,&lStack_40);
  lVar4 = lRam00000000033f4f88;
  plVar6 = *(long **)(param_1 + 0x70) + 0x38;
  if (*(uint *)(param_1 + 0x68) < 8) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4f98;
  plVar6[4] = lRam00000000033f4f90;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02aa19bb;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,8,&lStack_40);
  lVar4 = lRam00000000033f4fa0;
  plVar6 = *(long **)(param_1 + 0x70) + 0x40;
  if (*(uint *)(param_1 + 0x68) < 9) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  lVar5 = lRam00000000033f4fb0;
  plVar6[4] = lRam00000000033f4fa8;
  plVar6[5] = 0;
  plVar6[2] = lVar4;
  plVar6[3] = 0;
  plVar6[6] = lVar5;
  plVar6[7] = 0;
  puStack_38 = &UNK_02a25a98;
  lStack_40 = lVar2;
  FUN_020064b0(lVar1,9,&lStack_40);
  lVar4 = lRam00000000033f4fc0;
  lVar2 = lRam00000000033f4fb8;
  plVar6 = *(long **)(param_1 + 0x70) + 0x48;
  if (*(uint *)(param_1 + 0x68) < 10) {
    plVar6 = *(long **)(param_1 + 0x70);
  }
  *plVar6 = lVar3;
  plVar6[1] = param_1;
  plVar6[2] = lVar2;
  plVar6[3] = 0;
  lVar2 = lRam00000000033f4fc8;
  plVar6[4] = lVar4;
  plVar6[5] = 0;
  plVar6[6] = lVar2;
  plVar6[7] = 0;
  FUN_02006750(lVar1);
  return;
}

