
void FUN_00c2af20(long param_1)

{
  long lVar1;
  int iVar2;
  long lStack_40;
  undefined *puStack_38;
  
  if ((bRam0000000003654488 & 1) == 0) {
    iVar2 = 0x3654488;
    __cxa_guard_acquire();
    if (iVar2 != 0) {
      lRam00000000036544b0 = lRam00000000033d0668 + 0x10;
      lRam00000000036544a8 = lRam00000000033f51a0 + 0x10;
      uRam00000000036544b8 = uRam00000000033d0660;
      uRam00000000036544c8 = uRam00000000033d0660;
      uRam00000000036544d0 = 0;
      lRam00000000036544c0 = lRam00000000036544b0;
      __cxa_guard_release(0x3654488);
    }
  }
  if ((bRam0000000003654490 & 1) == 0) {
    iVar2 = 0x3654490;
    __cxa_guard_acquire();
    if (iVar2 != 0) {
      uRam00000000036544d8 = 0;
      lRam00000000036544e8 = lRam00000000033d0668 + 0x10;
      uRam00000000036544e0 = 0;
      uRam00000000036544f0 = uRam00000000033d0660;
      uRam0000000003654500 = uRam00000000033d0660;
      uRam0000000003654510 = uRam00000000033d0660;
      uRam0000000003654520 = uRam00000000033d0660;
      uRam0000000003654528 = 0;
      lRam00000000036544f8 = lRam00000000036544e8;
      lRam0000000003654508 = lRam00000000036544e8;
      lRam0000000003654518 = lRam00000000036544e8;
      __cxa_guard_release(0x3654490);
    }
  }
  uRam00000000036544e0 = 0x36544a8;
  lVar1 = lRam00000000033d0668 + 0x10;
  puStack_38 = &UNK_02ac71d5;
  lStack_40 = lVar1;
  FUN_01a904f0(0x3654518,&lStack_40);
  puStack_38 = &UNK_02aa19ca;
  lStack_40 = lVar1;
  FUN_01a904f0(0x36544e8,&lStack_40);
  uRam0000000003654528 = 0;
  FUN_01750020(param_1 + 0x20,0x36544d8);
  return;
}

