
void FUN_00c2b070(long param_1)

{
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 0x10) = 0;
  *(undefined1 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  FUN_00c2fc40(param_1 + 0x58);
  FUN_00bf1140(param_1 + 0x158);
  FUN_017500b0(param_1 + 0x20);
  return;
}

