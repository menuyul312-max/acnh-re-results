
void FUN_00c28ea0(long param_1)

{
  if ((*(long *)(param_1 + 0x10) == 0) && (*(long *)(param_1 + 0x20) != 0)) {
    FUN_00c23c40();
    return;
  }
  return;
}

