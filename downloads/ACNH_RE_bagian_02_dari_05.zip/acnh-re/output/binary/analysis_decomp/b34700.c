
void FUN_00c34700(undefined8 param_1)

{
  ulong uVar1;
  undefined1 *puVar2;
  long lStack_58;
  long lStack_50;
  undefined1 auStack_40 [8];
  undefined1 auStack_38 [8];
  undefined4 auStack_30 [2];
  long lStack_28;
  
  FUN_00ea3fc0(auStack_38);
  uVar1 = 0;
  FUN_00ea4020();
  if ((uVar1 & 1) == 0) {
    FUN_00f712f0(&lStack_58);
    uVar1 = 0;
    FUN_00ea4020();
    auStack_38[0] = (undefined1)lStack_58;
    if ((uVar1 & 1) == 0) {
      auStack_38[0] = 0xff;
    }
  }
  FUN_00ea3fc0(auStack_40,auStack_38);
  puVar2 = auStack_40;
  thunk_FUN_00faafd0();
  if (puVar2 != (undefined1 *)0x0) {
    FUN_00fe9350(&lStack_58,puVar2 + 0x165e0,1);
    lStack_58 = lRam00000000033d98a0 + 0x10;
    lStack_28 = *(long *)(lStack_50 + 0x10) + *(long *)(lStack_50 + 8) + 4;
    auStack_30[0] = 10;
    FUN_010e4670(param_1,auStack_30);
    FUN_001234f0(param_1);
    FUN_00121d40();
    FUN_00fe93d0(&lStack_58);
  }
  return;
}

