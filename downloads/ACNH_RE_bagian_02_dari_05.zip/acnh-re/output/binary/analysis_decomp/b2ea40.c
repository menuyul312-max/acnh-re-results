
void FUN_00c2ea40(void)

{
  FUN_00c127e0(*puRam00000000033d0f28);
  FUN_00c24d80();
  return;
}

