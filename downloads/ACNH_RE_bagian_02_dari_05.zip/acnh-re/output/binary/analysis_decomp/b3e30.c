
void _INIT_269(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uRam0000000003450240 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x3450278);
  uVar1 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam0000000003450244 = uVar1;
  uVar1 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003450248 = uVar1;
  uVar2 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam000000000345025c = 0xffff;
  uRam0000000003450258 = 0xffffffff;
  uRam0000000003450264 = 0;
  uRam0000000003450260 = 0;
  uRam000000000345024c = (undefined4)uVar2;
  uRam0000000003450250 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam0000000003450268 = uVar2;
  uRam0000000003450270 = 0;
  return;
}

