
void FUN_00c2ea60(ulong param_1,ulong param_2,ulong param_3)

{
  ulong uVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  undefined8 uVar5;
  undefined4 uStack_44;
  
  if ((param_3 != 0) && (uVar1 = param_3, FUN_012559a0(), (uVar1 & 1) != 0)) {
    uVar5 = *(undefined8 *)(param_3 + 0x48);
    uStack_44 = 0;
    uVar1 = param_2;
    FUN_001232a0(param_2);
    uVar2 = param_2;
    FUN_001232b0(param_2);
    uVar3 = param_1;
    FUN_001233a0(param_1);
    uVar4 = param_1;
    FUN_00123350(param_1);
    FUN_01dd0fb0(uVar5,&uStack_44,uVar1,uVar2 & 0xffffffff,uVar3,uVar4 & 0xffffffff,0,1);
    FUN_001233b0(param_2,param_1);
    FUN_00123100(param_1,param_2);
  }
  return;
}

