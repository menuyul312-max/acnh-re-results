
void FUN_001b31b0(long *param_1)

{
  long lVar1;
  long lVar2;
  
  FUN_022ecb50();
  lVar1 = lRam00000000033d4b30;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  *param_1 = lVar1 + 0x10;
  FUN_01be8480(param_1 + 8);
  param_1[0x111] = 0;
  *(undefined1 *)(param_1 + 0x110) = 0;
  param_1[0x10f] = 0;
  lVar2 = lRam00000000033d0668;
  param_1[0x10e] = 0;
  lVar1 = lRam00000000033d0660;
  param_1[0x112] = lVar2 + 0x10;
  param_1[0x113] = lVar1;
  param_1[0x114] = 0;
  *(undefined4 *)(param_1 + 0x115) = 0x20;
  return;
}

