
void _INIT_2653(void)

{
  int iVar1;
  char cVar2;
  char cVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  ulong uVar7;
  long lVar8;
  long lStack_40;
  undefined *puStack_38;
  
  lStack_40 = CONCAT44(lStack_40._4_4_,2);
  uRam0000000003655188 = 4;
  _ZN2nn3err18ErrorResultVariantC1Ev(0x36551e0);
  uVar5 = 0x7f;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0x7f,0,0,1);
  uRam000000000365518c = uVar5;
  uVar5 = 0xff;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0xff,0xff,0xff,0xff);
  uRam0000000003655190 = uVar5;
  uVar6 = 0;
  _ZN2nn3ldn15MakeIpv4AddressEhhhh(0,0,0,0);
  uRam00000000036551b4 = 0xffff;
  uRam00000000036551b0 = 0xffffffff;
  uRam00000000036551bc = 0;
  uRam00000000036551b8 = 0;
  uRam0000000003655194 = (undefined4)uVar6;
  uRam0000000003655198 = 0x8004ef;
  _ZN2nn2os13GetSystemTickEv();
  uRam00000000036551c8 = 0;
  uRam00000000036551c0 = uVar6;
  FUN_010588a0(0x36551d0,0x1c2b);
  FUN_010588a0(0x36551d8,0x142e);
  uRam00000000036551a4 = 0x200000003;
  iRam00000000036551a0 = *piRam00000000033d0630;
  lRam00000000036551f0 = lRam00000000033d0670 + 0x10;
  iRam000000000365519c = -iRam00000000036551a0;
  lVar8 = lRam00000000033d0668 + 0x10;
  puStack_38 = &UNK_02ac0a89;
  puRam00000000036551f8 = (undefined *)0x3655204;
  iRam0000000003655200 = 0x20;
  lStack_40 = lVar8;
  FUN_01a90780(0x36551f0);
  puVar4 = puRam00000000036551f8;
  lRam00000000036551f0 = lRam00000000033d0678 + 0x10;
  if (puRam00000000036551f8 != &UNK_02ac0a89) {
    cVar2 = *pcRam00000000033d0660;
    uVar7 = 0;
    cVar3 = UNK_02ac0a89;
    while (cVar3 != cVar2) {
      if (uVar7 >> 0x13 != 0) {
        uVar7 = 0;
        break;
      }
      if ((&UNK_02ac0a8a)[uVar7] == cVar2) {
        uVar7 = uVar7 + 1;
        break;
      }
      cVar3 = (&UNK_02ac0a8b)[uVar7];
      uVar7 = uVar7 + 2;
    }
    iVar1 = (int)uVar7;
    if (iRam0000000003655200 <= (int)uVar7) {
      iVar1 = iRam0000000003655200 + -1;
    }
    memcpy(puRam00000000036551f8,&UNK_02ac0a89,(long)iVar1);
    puVar4[iVar1] = cVar2;
    lVar8 = lStack_40;
  }
  lRam00000000036551f0 = lRam00000000033d0680 + 0x10;
  (**(code **)(lVar8 + 0x18))(&lStack_40);
  FUN_00101bf0(puStack_38,0);
  uRam0000000003655228 = (int)puStack_38;
  return;
}

